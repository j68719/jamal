/**
 * TA System — Frontend JavaScript
 */

(function ($) {
    'use strict';

    const ajax  = taSystem.ajaxUrl;
    const nonce = taSystem.nonce;

    // ─────────────────────────────────────────────────────────────────────────
    // Helper utilities
    // ─────────────────────────────────────────────────────────────────────────

    function showEl(id)  { var el = document.getElementById(id); if (el) el.style.display = ''; }
    function hideEl(id)  { var el = document.getElementById(id); if (el) el.style.display = 'none'; }
    function setHtml(id, html) { var el = document.getElementById(id); if (el) el.innerHTML = html; }

    function showMsg(id, msg, type) {
        var el = document.getElementById(id);
        if (!el) return;
        el.className = 'ta-message ta-message-' + (type || 'info');
        el.innerHTML = msg;
        el.style.display = '';
    }

    function post(data, callback) {
        data.nonce = nonce;
        $.post(ajax, data, function (res) {
            callback(res);
        }).fail(function () {
            callback({ success: false, data: { message: 'خطای اتصال. لطفاً دوباره تلاش کنید.' } });
        });
    }

    function postForm(formData, callback) {
        formData.append('nonce', nonce);
        $.ajax({
            url: ajax,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: callback,
            error: function () {
                callback({ success: false, data: { message: 'خطای اتصال.' } });
            }
        });
    }

    // ─────────────────────────────────────────────────────────────────────────
    // صفحه محصول — جستجوی استادیار
    // ─────────────────────────────────────────────────────────────────────────

    window.taCancelGroupForm = function (capId) {
    var form = document.getElementById('add-group-form-' + capId);
    if (!form) return;

    // پاک کردن فیلدها
    var messengerEl = document.getElementById('group-messenger-' + capId);
    var linkEl      = document.getElementById('group-link-' + capId);
    if (messengerEl) messengerEl.value = '';
    if (linkEl)      linkEl.value      = '';

    // برگرداندن دکمه به حالت «افزودن»
    var btn = form.querySelector('button');
    btn.textContent = 'افزودن';
    btn.className   = 'ta-btn ta-btn-primary ta-btn-sm';
    btn.onclick     = function () { taAddGroupSlot(capId); };

    // برگرداندن استایل فرم به حالت اولیه
    form.style.border  = '';
    form.style.padding = '';
    form.style.display = 'none';
};

    
    
     window.taSearchTAs = function () {
        var messenger = document.getElementById('ta-messenger')?.value;
        var gender    = document.getElementById('ta-gender')?.value;

        if (taCourseType === 'creative' && !messenger) {
            showMsg('ta-error', 'لطفاً پیام‌رسان را انتخاب کنید.', 'error');
            return;
        }
        if (!gender) {
            showMsg('ta-error', 'لطفاً جنسیت را انتخاب کنید.', 'error');
            return;
        }
        
        hideEl('ta-error');
        showEl('ta-loading');
        hideEl('ta-step-1');

        post({
            action:         'ta_get_available_tas',
            product_id:     taSystem.productId,
            messenger:      messenger || 'auto',
            student_gender: gender,
        }, function (res) {
            hideEl('ta-loading');

            if (!res.success || !res.data.tas.length) {
                showEl('ta-step-1');
                showMsg('ta-error', res.data?.message || 'استادیاری با این مشخصات یافت نشد.', 'error');
                return;
            }

            var html = '';
            res.data.tas.forEach(function (ta) {
                html += '<div class="ta-ta-card">' +
                    '<div><div class="ta-ta-card-name">' + ta.name + '</div>' +
                    '<div class="ta-ta-card-info">ظرفیت آزاد: ' + ta.remaining + '</div></div>' +
                    '<button class="ta-btn ta-btn-primary" onclick="taSelectTA(' + ta.id + ')">انتخاب</button>' +
                '</div>';
            });
            setHtml('ta-ta-list', html);
            showEl('ta-step-2');
        });
    };

    window.taBackToStep1 = function () {
        hideEl('ta-step-2');
        showEl('ta-step-1');
    };


       //-------------------------
    // تخصیص استادیار دوره حرفه‌ای
    //-------------------------
    $(document).on('click', '.ta-assign-professional', function (e) {
        e.preventDefault();
        var $btn = $(this);
        var productId = $btn.data('product-id');
        var taId = $btn.data('ta-id');

        if (taSystem.isLoggedIn == 0) {
            window.location.href = taSystem.loginUrl;
            return;
        }

        $btn.prop('disabled', true).css('opacity', '0.6').text('در حال بررسی و تخصیص...');

        $.ajax({
            url: taSystem.ajaxUrl,
            type: 'POST',
            data: {
                action: 'ta_assign_professional',
                product_id: productId,
                ta_id: taId,
                nonce: taSystem.nonce
            },
            success: function(response) {
                if (response.success) {
                    // اگر بک‌اند لینک گروه را برگرداند، کاربر را به آنجا هدایت می‌کنیم
                    if (response.data.redirect && response.data.redirect !== '') {
                        window.location.href = response.data.redirect;
                    } else {
                        alert(response.data.message || 'با موفقیت تخصیص یافتید.');
                        location.reload(); 
                    }
                } else {
                    alert(response.data.message || 'خطا در تخصیص استادیار.');
                    $btn.prop('disabled', false).css('opacity', '1').text('تخصیص مجدد به استادیار');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور. لطفاً مجدداً تلاش کنید.');
                $btn.prop('disabled', false).css('opacity', '1').text('تخصیص مجدد به استادیار');
            }
        });
    });

//-------------------------
$(document).on('click', '.ta-assign-critique', function (e) {
    e.preventDefault();
    var $btn = $(this);
    var productId = $btn.data('product-id');

    // چاپ اطلاعات اولیه در کنسول
    console.log("=== شروع عملیات پیوستن به نقد اثر ===");
    console.log("شناسه محصول (ProductID):", productId);
    console.log("کد امنیتی (Nonce):", taSystem.nonce);
    console.log("آدرس ای‌جکس (Ajax URL):", taSystem.ajaxUrl);

    if (taSystem.isLoggedIn == 0) {
        console.warn("کاربر لاگین نیست، هدایت به صفحه لاگین.");
        window.location.href = taSystem.loginUrl;
        return;
    }

    $btn.prop('disabled', true).css('opacity', '0.6').text('در حال ارتباط با سرور...');
   
    $.ajax({
    url: ajax,
    type: 'POST',
    data: {
        action: 'ta_assign_critique',
        product_id: productId,
        nonce: taSystem.nonce  // 👈 این خط باید حتماً اضافه شود
    },
            success: function(response) {
            console.log("✅ پاسخ موفقیت‌آمیز (Success) از سرور دریافت شد:", response);
            if (response.success) {
                alert(response.data.message || 'با موفقیت به نقد اثر پیوستید.');
                if(response.data.redirect) {
                    window.location.href = response.data.redirect;
                } else {
                    location.reload();
                }
            } else {
                console.warn("⚠️ سرور پاسخ داد اما عملیات ناموفق بود. پیام سرور:", response.data);
                alert(response.data.message || 'خطا در پیوستن به نقد اثر.');
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            // چاپ دقیق جزئیات خطا در کنسول
            console.error("❌ === خطا در درخواست AJAX ===");
            console.error("کد وضعیت HTTP (Status):", jqXHR.status);
            console.error("نوع خطا (textStatus):", textStatus);
            console.error("خطای پرتاب شده (errorThrown):", errorThrown);
            console.error("پاسخ خام سرور (responseText) که معمولاً حاوی خطای PHP است:", jqXHR.responseText);
            
            alert('خطا در برقراری ارتباط با سرور. لطفاً دکمه F12 را بزنید و تب Console را بررسی کنید.');
        },
        complete: function() {
            console.log("=== پایان درخواست AJAX ===");
            $btn.prop('disabled', false).css('opacity', '1').text('🔗 پیوستن به نقد اثر');
        }
    });
});








    // ─────────────────────────────────────────────────────────────────────────
    // صفحه محصول — انتخاب استادیار
    // ─────────────────────────────────────────────────────────────────────────
       window.taSelectTA = function (taId, customLink = '') {
        var messenger = document.getElementById('ta-messenger')?.value || 'auto';
        var gender    = document.getElementById('ta-gender')?.value;

        if (!gender) {
            showMsg('ta-error', 'لطفاً جنسیت را انتخاب کنید.', 'error');
            return;
        }

        hideEl('ta-step-2');
        showEl('ta-loading');

        var actionName = taCourseType === 'creative' ? 'ta_assign_creative' : 'ta_assign_with_group';

        var params = {
            action:         actionName,
            product_id:     taSystem.productId,
            ta_id:          taId,
            messenger:      messenger,
            student_gender: gender,
            custom_group_link: customLink // ارسال لینک در صورت وجود
        };

        post(params, function (res) {
            hideEl('ta-loading');

            if (!res.success) {
                // اگر بک‌اند درخواست لینک کرد (نیاز به لینک اختصاصی)
                if (res.data && res.data.needs_link) {
                    var msgName = 'پیام‌رسان';
                    if (messenger === 'telegram') msgName = 'تلگرام';
                    else if (messenger === 'bale') msgName = 'بله';
                    else if (messenger === 'eitaa') msgName = 'ایتا';

                    // فرم اینلاین دریافت لینک
                    var formHtml = `
                        <div id="ta-custom-link-box" style="margin-bottom: 20px; padding: 15px; border: 2px dashed #0073aa; border-radius: 8px; background: #f0f8ff; text-align: center;">
                            <p style="margin-bottom: 10px; font-weight: bold; color: #d9534f;">${res.data.message}</p>
                            <label style="display: block; margin-bottom: 10px; font-weight: bold;">لینک گروه ${msgName} خود را وارد کنید:</label>
                            <input type="text" id="ta-custom-link-input" style="width: 100%; padding: 8px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; text-align: left;" placeholder="https://..." dir="ltr">
                            <button type="button" class="ta-btn ta-btn-primary" onclick="window.taSubmitCustomLink('${taId}')">ثبت لینک و تایید</button>
                            <button type="button" class="ta-btn" onclick="window.taCancelCustomLink()" style="margin-right: 5px;">انصراف</button>
                        </div>
                    `;

                    showEl('ta-step-2');
                    
                    var existingBox = document.getElementById('ta-custom-link-box');
                    if (existingBox) existingBox.remove();
                    
                    hideEl('ta-ta-list');
                    
                    var step2 = document.getElementById('ta-step-2');
                    step2.insertAdjacentHTML('afterbegin', formHtml);
                    
                    return;
                }

                showEl('ta-step-2');
                showMsg('ta-error', res.data?.message || 'خطا در ثبت استادیار.', 'error');
                return;
            }

            if (res.data?.redirect) {
                window.location.href = res.data.redirect;
            } else if (res.data?.group_link) {
                window.location.href = res.data.group_link;
            } else {
                showMsg('ta-success', res.data?.message || 'استادیار با موفقیت ثبت شد.', 'success');
            }
        });
    };

    window.taSubmitCustomLink = function(taId) {
        var linkInput = document.getElementById('ta-custom-link-input');
        var link = linkInput ? linkInput.value.trim() : '';
        
        if (!link) {
            showMsg('ta-error', 'لطفاً لینک گروه را وارد کنید.', 'error');
            return;
        }
        
        var box = document.getElementById('ta-custom-link-box');
        if (box) box.remove();
        showEl('ta-ta-list');
        hideEl('ta-error');
        
        // فراخوانی مجدد با لینک جدید
        window.taSelectTA(taId, link);
    };

    window.taCancelCustomLink = function() {
        var box = document.getElementById('ta-custom-link-box');
        if (box) box.remove();
        showEl('ta-ta-list');
        hideEl('ta-error');
    };

    // ─────────────────────────────────────────────────────────────────────────
    // تعیین سطح — آپلود فایل
    // ─────────────────────────────────────────────────────────────────────────

    window.taSubmitLevelFile = function () {
        var taId     = document.getElementById('ta-level-ta-id')?.value;
        var fileEl   = document.getElementById('ta-level-file');

        if (!taId)               { showMsg('ta-level-error', 'استادیار تعیین سطح را انتخاب کنید.', 'error'); return; }
        if (!fileEl?.files[0])   { showMsg('ta-level-error', 'فایل را انتخاب کنید.', 'error'); return; }

        var fd = new FormData();
        fd.append('action',     'ta_submit_level_file');
        fd.append('product_id', taSystem.productId);
        fd.append('ta_id',      taId);
        fd.append('ta_level_file', fileEl.files[0]);

        hideEl('ta-level-error');
        postForm(fd, function (res) {
            if (res.success) {
                showMsg('ta-level-success', '✅ ' + res.data.message, 'success');
            } else {
                showMsg('ta-level-error', res.data?.message || 'خطا.', 'error');
            }
        });
    };

    // تعیین سطح — ثبت لینک گروه
    window.taSubmitGroupLink = function () {
        var link      = document.getElementById('ta-group-link-input')?.value;
        var messenger = document.getElementById('ta-group-messenger')?.value;

        if (!link) { showMsg('ta-group-error', 'لینک گروه را وارد کنید.', 'error'); return; }

        post({
            action:     'ta_submit_level_group',
            product_id: taSystem.productId,
            group_link: link,
            messenger:  messenger,
        }, function (res) {
            if (res.success) {
                showMsg('ta-group-success', '✅ ' + res.data.message, 'success');
            } else {
                showMsg('ta-group-error', res.data?.message || 'خطا.', 'error');
            }
        });
    };

    // ─────────────────────────────────────────────────────────────────────────
    // داشبورد استادیار
    // ─────────────────────────────────────────────────────────────────────────

    // ── ظرفیت ──
    window.taSaveCapacity = function () {
        var term   = document.getElementById('cap-term')?.value;
        var course = document.getElementById('cap-course')?.value;
        var gender = document.getElementById('cap-gender')?.value;
        var total  = document.getElementById('cap-total')?.value;

        if (!term || !course || !gender || !total) {
            showMsg('cap-result', 'همه فیلدها را پر کنید.', 'error');
            return;
        }

        post({
            action:          'ta_save_capacity',
            term_id:         term,
            course_type:     course,
            student_gender:  gender,
            total_capacity:  total,
        }, function (res) {
            showMsg('cap-result', res.data?.message || (res.success ? 'ذخیره شد.' : 'خطا.'), res.success ? 'success' : 'error');
            if (res.success) { setTimeout(function() { location.reload(); }, 1200); }
        });
    };

    // ── گروه ──
    window.taShowAddGroup = function (capId) {
        var formEl = document.getElementById('add-group-form-' + capId);
        if (formEl) formEl.style.display = formEl.style.display === 'none' ? '' : 'none';
    };

    window.taAddGroupSlot = function (capId) {
        var messenger = document.getElementById('group-messenger-' + capId)?.value;
        var link      = document.getElementById('group-link-' + capId)?.value;

        if (!link) { alert('لینک گروه را وارد کنید.'); return; }

        post({
            action:          'ta_add_group_slot',
            capacity_id:     capId,
            messenger_type:  messenger,
            group_link:      link,
        }, function (res) {
            if (res.success) { location.reload(); }
            else { alert(res.data?.message || 'خطا.'); }
        });
    };

    // ── نمره ──
    window.taShowGradeForm = function (studentId, productId, courseType) {
        showEl('grade-form-' + studentId + '-' + productId);
    };
    window.taHideGradeForm = function (studentId, productId) {
        hideEl('grade-form-' + studentId + '-' + productId);
    };

    window.taSubmitGrade = function (studentId, productId) {
    var grade        = document.getElementById('grade-select-' + studentId + '-' + productId)?.value;
    var notes        = document.getElementById('grade-notes-'  + studentId + '-' + productId)?.value;
    var assignmentId = document.getElementById('assignment-id-' + studentId + '-' + productId)?.value;
    var markComplete = document.getElementById('grade-complete-' + studentId + '-' + productId)?.checked ? 1 : 0;

    $.ajax({
        url: taSystem.ajaxUrl,
        type: 'POST',
        dataType: 'json',
        data: {
            action:        'ta_grade_student',
            nonce:         taSystem.nonce,
            student_id:    studentId,
            product_id:    productId,
            grade:         grade,
            notes:         notes,
            assignment_id: assignmentId,
            mark_complete: markComplete,
        },
        success: function (response) {
            if (response.success) {
                location.reload();
            } else {
                alert(response.data?.message || 'خطا در ثبت نمره.');
            }
        },
        error: function (jqXHR, textStatus, errorThrown) {
            console.error('خطا در ثبت نمره:', textStatus, errorThrown);
        }
    });
};

     
    // ── لیست سیاه ──
    window.taBlacklist = function (studentId, studentName) {
        if (!confirm('آیا می‌خواهید ' + studentName + ' را به لیست سیاه اضافه کنید؟')) return;
        var reason = prompt('دلیل (اختیاری):') || '';

        post({
            action:     'ta_blacklist_student',
            student_id: studentId,
            reason:     reason,
        }, function (res) {
            if (res.success) { alert('✅ ' + res.data.message); location.reload(); }
            else { alert('❌ ' + (res.data?.message || 'خطا.')); }
        });
    };

    window.taRemoveBlacklist = function (studentId) {
        if (!confirm('از لیست سیاه حذف شود؟')) return;

        post({
            action:     'ta_remove_from_blacklist',
            student_id: studentId,
        }, function (res) {
            if (res.success) { location.reload(); }
            else { alert(res.data?.message || 'خطا.'); }
        });
    };








// متغیر سراسری برای ذخیره ID ظرفیت در حال ویرایش
var editingCapacityId = null;

// بارگذاری ظرفیت برای ویرایش
window.taLoadCapacityForEdit = function(capId, termId, courseType, gender, totalCap, messenger) {
    editingCapacityId = capId;
    
    document.getElementById('cap-term').value = termId;
    document.getElementById('cap-course').value = courseType;
    document.getElementById('cap-gender').value = gender;
    document.getElementById('cap-total').value = totalCap;
     // مقداردهی پیام‌رسان برای ویرایش
    var msgField = document.getElementById('cap-messenger');
    if (msgField) {
        msgField.value = messenger || 'both';
    }

    var form = document.getElementById('ta-capacity-form');
    var btn = form.querySelector('button');
    
    form.classList.add('ta-form-edit-mode');
    btn.textContent = 'ویرایش ظرفیت';
    btn.classList.add('ta-btn-edit-mode');
    btn.onclick = taSaveOrUpdateCapacity;
    
    // اضافه کردن دکمه لغو
    if (!document.getElementById('ta-cancel-edit-btn')) {
        var cancelBtn = document.createElement('button');
        cancelBtn.id = 'ta-cancel-edit-btn';
        cancelBtn.className = 'ta-btn ta-btn-cancel';
        cancelBtn.textContent = 'لغو';
        cancelBtn.onclick = taCancelEdit;
        btn.parentElement.appendChild(cancelBtn);
    }
    
    form.scrollIntoView({ behavior: 'smooth', block: 'center' });
};

// لغو ویرایش
window.taCancelEdit = function() {
    editingCapacityId = null;
    
    var form = document.getElementById('ta-capacity-form');
    var btn = form.querySelector('button');
    
    form.classList.remove('ta-form-edit-mode');
    btn.textContent = 'ذخیره ظرفیت';
    btn.classList.remove('ta-btn-edit-mode');
    btn.onclick = taSaveOrUpdateCapacity;
    
    var cancelBtn = document.getElementById('ta-cancel-edit-btn');
    if (cancelBtn) cancelBtn.remove();
    
    document.getElementById('cap-total').value = '';
     // ریست کردن پیام‌رسان
    var msgField = document.getElementById('cap-messenger');
    if (msgField) {
        msgField.value = 'both';
    }
};

// ذخیره یا ویرایش ظرفیت
window.taSaveOrUpdateCapacity = function() {
    var term = document.getElementById('cap-term')?.value;
    var course = document.getElementById('cap-course')?.value;
    var gender = document.getElementById('cap-gender')?.value;
    var total = document.getElementById('cap-total')?.value;
    var messenger = document.getElementById('cap-messenger')?.value || 'both'; // دریافت مقدار پیام‌رسان

    if (!term || !course || !gender || !total|| !messenger) {
        showMsg('cap-result', 'همه فیلدها را پر کنید.', 'error');
        return;
    }

    var data = {
        term_id: term,
        course_type: course,
        student_gender: gender,
        total_capacity: total,
        messenger: messenger // اضافه شدن پیام‌رسان به دیتای ارسالی

    };

    if (editingCapacityId) {
        data.action = 'ta_update_capacity';
        data.capacity_id = editingCapacityId;
    } else {
        data.action = 'ta_save_capacity';
    }

    post(data, function(res) {
        showMsg(
            'cap-result',
            res.data?.message || (res.success ? 'عملیات موفق.' : 'خطا.'),
            res.success ? 'success' : 'error'
        );
        if (res.success) {
            setTimeout(function() { location.reload(); }, 1000);
        }
    });
};

// حذف ظرفیت
window.taDeleteCapacity = function(capId) {
    if (!confirm('آیا از حذف این ظرفیت اطمینان دارید؟')) return;

    post({
        action: 'ta_delete_capacity',
        capacity_id: capId,
    }, function(res) {
        showMsg(
            'cap-result',
            res.data?.message || (res.success ? 'حذف شد.' : 'خطا.'),
            res.success ? 'success' : 'error'
        );
        if (res.success) {
            setTimeout(function() { location.reload(); }, 1000);
        }
    });
};

// ویرایش گروه
window.taEditGroup = function (groupId, capId, messenger, link) {
    var form = document.getElementById('add-group-form-' + capId);
    if (!form) return;

    // پر کردن فیلدها
    document.getElementById('group-messenger-' + capId).value = messenger;
    document.getElementById('group-link-' + capId).value = link || '';

    // تغییر دکمه به حالت ویرایش
    var btn = form.querySelector('button');
    btn.textContent = 'ذخیره ویرایش';
    btn.className = 'ta-btn ta-btn-warning ta-btn-sm';
    btn.onclick = function () { taUpdateGroupSlot(groupId, capId); };

    // نمایش فرم
    form.style.display = '';
    form.style.border = '2px solid #f39c12';
    form.style.borderRadius = '6px';
    form.style.padding = '10px';
};


window.taUpdateGroupSlot = function (groupId, capId) {
    var messenger = document.getElementById('group-messenger-' + capId)?.value;
    var link      = document.getElementById('group-link-' + capId)?.value;

    post({
        action:         'ta_update_group_slot',
        group_id:       groupId,
        messenger_type: messenger,
        group_link:     link,
    }, function (res) {
        showMsg(
            'cap-result',
            res.data?.message || (res.success ? 'گروه ویرایش شد.' : 'خطا.'),
            res.success ? 'success' : 'error'
        );
        if (res.success) {
            // ریست فرم به حالت افزودن
            var form = document.getElementById('add-group-form-' + capId);
            var btn  = form.querySelector('button');
            btn.textContent = 'افزودن';
            btn.className   = 'ta-btn ta-btn-primary ta-btn-sm';
            btn.onclick     = function () { taAddGroupSlot(capId); };
            form.style.border  = '';
            form.style.padding = '';
            form.style.display = 'none';
            setTimeout(() => location.reload(), 800);
        }
    });
};


// حذف گروه
window.taDeleteGroup = function(groupId) {
    if (!confirm('آیا از حذف این گروه اطمینان دارید؟')) return;

    post({
        action: 'ta_delete_group_slot',
        group_id: groupId,
    }, function(res) {
        showMsg(
            'cap-result',
            res.data?.message || (res.success ? 'گروه حذف شد.' : 'خطا.'),
            res.success ? 'success' : 'error'
        );
        if (res.success) {
            setTimeout(function() { location.reload(); }, 1000);
        }
    });
};

// تغییر تابع اصلی ذخیره
window.taSaveCapacity = taSaveOrUpdateCapacity;







/**
 * باز کردن فرم ویرایش assignment (دوره‌های غیرخلاق)
 */
function taEditAssignment(assignmentId, messenger, link) {
    document.getElementById('edit-assignment-id').value = assignmentId;

    const messengerEl = document.getElementById('edit-assignment-messenger');
    if (messengerEl) messengerEl.value = messenger;

    const linkEl = document.getElementById('edit-assignment-link');
    if (linkEl) linkEl.value = link;

    document.getElementById('edit-assignment-form').style.display = 'block';
}

/**
 * ذخیره تغییرات assignment (پیام‌رسان + لینک گروه)
 */
function taSaveAssignment() {
    const assignmentId = document.getElementById('edit-assignment-id').value;
    const messenger    = document.getElementById('edit-assignment-messenger').value;
    const groupLink    = document.getElementById('edit-assignment-link').value;

    jQuery.post(taSystem.ajaxUrl, {
        action:        'ta_update_assignment_group',
        nonce:         taSystem.nonce,
        assignment_id: assignmentId,
        messenger:     messenger,
        group_link:    groupLink,
    }, function(res) {
        if (res.success) {
            alert(res.data.message || 'ذخیره شد.');
            setTimeout(() => location.reload(), 800);
        } else {
            alert(res.data.message || 'خطا در ذخیره.');
        }
    });
}

// ── انتخاب همه ردیف‌ها ──────────────────────────────────────────
window.taToggleSelectAll = function (checked) {
    document.querySelectorAll('.ta-row-check').forEach(function (cb) {
        cb.checked = checked;
    });
    taOnRowCheck();
};

// ── به‌روزرسانی شمارنده و نمایش/پنهان دکمه‌های bulk ──────────────
window.taOnRowCheck = function () {
    var selected = document.querySelectorAll('.ta-row-check:checked');
    var count    = selected.length;
    var toolbar  = document.getElementById('ta-bulk-actions');
    var counter  = document.getElementById('ta-selected-count');

    if (toolbar)  toolbar.style.display  = count > 0 ? 'flex' : 'none';
    if (counter)  counter.textContent    = count + ' انتخاب‌شده';
};

// ── تغییر وضعیت گروهی ───────────────────────────────────────────
window.taBulkUpdateStatus = function (newStatus) {
    var selected = document.querySelectorAll('.ta-row-check:checked');
    if (selected.length === 0) return;

    var ids = Array.from(selected).map(function (cb) { return cb.dataset.id; });
    var label = newStatus === 'completed' ? 'تکمیل‌شده' : 'فعال';

    if (!confirm('وضعیت ' + ids.length + ' تخصیص به «' + label + '» تغییر کند؟')) return;

    $.ajax({
        url: taSystem.ajaxUrl,
        type: 'POST',
        dataType: 'json',
        data: {
            action:     'ta_bulk_update_assignment_status',
            nonce:      taSystem.nonce,
            ids:        ids,
            new_status: newStatus,
        },
        success: function (response) {
            if (response.success) {
                location.reload();
            } else {
                alert(response.data?.message || 'خطا در تغییر وضعیت.');
            }
        },
        error: function () {
            alert('خطا در ارتباط با سرور.');
        }
    });
};


/**
 * هندلر دکمه «انتخاب» در صفحه تخصیص بر اساس ظرفیت (پنل ادمین)
 */
/**
 * هندلر دکمه «انتخاب» در صفحه تخصیص بر اساس ظرفیت (پنل ادمین)
 */
jQuery(document).on('click', '.ta-capacity-assign-btn', function (e) {
    e.preventDefault();
    var $btn = jQuery(this);
    var $row = $btn.closest('tr, .ta-capacity-row');

    var orderId       = $btn.data('order-id');
    var taId          = $btn.data('ta-id');
    var capacityId    = $btn.data('capacity-id');
    var messengerType = $btn.data('messenger') || $row.find('.ta-messenger-select').val();

    var data = {
        action:         'ta_admin_assign_by_capacity',
        nonce:          ta_system_vars.nonce,
        order_id:       orderId,
        ta_user_id:     taId,
        capacity_id:    capacityId,
        messenger_type: messengerType
    };

    $btn.prop('disabled', true).text('در حال پردازش...');

    jQuery.post(ta_system_vars.ajax_url, data, function (res) {

        if (res.success) {
            // بررسی needs_link → نمایش فرم اینلاین دریافت لینک
            if (res.data && res.data.needs_link) {
                taShowAdminLinkForm($btn, $row, res.data.message, orderId, taId, capacityId, messengerType);
                return;
            }

            alert(res.data.message || '✅ تخصیص انجام شد.');
            $btn.prop('disabled', true).text('تخصیص‌شده ✅').addClass('ta-assigned');
            if (res.data.group_link) {
                $row.find('.ta-group-link-cell').html(
                    '<a href="' + res.data.group_link + '" target="_blank">مشاهده گروه</a>'
                );
            }
        } else {
            // بررسی needs_link در حالت error هم (چون assign_creative با success=false برمی‌گرداند)
            if (res.data && res.data.needs_link) {
                taShowAdminLinkForm($btn, $row, res.data.message, orderId, taId, capacityId, messengerType);
                return;
            }

            alert(res.data.message || '⚠️ خطا در تخصیص');
            $btn.prop('disabled', false).text('انتخاب');
        }

    }).fail(function () {
        alert('⚠️ خطا در ارتباط با سرور');
        $btn.prop('disabled', false).text('انتخاب');
    });
});

/**
 * نمایش فرم اینلاین دریافت لینک گروه (مشابه صفحه دانشجو)
 */
function taShowAdminLinkForm($btn, $row, message, orderId, taId, capacityId, messengerType) {
    // حذف فرم قبلی اگر وجود داشت
    jQuery('.ta-admin-link-box').remove();

    var msgName = 'پیام‌رسان';
    if (messengerType === 'telegram') msgName = 'تلگرام';
    else if (messengerType === 'bale') msgName = 'بله';
    else if (messengerType === 'eitaa') msgName = 'ایتا';

    var formHtml = '<div class="ta-admin-link-box" style="margin:10px 0;padding:15px;border:2px dashed #0073aa;border-radius:8px;background:#f0f8ff;text-align:center;">'
        + '<p style="margin-bottom:10px;font-weight:bold;color:#d9534f;">' + (message || '⚠️ لطفا لینک گروه را وارد کنید.') + '</p>'
        + '<label style="display:block;margin-bottom:10px;font-weight:bold;">لینک گروه ' + msgName + ' را وارد کنید:</label>'
        + '<input type="text" class="ta-admin-link-input" style="width:80%;padding:8px;margin-bottom:15px;border:1px solid #ccc;border-radius:4px;text-align:left;" placeholder="https://..." dir="ltr">'
        + '<br>'
        + '<button type="button" class="button button-primary ta-admin-link-submit">ثبت لینک و تایید</button> '
        + '<button type="button" class="button ta-admin-link-cancel" style="margin-right:5px;">انصراف</button>'
        + '</div>';

    // نمایش فرم بعد از ردیف یا دکمه
    $row.after('<tr class="ta-admin-link-row"><td colspan="99">' + formHtml + '</td></tr>');

    $btn.prop('disabled', true).text('در انتظار لینک...');

    // هندلر دکمه «ثبت لینک و تایید»
    jQuery(document).one('click', '.ta-admin-link-submit', function () {
        var $form = jQuery(this).closest('.ta-admin-link-box');
        var link = $form.find('.ta-admin-link-input').val().trim();

        if (!link || link.indexOf('http') !== 0) {
            alert('لطفاً یک لینک معتبر وارد کنید.');
            return;
        }

        jQuery(this).prop('disabled', true).text('در حال ارسال...');

        jQuery.post(ta_system_vars.ajax_url, {
            action:            'ta_admin_assign_with_custom_link',
            nonce:             ta_system_vars.nonce,
            order_id:          orderId,
            ta_user_id:        taId,
            capacity_id:       capacityId,
            messenger_type:    messengerType,
            custom_group_link: link
        }, function (res) {
            jQuery('.ta-admin-link-row').remove();

            if (res.success) {
                alert(res.data.message || '✅ تخصیص انجام شد.');
                $btn.prop('disabled', true).text('تخصیص‌شده ✅').addClass('ta-assigned');
                if (res.data.group_link) {
                    $row.find('.ta-group-link-cell').html(
                        '<a href="' + res.data.group_link + '" target="_blank">مشاهده گروه</a>'
                    );
                }
            } else {
                alert(res.data.message || '⚠️ خطا در تخصیص');
                $btn.prop('disabled', false).text('انتخاب');
            }
        }).fail(function () {
            jQuery('.ta-admin-link-row').remove();
            alert('⚠️ خطا در ارتباط با سرور');
            $btn.prop('disabled', false).text('انتخاب');
        });
    });

    // هندلر دکمه «انصراف»
    jQuery(document).one('click', '.ta-admin-link-cancel', function () {
        jQuery('.ta-admin-link-row').remove();
        $btn.prop('disabled', false).text('انتخاب');
    });
}

/**
 * ارسال تخصیص با لینک سفارشی (برای دوره خلاق بدون گروه آزاد)
 */
function taCapacityAssignWithLink(originalData, groupLink, $btn) {
    var data = jQuery.extend({}, originalData, {
        action:            'ta_admin_assign_with_custom_link',
        custom_group_link: groupLink
    });

    jQuery.post(ta_system_vars.ajax_url, data, function (res) {
        if (res.success) {
            alert(res.data.message || '✅ تخصیص انجام شد.');
            $btn.prop('disabled', true).text('تخصیص‌شده ✅');
        } else {
            alert(res.data.message || '⚠️ خطا در تخصیص');
            $btn.prop('disabled', false).text('انتخاب');
        }
    }).fail(function () {
        alert('⚠️ خطا در ارتباط با سرور');
        $btn.prop('disabled', false).text('انتخاب');
    });
}



})(jQuery);
