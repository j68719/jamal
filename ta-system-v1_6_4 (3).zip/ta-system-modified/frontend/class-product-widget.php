<?php
defined( 'ABSPATH' ) || exit;

/**
 * ویجت انتخاب استادیار
 * شورت‌کد: [ta_select_assistant]
 * در صفحه محصول قرار دهید
 */
class TA_Product_Widget {

    public function __construct() {
        add_shortcode( 'ta_select_assistant', [ $this, 'render_shortcode' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
    }

    public function enqueue_assets(): void {
        global $post;
        if ( ! $post ) return;

        wp_enqueue_style(
            'ta-system',
            TA_SYSTEM_URL . 'assets/css/ta-system.css',
            [],
            TA_SYSTEM_VERSION
        );
        wp_enqueue_script(
            'ta-system',
            TA_SYSTEM_URL . 'assets/js/ta-system.js',
            [ 'jquery' ],
            TA_SYSTEM_VERSION,
            true
        );

        $product_id = get_the_ID();

        wp_localize_script( 'ta-system', 'taSystem', [
            'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
            'nonce'      => wp_create_nonce( 'ta_product_nonce' ),
            'productId'  => $product_id,
            'isLoggedIn' => is_user_logged_in() ? 1 : 0,
            'loginUrl'   => wp_login_url( get_permalink() ),
        ] );
    }

    public function render_shortcode( array $atts ): string {
        $atts = shortcode_atts( [
            'product_id' => 0,
        ], $atts );

        $product_id = (int) $atts['product_id'] ?: get_the_ID();

        if ( ! $product_id ) {
            return '';
        }

        ob_start();
        $this->render( $product_id );
        return ob_get_clean();
    }

    private function render( int $product_id ): void {
        $settings = TA_Eligibility::get_product_settings( $product_id );

        if ( ! $settings ) {
            return;
        }

        $uid = get_current_user_id();

        if ( ! $uid ) {
            echo '<div class="ta-widget ta-not-logged-in">';
            echo '<p>برای ورود به دوره باید ثبت نام کنید (اگر ثبت نام کرده اید وارد سایت شوید).</p>';
            echo do_shortcode('[mreeir_login_register]');
            echo '</div>'; 
            return;
        }

        if ( $product_id !== get_the_ID() ) {
            echo '<script>if(typeof taSystem !== "undefined") taSystem.productId = ' . $product_id . ';</script>';
        }

        $check = TA_Eligibility::check( $uid, $product_id );

        echo '<div class="ta-widget" id="ta-product-widget">';
        
        
        
        // تغییر عنوان بر اساس نوع دوره
        if( $settings->course_type === 'professional' ) {
            echo '<div class="ta-widget-header"><h3>🌟 ورود به دوره حرفه‌ای</h3></div>';
        }
        elseif( $settings->course_type === 'critique' ) {
          echo '<div class="ta-widget-header"><h3>📝 ورود به دوره نقد اثر</h3></div>'; // اضافه شدن این بخش
        } 
        else {
          echo '<div class="ta-widget-header"><h3>👩‍🏫 انتخاب استادیار</h3></div>';
        }
        
        
        
        
        
        

        if ( $check['path'] === 'blocked' && TA_Eligibility::already_assigned( $uid, $product_id ) ) {
            $this->render_already_assigned( $uid, $product_id );
            echo '</div>';
            return;
        }

        if ( ! $check['eligible'] ) {
            echo '<div class="ta-message ta-message-error">' . esc_html( $check['message'] ) . '</div>';
        } elseif ( $check['path'] === 'normal' ) {
            $this->render_normal_flow( $settings, $uid, $product_id );
        } elseif ( $check['path'] === 'level_assess' ) {
            $this->render_level_assess_flow( $settings, $uid, $product_id );
        } elseif ( $check['path'] === 'level_assess_submit_group' ) {
            $this->render_level_assess_submit_group( $uid, $product_id );
        } elseif ( $check['path'] === 'level_assess_done' ) {
            echo '<div class="ta-message ta-message-success">✅ درخواست تعیین سطح تأیید شد. منتظر ورود استادیار به گروه باشید.</div>';
        } elseif ( $check['path'] === 'show_link' ) {
            $this->render_show_link( $settings, $uid, $product_id );
        }
        elseif ( $check['path'] === 'show_critique_link' ) {
            $this->render_show_critique_link( $settings, $uid, $product_id );
        }
        elseif ( $check['path'] === 'assign_professional' ) { // مسیر جدید برای دوره حرفه ای
        $this->render_assign_professional_flow( $settings, $uid, $product_id );
        }

        echo '</div>';
    }

private function render_already_assigned( int $uid, int $product_id ): void {
    $assignment = TA_Assignment::get_assignment( $uid, $product_id );
    if ( ! $assignment ) return;
    
    // دریافت تنظیمات محصول برای تشخیص نوع دوره
    $settings = TA_Eligibility::get_product_settings( $product_id );

    echo '<div class="ta-message ta-message-success">';
    echo '<p>✅ استادیار شما: <strong>' . esc_html( $assignment->ta_name ?? '' ) . '</strong></p>';

    if ( ! empty( $assignment->group_link ) ) {
        // تغییر لیبل لینک در صورتی که دوره نقد اثر باشد
        $link_label = ( $settings && $settings->course_type === 'critique' ) ? 'لینک دوره نقد اثر' : 'ورود به گروه';
        
        echo '<p><a href="' . esc_url( $assignment->group_link ) . '" class="ta-btn ta-btn-primary" target="_blank">' . esc_html( $link_label ) . '</a></p>';
    }

    echo '</div>';
}

  /*  private function render_already_assigned( int $uid, int $product_id ): void {
        $assignment = TA_Assignment::get_assignment( $uid, $product_id );
        if ( ! $assignment ) return;
        echo '<div class="ta-message ta-message-success">';
        echo '<p>✅ استادیار شما: <strong>' . esc_html( $assignment->ta_name ) . '</strong></p>';
        if ( $assignment->group_link ) {
            echo '<p><a href="' . esc_url( $assignment->group_link ) . '" class="ta-btn ta-btn-primary" target="_blank">ورود به گروه</a></p>';
        }
        echo '</div>';
    }
*/
   private function render_show_link( object $settings, int $uid, int $product_id ): void {
    echo '<div class="ta-message ta-message-success" style="text-align: center; padding: 20px;">';

    // ── عنوان و توضیح بر اساس نوع وضعیت ──────────────────────────────
    $already = TA_Eligibility::already_assigned( $uid, $product_id );

    if ( $already ) {
        // هنرجو قبلاً تخصیص دارد
        echo '<h4 style="margin-bottom:15px; color:#2e7d32;">✅ شما در این دوره استادیار دارید</h4>';
        echo '<p>برای ورود به دوره حرفه‌ای از لینک زیر استفاده کنید.</p>';
    } else {
        // هنرجو مجوز دارد اما هنوز تخصیص نگرفته (حالت آینده اگر نیاز شد)
        echo '<h4 style="margin-bottom:15px; color:#2e7d32;">✅ مجوز ورود به دوره حرفه‌ای صادر شد!</h4>';
        echo '<p>شما پیش‌نیازهای لازم برای شرکت در این دوره را با موفقیت گذرانده‌اید.</p>';
    }
    // ──────────────────────────────────────────────────────────────────

    if ( ! empty( $settings->pro_group_link ) ) {
        echo '<div style="margin-top:20px;">';
        echo '<a href="' . esc_url( $settings->pro_group_link ) . '" '
           . 'class="ta-btn ta-btn-primary" target="_blank" '
           . 'style="padding: 10px 20px; font-size: 16px;">'
           . '🔗 پیوستن به نویسندگی حرفه‌ای'   // ← متن تغییر کرد
           . '</a>';
        echo '</div>';
    } else {
        echo '<p class="ta-message ta-message-error" style="margin-top:15px;">'
           . 'لینک گروه برای این دوره هنوز توسط مدیر تنظیم نشده است.'
           . '</p>';
    }

    echo '</div>';
}

    
  private function render_show_critique_link( object $settings, int $uid, int $product_id ): void {
        echo '<div class="ta-message ta-message-success" style="text-align: center; padding: 20px;">';
        
         
        if ( ! empty( $settings->pro_group_link ) ) {
            echo '<div style="margin-top:20px;">';
           
            //echo '<a href="' . esc_url( $settings->pro_group_link ) . '" class="ta-btn ta-btn-primary" target="_blank" style="padding: 10px 20px; font-size: 16px;">🔗 پیوستن به گروه دوره</a>';
           
           echo '<button class="ta-btn ta-btn-primary ta-assign-critique" data-product-id="' . esc_attr( $product_id ) . '">
🔗 پیوستن به نقد اثر
</button>';


            echo '</div>';
        } else {
            echo '<p class="ta-message ta-message-error" style="margin-top:15px;">لینک گروه برای این دوره هنوز توسط مدیر تنظیم نشده است.</p>';
            
             

        }
        echo '</div>';
    }


 

      private function render_normal_flow( object $settings, int $uid, int $product_id ): void {
        ?>
        <div class="ta-step" id="ta-step-1">
           
            
            <?php if ( $settings->course_type === 'creative' ) : ?>
                <div class="ta-field-group">
                    <label>پیام‌رسان خود را انتخاب کنید:</label>
                    <select id="ta-messenger" class="ta-select">
                        <option value="">— انتخاب کنید —</option>
                        <option value="telegram">تلگرام</option>
                        <option value="bale">بله</option>
                        <option value="eitaa">ایتا</option>
                    </select>
                </div>
            <?php else : ?>
                <div class="ta-message ta-message-info" style="margin-bottom: 15px;">
                    سیستم به صورت خودکار اطلاعات پیام‌رسان و لینک گروه شما را از دوره پیش‌نیاز استخراج خواهد کرد.
                </div>
                <!-- فیلد مخفی برای جلوگیری از بروز خطا در جاوااسکریپت -->
                <input type="hidden" id="ta-messenger" value="auto">
            <?php endif; ?>

            
           <?php 
            // --- منطق جدید: واکشی جنسیت از پروفایل کاربر ---
$user_gender = get_user_meta( get_current_user_id(), 'student_gender', true );

if ( in_array( $user_gender, [ 'male', 'female' ], true ) ) : 
    // ترجمه مقدار برای نمایش به کاربر
    $gender_fa = ( $user_gender === 'male' ) ? 'آقا' : 'خانم';
?>
    <!-- باکس نمایش جنسیت فعلی همراه با دکمه ویرایش -->
    <div class="ta-field-group" id="ta-gender-display-box" style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
        <span style="font-size: 14px;">جنسیت شما: <strong><?= esc_html( $gender_fa ) ?></strong></span>
        <button type="button" id="ta-btn-edit-gender" style="background: none; border: none; cursor: pointer; color: #007cba; padding: 0; font-size: 13px; display: inline-flex; align-items: center; gap: 4px;">
            ✏️ ویرایش
        </button>
    </div>

    <!-- باکس انتخاب جنسیت (در حالت عادی مخفی است و با کلیک روی ویرایش ظاهر می‌شود) -->
    <div class="ta-field-group" id="ta-gender-select-box" style="display: none;">
        <label>جنسیت خود را وارد کنید:</label>
        <select id="ta-gender" class="ta-select" name="student_gender">
            <option value="male" <?php selected( $user_gender, 'male' ); ?>>آقا</option>
            <option value="female" <?php selected( $user_gender, 'female' ); ?>>خانم</option>
        </select>
    </div>

    <!-- اسکریپت ساده برای جابجایی بین حالت نمایش و ویرایش -->
    <script>
        document.getElementById('ta-btn-edit-gender').addEventListener('click', function(e) {
            e.preventDefault();
            // مخفی کردن متن و دکمه ویرایش
            document.getElementById('ta-gender-display-box').style.display = 'none';
            // نمایش دادن کادر انتخاب جنسیت
            document.getElementById('ta-gender-select-box').style.display = 'block';
        });
    </script>

<?php else : ?>
    <!-- اگر از قبل هیچ جنسیتی برای این هنرجو ذخیره نشده باشد -->
    <div class="ta-field-group">
        <label>جنسیت خود را وارد کنید:</label>
        <select id="ta-gender" class="ta-select" name="student_gender">
            <option value="">— انتخاب کنید —</option>
            <option value="male">آقا</option>
            <option value="female">خانم</option>
        </select>
    </div>
<?php endif; ?>

            
            
            
            
            <button class="ta-btn ta-btn-secondary" onclick="taSearchTAs()">🔍 جستجوی استادیار</button>
        </div>

        <div class="ta-step" id="ta-step-2" style="display:none">

            <div id="ta-ta-list"></div>
            <button class="ta-btn" onclick="taBackToStep1()">← بازگشت</button>
        </div>

        <div class="ta-step" id="ta-step-3" style="display:none">
            <div id="ta-success-message" class="ta-message ta-message-success"></div>
        </div>

        <div id="ta-loading" style="display:none" class="ta-loading">⏳ در حال جستجو...</div>
        <div id="ta-error"   style="display:none" class="ta-message ta-message-error"></div>

        <script>var taCourseType = '<?= esc_js( $settings->course_type ) ?>';</script>
        <?php
    }

 
    
    
    

    private function render_level_assess_flow( object $settings, int $uid, int $product_id ): void {
        $term_id         = (int) $settings->term_id;
        $level_assessors = $this->get_all_level_assessors( $term_id, $uid );
        ?>
        <div class="ta-level-assess-form">
            <div class="ta-message ta-message-info">
                📋 شما در دوره نویسندگی خلاق شرکت نکرده‌اید یا نمره قبولی دریافت نکرده‌اید.
                برای شرکت در این دوره باید تعیین سطح شوید.
            </div>
            <div class="ta-field-group">
                <label>انتخاب استادیار تعیین سطح:</label>
                <select id="ta-level-ta-id" class="ta-select">
                    <option value="">— انتخاب کنید —</option>
                    <?php foreach ( $level_assessors as $ta ) : ?>
                        <option value="<?= $ta->id ?>"><?= esc_html( $ta->ta_name ) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="ta-field-group">
                <label>بارگذاری فایل متنی (نمونه نوشته):</label>
                <input type="file" id="ta-level-file" accept=".pdf,.doc,.docx,.txt">
                <small>فرمت‌های مجاز: PDF، Word، TXT — حداکثر ۱۰ مگابایت</small>
            </div>
            <button class="ta-btn ta-btn-primary" onclick="taSubmitLevelFile()">📤 ارسال برای تعیین سطح</button>
        </div>
        <div id="ta-level-success" style="display:none" class="ta-message ta-message-success"></div>
        <div id="ta-level-error"   style="display:none" class="ta-message ta-message-error"></div>
        <?php
    }

    private function render_level_assess_submit_group( int $uid, int $product_id ): void {
        ?>
        <div class="ta-message ta-message-success">✅ تعیین سطح شما تأیید شد!</div>
        <div class="ta-field-group">
            <label>پیام‌رسان:</label>
            <select id="ta-group-messenger" class="ta-select">
                <option value="telegram">تلگرام</option>
                <option value="bale">بله</option>
                <option value="eitaa">ایتا</option>
            </select>
        </div>
        <div class="ta-field-group">
            <label>لینک گروه:</label>
            <input type="url" id="ta-group-link-input" class="ta-input" placeholder="https://t.me/...">
            <small>لینک گروهی که در آن عضو هستید. استادیار به این گروه اضافه خواهد شد.</small>
        </div>
        <button class="ta-btn ta-btn-primary" onclick="taSubmitGroupLink()">✅ ثبت لینک گروه</button>
        <div id="ta-group-success" style="display:none" class="ta-message ta-message-success"></div>
        <div id="ta-group-error"   style="display:none" class="ta-message ta-message-error"></div>
        <?php
    }

    private function get_all_level_assessors( int $term_id, int $student_id ): array {
        global $wpdb;
        $ta_table  = TA_Database::table( 'assistants' );
        $cap_table = TA_Database::table( 'capacities' );
        $bl_table  = TA_Database::table( 'blacklist' );

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT ta.*, u.display_name AS ta_name
             FROM {$ta_table} ta
             JOIN {$cap_table} cap ON cap.ta_id = ta.id
                                  AND cap.course_type = 'level_assess'
                                  AND cap.term_id = %d
             JOIN {$wpdb->users} u ON u.ID = ta.user_id
             LEFT JOIN {$bl_table} bl ON bl.ta_id = ta.id AND bl.student_id = %d
             WHERE ta.is_active = 1
               AND bl.id IS NULL
               AND cap.used_capacity < cap.total_capacity
             ORDER BY ta.rank DESC",
            [ $term_id, $student_id ]
        ) ) ?: [];
    }
        /**
     * نمایش دکمه تخصیص به استادیار اختصاصی برای دوره حرفه‌ای
     */
    private function render_assign_professional_flow( object $settings, int $uid, int $product_id ): void {
        // خواندن استادیار اختصاصی از تنظیمات محصول (باید توسط مدیر در صفحه محصول ثبت شده باشد)
        $ta_professional_id = get_post_meta( $product_id, '_ta_professional_ta_id', true );
        $ta_info = $ta_professional_id ? get_userdata( $ta_professional_id ) : null;

        echo '<div class="ta-message ta-message-success" style="text-align: center; padding: 20px;">';
        echo '<h4 style="margin-bottom:15px; color:#2e7d32;">✅ شما مجوز ورود به این دوره حرفه‌ای را دارید.</h4>';
        
        if ( $ta_info && $ta_professional_id ) {
            echo '<p>لطفاً برای ثبت درخواست و تخصیص به استادیار دوره، روی دکمه زیر کلیک کنید.</p>';
            echo '<div style="margin-top:20px;">';
            // دکمه با کلاس ta-assign-professional برای اتصال به ایجکس
            echo '<button class="ta-btn ta-btn-primary ta-assign-professional" data-product-id="' . esc_attr( $product_id ) . '" data-ta-id="' . esc_attr( $ta_professional_id ) . '" style="padding: 10px 20px; font-size: 16px;">
            تخصیص به استادیار دوره ( ' . esc_html( $ta_info->display_name ) . ' )
            </button>';
            echo '</div>';
        } else {
            echo '<p class="ta-message ta-message-error" style="margin-top:15px;">⚠️ استادیار اختصاصی برای این دوره هنوز توسط مدیر سیستم تعیین نشده است. لطفاً با پشتیبانی تماس بگیرید.</p>';
        }
        echo '</div>';
    }

}
