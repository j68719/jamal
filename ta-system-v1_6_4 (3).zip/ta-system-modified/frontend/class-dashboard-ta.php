<?php
defined( 'ABSPATH' ) || exit;

/**
 * داشبورد فرانت‌اند استادیار
 * با شورت‌کد [ta_dashboard]
 */
class TA_Dashboard_TA {

    public function __construct() {
        add_shortcode( 'ta_dashboard', [ $this, 'render_shortcode' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
    }

    public function enqueue_assets(): void {
        if ( ! is_page() ) {
            return;
        }
        global $post;
        if ( $post && has_shortcode( $post->post_content, 'ta_dashboard' ) ) {
            wp_enqueue_style( 'ta-system', TA_SYSTEM_URL . 'assets/css/ta-system.css', [], TA_SYSTEM_VERSION );
            wp_enqueue_script( 'ta-system', TA_SYSTEM_URL . 'assets/js/ta-system.js', [ 'jquery' ], TA_SYSTEM_VERSION, true );
            wp_localize_script( 'ta-system', 'taSystem', [
                'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
                'nonce'      => wp_create_nonce( 'ta_dashboard_nonce' ),
                'isDashboard' => 1,
            ] );
        }
    }

    public function render_shortcode(): string {
        if ( ! is_user_logged_in() ) {
            return '<p>برای دسترسی به داشبورد باید <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">وارد شوید</a>.</p>';
        }

        $uid = get_current_user_id();
        if ( ! TA_Roles::is_ta( $uid ) ) {
            return '<p>شما دسترسی به این بخش ندارید.</p>';
        }

        $ta_table = TA_Database::table( 'assistants' );
        $ta = TA_Database::get_row( "SELECT * FROM {$ta_table} WHERE user_id = %d", [ $uid ] );
        if ( ! $ta ) {
            return '<p>اطلاعات شما به عنوان استادیار یافت نشد. با ادمین تماس بگیرید.</p>';
        }

        $tab = sanitize_text_field( $_GET['ta_tab'] ?? 'overview' );

        ob_start();
        $this->render_dashboard( $ta, $tab );
        return ob_get_clean();
    }

    private function render_dashboard( object $ta, string $tab ): void {
        $tabs = [
            'overview'       => 'خلاصه',
            'capacity'       => 'ظرفیت و گروه‌ها',
            'students'       => 'هنرجویان',
            'payroll'        => '💰 حق‌الزحمه',
            'story_critique' => '✍️ نقد داستان',
            'blacklist'      => 'لیست سیاه',
        ];
        ?>
        <div class="ta-dashboard" dir="rtl">
            <div class="ta-dashboard-header">
                <h2>داشبورد استادیار — <?= esc_html( wp_get_current_user()->display_name ) ?></h2>
            </div>

            <nav class="ta-tabs">
                <?php foreach ( $tabs as $key => $label ) :
                    $url = add_query_arg( 'ta_tab', $key );
                    $active = $tab === $key ? ' ta-tab-active' : '';
                ?>
                    <a href="<?= esc_url( $url ) ?>" class="ta-tab<?= $active ?>"><?= $label ?></a>
                <?php endforeach; ?>
            </nav>

            <div class="ta-dashboard-content">
                <?php
                match ( $tab ) {
                    'capacity'       => $this->tab_capacity( $ta ),
                    'students'       => $this->tab_students( $ta ),
                    'payroll'        => $this->tab_payroll( $ta ),
                    'story_critique' => $this->tab_story_critique( $ta ),
                    'blacklist'      => $this->tab_blacklist( $ta ),
                    default          => $this->tab_overview( $ta ),
                };
                ?>
            </div>
        </div>
        <?php
    }

    // ── Overview ─────────────────────────────────────────────────────────────
    private function tab_overview( object $ta ): void {
        ?>
        <div class="ta-overview-wrapper" id="ta-overview-root">

            <!-- ── بارگذاری اولیه ── -->
            <div class="ta-overview-loading" id="ta-overview-loading">
                <div class="ta-spinner"></div>
                <span>در حال بارگذاری آمار…</span>
            </div>

            <!-- ── محتوای اصلی (پنهان تا بارگذاری) ── -->
            <div id="ta-overview-content" style="display:none">

                <!-- کارت‌های خلاصه کلی -->
                <div class="ta-ov-global-cards" id="ta-ov-global-cards"></div>

                <!-- نوار پر شدن ظرفیت کلی -->
                <div class="ta-ov-fill-bar-wrap">
                    <div class="ta-ov-fill-bar-label">
                        <span>پر شدن ظرفیت کل</span>
                        <span id="ta-ov-fill-pct" class="ta-ov-fill-pct-val">۰٪</span>
                    </div>
                    <div class="ta-ov-fill-track">
                        <div class="ta-ov-fill-thumb" id="ta-ov-fill-thumb" style="width:0%"></div>
                    </div>
                </div>

                <!-- آمار نمرات کلی -->
                <div class="ta-ov-grades-row" id="ta-ov-grades-row"></div>

                <!-- سربرگ ترم‌ها -->
                <div class="ta-ov-section-title">
                    <span class="ta-ov-section-icon">📅</span>
                    آمار به تفکیک ترم
                </div>

                <!-- آکاردئون ترم‌ها -->
                <div id="ta-ov-terms-list"></div>

            </div>
        </div>

        <style>
        .ta-overview-wrapper { padding: 0; }
        .ta-overview-loading {
            display: flex; align-items: center; gap: 12px;
            padding: 40px 0; color: #636e72; font-size: 0.95rem;
        }
        .ta-spinner {
            width: 22px; height: 22px; border: 3px solid #e0e0e0;
            border-top-color: #6c5ce7; border-radius: 50%;
            animation: ta-spin 0.8s linear infinite;
        }
        @keyframes ta-spin { to { transform: rotate(360deg); } }
        .ta-ov-global-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 14px; margin-bottom: 20px;
        }
        .ta-ov-kpi {
            background: #fff; border: 1.5px solid #f0f0f0; border-radius: 14px;
            padding: 18px 16px 14px; text-align: center;
            box-shadow: 0 2px 8px rgba(0,0,0,.04);
            transition: transform .2s, box-shadow .2s; position: relative; overflow: hidden;
        }
        .ta-ov-kpi:hover { transform: translateY(-3px); box-shadow: 0 6px 20px rgba(0,0,0,.09); }
        .ta-ov-kpi::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0; height: 4px;
            background: var(--kpi-color, #6c5ce7); border-radius: 14px 14px 0 0;
        }
        .ta-ov-kpi-icon { font-size: 1.6rem; line-height: 1; margin-bottom: 8px; }
        .ta-ov-kpi-val  { font-size: 2rem; font-weight: 800; line-height: 1; color: var(--kpi-color, #2d3436); margin-bottom: 4px; }
        .ta-ov-kpi-label { font-size: 0.78rem; color: #636e72; font-weight: 500; }
        .ta-ov-fill-bar-wrap { margin-bottom: 22px; }
        .ta-ov-fill-bar-label {
            display: flex; justify-content: space-between; align-items: center;
            font-size: 0.85rem; color: #636e72; margin-bottom: 6px; font-weight: 600;
        }
        .ta-ov-fill-pct-val { font-size: 1rem; font-weight: 800; color: #2d3436; }
        .ta-ov-fill-track { height: 10px; background: #f0f0f0; border-radius: 99px; overflow: hidden; }
        .ta-ov-fill-thumb {
            height: 100%; border-radius: 99px;
            background: linear-gradient(90deg, #6c5ce7, #a29bfe);
            transition: width 1s cubic-bezier(.4,0,.2,1);
        }
        .ta-ov-grades-row { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 28px; }
        .ta-ov-grade-chip {
            display: flex; align-items: center; gap: 6px;
            padding: 6px 14px; border-radius: 99px; font-size: 0.82rem; font-weight: 700;
            border: 1.5px solid transparent;
        }
        .ta-ov-grade-chip.pass     { background: #d4edda; color: #155724; border-color: #c3e6cb; }
        .ta-ov-grade-chip.repeat   { background: #fff3cd; color: #856404; border-color: #ffeeba; }
        .ta-ov-grade-chip.critique { background: #cce5ff; color: #004085; border-color: #b8daff; }
        .ta-ov-section-title {
            font-size: 1rem; font-weight: 700; color: #2d3436;
            display: flex; align-items: center; gap: 8px;
            margin-bottom: 14px; padding-bottom: 8px; border-bottom: 2px solid #f0f0f0;
        }
        .ta-ov-section-icon { font-size: 1.2rem; }
        .ta-ov-term-card {
            background: #fff; border: 1.5px solid #efefef; border-radius: 12px;
            margin-bottom: 12px; overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,.04);
        }
        .ta-ov-term-header {
            display: flex; align-items: center; justify-content: space-between;
            padding: 14px 18px; cursor: pointer; user-select: none; transition: background .15s;
        }
        .ta-ov-term-header:hover { background: #fafafa; }
        .ta-ov-term-header-left { display: flex; align-items: center; gap: 10px; }
        .ta-ov-term-name { font-weight: 700; font-size: 0.95rem; color: #2d3436; }
        .ta-ov-term-badge {
            font-size: 0.72rem; font-weight: 700; padding: 2px 9px; border-radius: 99px;
            background: #f0ebff; color: #6c5ce7;
        }
        .ta-ov-term-summary { display: flex; gap: 16px; align-items: center; }
        .ta-ov-term-mini-stat { font-size: 0.78rem; color: #636e72; display: flex; align-items: center; gap: 4px; }
        .ta-ov-term-mini-stat strong { color: #2d3436; font-weight: 700; }
        .ta-ov-term-chevron { font-size: 0.85rem; color: #b2bec3; transition: transform .25s; }
        .ta-ov-term-card.open .ta-ov-term-chevron { transform: rotate(180deg); }
        .ta-ov-term-fill-track { height: 4px; background: #f0f0f0; border-radius: 0; }
        .ta-ov-term-fill-thumb {
            height: 100%; background: linear-gradient(90deg, #00b894, #55efc4);
            transition: width 1.2s cubic-bezier(.4,0,.2,1);
        }
        .ta-ov-term-fill-thumb.warn { background: linear-gradient(90deg, #fdcb6e, #ffeaa7); }
        .ta-ov-term-fill-thumb.full { background: linear-gradient(90deg, #d63031, #ff7675); }
        .ta-ov-term-body { max-height: 0; overflow: hidden; transition: max-height .35s ease; border-top: 0; }
        .ta-ov-term-card.open .ta-ov-term-body { max-height: 800px; border-top: 1px solid #f0f0f0; }
        .ta-ov-term-body-inner { padding: 16px 18px 18px; }
        .ta-ov-term-cols { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        @media (max-width: 560px) { .ta-ov-term-cols { grid-template-columns: 1fr; } }
        .ta-ov-sub-title { font-size: 0.78rem; font-weight: 700; color: #b2bec3; text-transform: uppercase; letter-spacing: .04em; margin-bottom: 8px; }
        .ta-ov-stat-row {
            display: flex; justify-content: space-between; align-items: center;
            padding: 5px 0; border-bottom: 1px dashed #f0f0f0; font-size: 0.84rem;
        }
        .ta-ov-stat-row:last-child { border-bottom: none; }
        .ta-ov-stat-row-label { color: #636e72; }
        .ta-ov-stat-row-val { font-weight: 700; color: #2d3436; }
        .ta-ov-stat-row-val.green  { color: #00b894; }
        .ta-ov-stat-row-val.red    { color: #d63031; }
        .ta-ov-stat-row-val.blue   { color: #0984e3; }
        .ta-ov-grade-chips-sm { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
        .ta-ov-grade-chip-sm {
            display: flex; align-items: center; gap: 4px;
            padding: 4px 10px; border-radius: 99px; font-size: 0.76rem; font-weight: 700;
        }
        .ta-ov-grade-chip-sm.pass     { background: #d4edda; color: #155724; }
        .ta-ov-grade-chip-sm.repeat   { background: #fff3cd; color: #856404; }
        .ta-ov-grade-chip-sm.critique { background: #cce5ff; color: #004085; }
        .ta-ov-grade-chip-sm.pending  { background: #f8f9fa; color: #888; }
        .ta-ov-course-pills { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 4px; }
        .ta-ov-course-pill {
            display: flex; align-items: center; gap: 4px;
            padding: 4px 10px; border-radius: 8px; font-size: 0.76rem; font-weight: 600;
            background: #f0f4f8; color: #495057; border: 1px solid #e2e8f0;
        }
        .ta-ov-course-pill .pill-count { font-weight: 800; color: #2d3436; }
        .ta-ov-empty { text-align: center; padding: 40px; color: #b2bec3; font-size: 0.9rem; }
        </style>

        <script>
        (function() {
            const toFa = n => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
            const gradeLabel = { pass: 'قبولی', repeat: 'تکرار دوره', critique: 'نقد اثر', pending: 'ثبت‌نشده' };
            const courseLabel = { creative: 'خلاق', intro: 'مقدماتی', advanced: 'پیشرفته', professional: 'حرفه‌ای', critique: 'نقد اثر' };

            function kpiCard(icon, val, label, color) {
                return '<div class="ta-ov-kpi" style="--kpi-color:' + color + '">'
                    + '<div class="ta-ov-kpi-icon">' + icon + '</div>'
                    + '<div class="ta-ov-kpi-val">' + toFa(val) + '</div>'
                    + '<div class="ta-ov-kpi-label">' + label + '</div>'
                    + '</div>';
            }

            function renderGlobal(g) {
                document.getElementById('ta-ov-global-cards').innerHTML =
                    kpiCard('👥', g.total_students, 'کل هنرجویان', '#6c5ce7') +
                    kpiCard('✅', g.active_count,    'هنرجویان فعال', '#00b894') +
                    kpiCard('🎓', g.completed_count, 'تکمیل‌شده', '#0984e3') +
                    kpiCard('❌', g.canceled_count,  'انصرافی', '#d63031') +
                    kpiCard('📦', g.total_cap,       'کل ظرفیت', '#fdcb6e') +
                    kpiCard('🔓', g.remaining_cap,   'ظرفیت آزاد', '#55efc4');

                document.getElementById('ta-ov-fill-pct').textContent = toFa(g.fill_pct) + '٪';
                setTimeout(function() {
                    document.getElementById('ta-ov-fill-thumb').style.width = g.fill_pct + '%';
                }, 50);

                var gRow = document.getElementById('ta-ov-grades-row');
                var grades = g.grades || {};
                var html = '';
                if (grades.pass)     html += '<span class="ta-ov-grade-chip pass">' + gradeLabel.pass + ' <strong>' + toFa(grades.pass) + '</strong></span>';
                if (grades.repeat)   html += '<span class="ta-ov-grade-chip repeat">' + gradeLabel.repeat + ' <strong>' + toFa(grades.repeat) + '</strong></span>';
                if (grades.critique) html += '<span class="ta-ov-grade-chip critique">' + gradeLabel.critique + ' <strong>' + toFa(grades.critique) + '</strong></span>';
                if (!html) html = '<span style="color:#b2bec3;font-size:0.85rem">هنوز نمره‌ای ثبت نشده است.</span>';
                gRow.innerHTML = '<span style="font-size:0.82rem;font-weight:600;color:#636e72;margin-left:6px">نمرات کل:</span>' + html;
            }

            function fillColor(pct) {
                if (pct >= 90) return 'full';
                if (pct >= 60) return 'warn';
                return '';
            }

            function renderTerms(terms) {
                var list = document.getElementById('ta-ov-terms-list');
                if (!terms.length) {
                    list.innerHTML = '<div class="ta-ov-empty">هیچ ترمی یافت نشد.</div>';
                    return;
                }
                var out = '';
                terms.forEach(function(t) {
                    var fc = fillColor(t.fill_pct);
                    var coursePills = '';
                    var courses = t.courses || {};
                    Object.keys(courses).forEach(function(type) {
                        var row = courses[type];
                        var label = courseLabel[type] || type;
                        coursePills += '<span class="ta-ov-course-pill">' + label + ' <span class="pill-count">' + toFa(row.cnt) + '</span></span>';
                    });
                    if (!coursePills) coursePills = '<span style="color:#b2bec3;font-size:0.78rem">—</span>';

                    var gradeChips = '';
                    var grades = t.grades || {};
                    if (grades.pass)     gradeChips += '<span class="ta-ov-grade-chip-sm pass">' + gradeLabel.pass + ' ' + toFa(grades.pass) + '</span>';
                    if (grades.repeat)   gradeChips += '<span class="ta-ov-grade-chip-sm repeat">' + gradeLabel.repeat + ' ' + toFa(grades.repeat) + '</span>';
                    if (grades.critique) gradeChips += '<span class="ta-ov-grade-chip-sm critique">' + gradeLabel.critique + ' ' + toFa(grades.critique) + '</span>';
                    if (!gradeChips)     gradeChips = '<span class="ta-ov-grade-chip-sm pending">بدون نمره</span>';

                    var remClass = t.remaining_cap > 0 ? 'green' : 'red';
                    var canClass = t.canceled_count > 0 ? 'red' : '';

                    out += '<div class="ta-ov-term-card" id="ta-term-card-' + t.id + '">'
                        + '<div class="ta-ov-term-fill-track"><div class="ta-ov-term-fill-thumb ' + fc + '" id="ta-tfill-' + t.id + '" style="width:0%"></div></div>'
                        + '<div class="ta-ov-term-header" onclick="taOvToggleTerm(' + t.id + ')">'
                        +   '<div class="ta-ov-term-header-left">'
                        +     '<span class="ta-ov-term-name">' + t.name + '</span>'
                        +     '<span class="ta-ov-term-badge">' + toFa(t.fill_pct) + '٪ پر</span>'
                        +   '</div>'
                        +   '<div class="ta-ov-term-summary">'
                        +     '<span class="ta-ov-term-mini-stat">👥 <strong>' + toFa(t.total_students) + '</strong> هنرجو</span>'
                        +     '<span class="ta-ov-term-mini-stat">📦 <strong>' + toFa(t.used_cap) + '/' + toFa(t.total_cap) + '</strong></span>'
                        +     '<span class="ta-ov-term-chevron">▼</span>'
                        +   '</div>'
                        + '</div>'
                        + '<div class="ta-ov-term-body" id="ta-tbody-' + t.id + '">'
                        +   '<div class="ta-ov-term-body-inner">'
                        +     '<div class="ta-ov-term-cols">'
                        +       '<div>'
                        +         '<div class="ta-ov-sub-title">ظرفیت و وضعیت</div>'
                        +         '<div class="ta-ov-stat-row"><span class="ta-ov-stat-row-label">کل ظرفیت</span><span class="ta-ov-stat-row-val">' + toFa(t.total_cap) + '</span></div>'
                        +         '<div class="ta-ov-stat-row"><span class="ta-ov-stat-row-label">استفاده‌شده</span><span class="ta-ov-stat-row-val blue">' + toFa(t.used_cap) + '</span></div>'
                        +         '<div class="ta-ov-stat-row"><span class="ta-ov-stat-row-label">ظرفیت آزاد</span><span class="ta-ov-stat-row-val ' + remClass + '">' + toFa(t.remaining_cap) + '</span></div>'
                        +         '<div class="ta-ov-stat-row"><span class="ta-ov-stat-row-label">هنرجوی فعال</span><span class="ta-ov-stat-row-val green">' + toFa(t.active_count) + '</span></div>'
                        +         '<div class="ta-ov-stat-row"><span class="ta-ov-stat-row-label">تکمیل‌شده</span><span class="ta-ov-stat-row-val blue">' + toFa(t.completed_count) + '</span></div>'
                        +         '<div class="ta-ov-stat-row"><span class="ta-ov-stat-row-label">انصرافی</span><span class="ta-ov-stat-row-val ' + canClass + '">' + toFa(t.canceled_count) + '</span></div>'
                        +       '</div>'
                        +       '<div>'
                        +         '<div class="ta-ov-sub-title">نوع دوره‌ها</div>'
                        +         '<div class="ta-ov-course-pills">' + coursePills + '</div>'
                        +         '<div class="ta-ov-sub-title" style="margin-top:14px">نمرات</div>'
                        +         '<div class="ta-ov-grade-chips-sm">' + gradeChips + '</div>'
                        +       '</div>'
                        +     '</div>'
                        +   '</div>'
                        + '</div>'
                        + '</div>';
                });
                list.innerHTML = out;

                terms.forEach(function(t, i) {
                    setTimeout(function() {
                        var el = document.getElementById('ta-tfill-' + t.id);
                        if (el) el.style.width = t.fill_pct + '%';
                    }, 100 + i * 80);
                });
            }

            window.taOvToggleTerm = function(id) {
                var card = document.getElementById('ta-term-card-' + id);
                var body = document.getElementById('ta-tbody-' + id);
                var isOpen = card.classList.contains('open');
                document.querySelectorAll('.ta-ov-term-card.open').forEach(function(c) {
                    c.classList.remove('open');
                    c.querySelector('.ta-ov-term-body').style.maxHeight = '0';
                });
                if (!isOpen) {
                    card.classList.add('open');
                    body.style.maxHeight = body.scrollHeight + 'px';
                }
            };

            function loadStats() {
                jQuery.post(taSystem.ajaxUrl, {
                    action: 'ta_get_term_stats',
                    nonce:  taSystem.nonce
                }, function(res) {
                    document.getElementById('ta-overview-loading').style.display = 'none';
                    document.getElementById('ta-overview-content').style.display  = 'block';
                    if (res.success) {
                        renderGlobal(res.data.global);
                        renderTerms(res.data.terms);
                        if (res.data.terms.length) {
                            setTimeout(function() { taOvToggleTerm(res.data.terms[0].id); }, 200);
                        }
                    }
                }).fail(function() {
                    document.getElementById('ta-overview-loading').innerHTML =
                        '<span style="color:#d63031">خطا در بارگذاری آمار. صفحه را بازخوانی کنید.</span>';
                });
            }

            if (typeof jQuery !== 'undefined' && typeof taSystem !== 'undefined') {
                loadStats();
            } else {
                document.addEventListener('DOMContentLoaded', loadStats);
            }
        })();
        </script>
        <?php
    }

    // ── ظرفیت و گروه‌ها ──────────────────────────────────────────────────────
    private function tab_capacity( object $ta ): void {
        $terms     = TA_Database::get_results( "SELECT * FROM " . TA_Database::table('terms') . " ORDER BY order_index DESC" );
        $cap_table = TA_Database::table( 'capacities' );
        $gr_table  = TA_Database::table( 'groups' );

        $course_types = [
            'creative'     => 'خلاق',
            'intro'        => 'مقدماتی',
            'advanced'     => 'پیشرفته',
            'professional'     => 'حرفه‌ای',
            'critique'     => 'نقد اثر',
            
        ];
        $gender_labels = [ 'male' => 'آقایان', 'female' => 'خانم‌ها', 'both' => 'هر دو' ];
        ?>
        <div class="ta-section">
            <h3>افزودن / ویرایش ظرفیت</h3>
            <p style="color:#636e72;font-size:0.88rem">
                💡 می‌توانید برای آقایان و خانم‌ها ظرفیت جداگانه تعریف کنید.
                هنگام جستجوی استادیار، سیستم ابتدا ظرفیت مخصوص جنسیت هنرجو را بررسی می‌کند.
            </p>
            <div class="ta-form-inline" id="ta-capacity-form">
                <div>
                    <label style="display:block;font-size:0.8rem;margin-bottom:3px">ترم:</label>
                    <select id="cap-term" class="ta-select" style="width:auto">
                        <?php foreach ($terms as $t) : ?>
                            <option value="<?= $t->id ?>"><?= esc_html($t->name) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label style="display:block;font-size:0.8rem;margin-bottom:3px">نوع دوره:</label>
                    <select id="cap-course" class="ta-select" style="width:auto">
                        <?php foreach ($course_types as $val => $label) : ?>
                            <option value="<?= $val ?>"><?= $label ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label style="display:block;font-size:0.8rem;margin-bottom:3px">جنسیت هنرجو:</label>
                    <select id="cap-gender" class="ta-select" style="width:auto">
                        <option value="male">آقایان</option>
                        <option value="female">خانم‌ها</option>
                        <option value="both">هر دو (مشترک)</option>
                    </select>
                </div>
                <div>
            <label style="display:block;font-size:0.8rem;margin-bottom:3px">پیام‌رسان:</label>
            <select id="cap-messenger" class="ta-input">
                <option value="both">فرقی ندارد (پیش‌فرض)</option>
                <option value="telegram">تلگرام</option>
                <option value="bale">بله</option>
                <option value="eitaa">ایتا</option>
            </select>
        </div>
        
                <div>
                    <label style="display:block;font-size:0.8rem;margin-bottom:3px">تعداد ظرفیت:</label>
                    <input type="number" id="cap-total" class="ta-input" placeholder="مثلاً ۱۰" min="0" style="width:100px">
                </div>
                <div style="align-self:flex-end">
                   <button class="ta-btn ta-btn-primary" onclick="taSaveOrUpdateCapacity()">ذخیره ظرفیت</button>

                </div>
            </div>
            <div id="cap-result" class="ta-message" style="display:none"></div>
        </div>

        <div class="ta-section">
            <h3>ظرفیت‌های تعریف‌شده</h3>
            <table class="ta-table">
                <thead>
                    <tr>
                        <th>ترم</th><th>نوع دوره</th><th>جنسیت</th>            <th>پیام‌رسان</th> <!-- این خط اضافه شود -->

                        <th>کل</th><th>استفاده‌شده</th><th>باقی</th><th>گروه‌ها</th><th>عملیات</th>

                    </tr>
                </thead>
                <tbody>
                <?php
                $caps = TA_Database::get_results(
                    "SELECT c.*, t.name AS term_name
                     FROM {$cap_table} c
                     LEFT JOIN " . TA_Database::table('terms') . " t ON t.id = c.term_id
                     WHERE c.ta_id = %d
                     ORDER BY t.order_index DESC, c.course_type, c.student_gender",
                    [ $ta->id ]
                );
                foreach ( $caps as $cap ) :
                    $remaining = $cap->total_capacity - $cap->used_capacity;
                    $groups = [];
                    if ( $cap->course_type === 'creative' ) {
                        $groups = TA_Database::get_results(
                            "SELECT * FROM {$gr_table} WHERE capacity_id = %d ORDER BY id",
                            [ $cap->id ]
                        );
                    }
                    $m_labels = ['telegram'=>'تلگرام','bale'=>'بله','eitaa'=>'ایتا'];
                ?>
                    <tr>
                        <td><?= esc_html($cap->term_name ?? '—') ?></td>
                        <td><?= $course_types[$cap->course_type] ?? $cap->course_type ?></td>
                        <td>
                            <span class="ta-badge ta-badge-<?= $cap->student_gender === 'male' ? 'pass' : ($cap->student_gender === 'female' ? 'critique' : 'pending') ?>">
                                <?= $gender_labels[$cap->student_gender] ?? $cap->student_gender ?>
                            </span>
                        </td>
                                    <td><?= esc_html( $m_labels[ $cap->messenger ?? 'both' ] ?? 'فرقی ندارد' ) ?></td>

                        <td><?= $cap->total_capacity ?></td>
                        <td><?= $cap->used_capacity ?></td>
                        <td>
                            <strong style="color:<?= $remaining > 0 ? '#00b894' : '#d63031' ?>">
                                <?= $remaining ?>
                            </strong>
                        </td>
                        <td>
                            <?php if ( $cap->course_type === 'creative' ) : ?>
                                <button class="ta-btn ta-btn-sm" onclick="taShowAddGroup(<?= $cap->id ?>)">+ گروه</button>
                                <?php if ( ! empty($groups) ) : ?>
                                <span style="color:#636e72;font-size:0.82rem">(<?= count($groups) ?> گروه)</span>
                                <?php endif; ?>

                                <div id="groups-<?= $cap->id ?>" style="margin-top:8px">
                                    <?php foreach ($groups as $g) : ?>
                                        <div class="ta-group-row <?= $g->is_used ? 'ta-used' : '' ?>">
                                            <?= $m_labels[$g->messenger_type] ?? $g->messenger_type ?> —
                                            <?php if ($g->is_used) :
                                                $st = get_user_by('id', $g->assigned_to_user_id);
                                            ?>
                                                <span class="ta-badge ta-badge-used">استفاده‌شده</span>
                                                <?= $st ? esc_html($st->display_name) : '' ?>
                                            <?php else : ?>
                                                <span class="ta-badge ta-badge-free">آزاد</span>
                                                <a href="<?= esc_url($g->group_link) ?>" target="_blank">مشاهده</a>
               <button class="ta-btn ta-btn-xs ta-btn-warning"
        onclick="taEditGroup(<?= $g->id ?>, <?= $cap->id ?>, '<?= esc_js($g->messenger_type) ?>', '<?= esc_js($g->group_link) ?>')">
    ویرایش
</button>

                <button class="ta-btn ta-btn-xs ta-btn-danger" onclick="taDeleteGroup(<?= $g->id ?>)">حذف </button>

                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                </div>

                                <div id="add-group-form-<?= $cap->id ?>" style="display:none;margin-top:8px">
                                    
                                    
                                    
                                    
                                    <?php
                                    // نوع پیام‌رسان ظرفیت
                                    $cap_messenger = $cap->messenger ?? 'both';
                                    // آرایه لیبل‌ها
                                    $messenger_labels = [
                                        'telegram' => 'تلگرام',
                                        'bale'     => 'بله',
                                        'eitaa'    => 'ایتا',
                                        ];
                                        // تعیین لیست مجاز برای این ظرفیت
                                        if (in_array($cap_messenger, ['telegram', 'bale', 'eitaa'], true)) {
                                            // فقط همان پیام‌رسان ظرفیت
                                            $allowed_messengers = [ $cap_messenger ];
                                            } else {
                                                    // فرقی ندارد → هر سه نوع
                                                    $allowed_messengers = ['telegram', 'bale', 'eitaa'];
                                                    }
                                                    ?>
                                                    
                                                    <label style="display:block;font-size:0.8rem;margin-bottom:3px">
                                                        پیام‌رسان گروه:
                                                        </label>
                                                        <select id="group-messenger-<?= $cap->id ?>" class="ta-input">
                                                            
                                                            <?php foreach ($allowed_messengers as $m_key): ?>
                                                            <option value="<?= esc_attr($m_key) ?>">
                                                                <?= esc_html($messenger_labels[$m_key]) ?>
                                                                </option>
                                                                <?php endforeach; ?>
                                                                </select>
                                                                
                                                                

                                    
                                    
                                    
                                    
                                    
                                    
                                    <!--select class="ta-select" id="group-messenger-<?= $cap->id ?>" style="width:auto">
                                        <option value="telegram">تلگرام</option>
                                        <option value="bale">بله</option>
                                        <option value="eitaa">ایتا</option>
                                    </select-->
                                    
                                    <input type="url" class="ta-input" id="group-link-<?= $cap->id ?>" placeholder="لینک گروه" style="margin-top:6px">
                                    <button class="ta-btn ta-btn-primary ta-btn-sm" onclick="taAddGroupSlot(<?= $cap->id ?>)">افزودن</button>
                                </div>
                            <?php else : ?>
                                —
                            <?php endif; ?>
                        </td>
                        
                        
                        <td>
    <button class="ta-btn ta-btn-xs" 
            onclick="taLoadCapacityForEdit(<?= $cap->id ?>, <?= $cap->term_id ?>, '<?= esc_js($cap->course_type) ?>', '<?= esc_js($cap->student_gender) ?>', <?= $cap->total_capacity ?>)">
        ویرایش
    </button>
    <?php if ( $cap->used_capacity == 0 ) : ?>
        <button class="ta-btn ta-btn-xs ta-btn-danger" 
                onclick="taDeleteCapacity(<?= $cap->id ?>)"
                style="margin-right:4px">
            حذف
        </button>
    <?php else : ?>
        <span style="color:#dc3545;font-size:0.75rem;display:block;margin-top:4px">
            (در حال استفاده)
        </span>
    <?php endif; ?>
</td>




                    </tr>
                <?php endforeach; ?>
                <?php if ( empty($caps) ) : ?>
                    <tr><td colspan="7" style="text-align:center;padding:20px;color:#636e72">هنوز ظرفیتی ثبت نشده است.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    // ── هنرجویان ────────────────────────────────────────────────────────────
        // ── هنرجویان ────────────────────────────────────────────────────────────
    private function tab_students( object $ta ): void {
        $assign_table = TA_Database::table( 'assignments' );
        $bl_table     = TA_Database::table( 'blacklist' );
        $term_table   = TA_Database::table( 'terms' ); // اصلاح: دریافت صحیح نام جدول ترم‌ها
        $grade_table  = TA_Database::table( 'grades' ); // اصلاح: دریافت صحیح نام جدول نمرات
        global $wpdb;

        $status_filter = isset( $_GET['ta_status'] ) ? sanitize_text_field( $_GET['ta_status'] ) : 'active';
        $allowed_statuses = [ 'active', 'completed', 'canceled', 'all' ];

        if ( ! in_array( $status_filter, $allowed_statuses, true ) ) {
            $status_filter = 'active';
        }
        
        $term_filter    = isset( $_GET['ta_term'] )    ? sanitize_text_field( $_GET['ta_term'] )    : '';
        $product_filter = isset( $_GET['ta_product'] ) ? sanitize_text_field( $_GET['ta_product'] ) : '';
        $grade_filter   = isset( $_GET['ta_grade'] )   ? sanitize_text_field( $_GET['ta_grade'] )   : '';

        // ساخت شرط‌های پویا
        $where_clauses = [ 'a.ta_id = %d' ];
        $query_args    = [ $ta->id ];

        if ( $status_filter !== 'all' ) {
            $where_clauses[] = 'a.status = %s';
            $query_args[]    = $status_filter;
        }
        if ( $term_filter !== '' ) {
            $where_clauses[] = 'a.term_id = %d';
            $query_args[]    = (int) $term_filter;
        }
        if ( $product_filter !== '' ) {
            $where_clauses[] = 'a.product_id = %d';
            $query_args[]    = (int) $product_filter;
        }
        if ( $grade_filter === 'none' ) {
            $where_clauses[] = 'g.grade IS NULL';
        } elseif ( $grade_filter !== '' ) {
            $where_clauses[] = 'g.grade = %s';
            $query_args[]    = $grade_filter;
        }

        $where_sql = implode( ' AND ', $where_clauses );

        // اصلاح نام جداول در کوئری اصلی
        $students = $wpdb->get_results( $wpdb->prepare(
            "SELECT
                a.id, a.status, a.product_id, a.course_type, a.messenger, a.group_link,
                u.ID   AS student_id,
                u.display_name,
                u.user_email,
                t.name AS term_name,
                t.id   AS term_id,
                p.post_title AS product_name,
                g.grade,
                g.notes AS grade_notes,
                b.id   AS is_blacklisted
             FROM {$assign_table} a
             JOIN {$wpdb->users} u ON u.ID = a.student_id
             JOIN {$term_table} t ON t.id = a.term_id
             JOIN {$wpdb->posts} p ON p.ID = a.product_id
             LEFT JOIN {$grade_table} g ON g.student_id = a.student_id AND g.product_id = a.product_id
             LEFT JOIN {$bl_table} b ON b.student_id = a.student_id AND b.ta_id = a.ta_id
             WHERE {$where_sql}
             ORDER BY a.id DESC",
            $query_args
        ) );

        // جلوگیری از Fatal Error در صورت شکست کوئری
        if ( ! is_array( $students ) ) {
            $students = [];
        }

        // واکشی ترم‌های منحصربه‌فرد این استادیار
        $terms_list = $wpdb->get_results( $wpdb->prepare(
            "SELECT DISTINCT t.id, t.name
             FROM {$assign_table} a
             JOIN {$term_table} t ON t.id = a.term_id
             WHERE a.ta_id = %d
             ORDER BY t.name",
            $ta->id
        ) );
        if ( ! is_array( $terms_list ) ) $terms_list = [];

        // واکشی دوره‌های منحصربه‌فرد این استادیار
        $products_list = $wpdb->get_results( $wpdb->prepare(
            "SELECT DISTINCT p.ID, p.post_title
             FROM {$assign_table} a
             JOIN {$wpdb->posts} p ON p.ID = a.product_id
             WHERE a.ta_id = %d
             ORDER BY p.post_title",
            $ta->id
        ) );
        if ( ! is_array( $products_list ) ) $products_list = [];

        $course_labels = [ 'creative' => 'خلاق', 'critique' => 'نقد اثر', 'intro' => 'مقدماتی', 'advanced' => 'پیشرفته' ];
        $m_labels = ['telegram'=>'تلگرام','bale'=>'بله','eitaa'=>'ایتا'];
        ?>
        <div class="ta-section">
            <h3>هنرجویان من (<?= count($students) ?>)</h3>
            <?php
            $base_url = remove_query_arg( [ 'ta_status', 'ta_term', 'ta_product', 'ta_grade' ] );
            ?>
            <div class="ta-toolbar" style="display:flex; align-items:center; gap:12px; margin-bottom:12px; flex-wrap:wrap;">
                
                <div>
                    <label style="font-weight:600; margin-left:6px;">وضعیت:</label>
                    <select id="ta-status-filter" class="ta-select" style="width:auto"
                            onchange="window.location.href='<?= esc_url($base_url) ?>&ta_status='+this.value">
                        <option value="active"    <?= $status_filter === 'active'    ? 'selected' : '' ?>>فعال</option>
                        <option value="completed" <?= $status_filter === 'completed' ? 'selected' : '' ?>>تکمیل‌شده</option>
                        <option value="canceled"  <?= $status_filter === 'canceled'  ? 'selected' : '' ?>>انصرافی</option>
                        <option value="all"       <?= $status_filter === 'all'       ? 'selected' : '' ?>>همه</option>
                       

                    </select>
                </div>

                <div id="ta-bulk-actions" style="display:none; gap:8px; align-items:center; ">
                    <span id="ta-selected-count" style="font-size:13px; color:#555;">۰ انتخاب‌شده</span>
                    <button class="ta-btn ta-btn-sm ta-btn-primary" onclick="taBulkUpdateStatus('active')">تغییر وضعیت به فعال</button>
                    <button class="ta-btn ta-btn-sm ta-btn-warning" onclick="taBulkUpdateStatus('completed')">تغییر وضعیت به تکمیل‌شده</button>
                </div>
                
                <?php $url_without_term = remove_query_arg( 'ta_term' ); ?>
                <div>
                    <label style="font-weight:600; margin-left:6px;">ترم:</label>
                    <select class="ta-select" style="width:auto"
                            onchange="window.location.href='<?= esc_url($url_without_term) ?>&ta_term='+this.value">
                        <option value="">همه</option>
                        <?php foreach ( $terms_list as $term ) : ?>
                            <option value="<?= (int) $term->id ?>" <?= (string)$term_filter === (string)$term->id ? 'selected' : '' ?>>
                                <?= esc_html( $term->name ) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <?php $url_without_product = remove_query_arg( 'ta_product' ); ?>
                <div>
                    <label style="font-weight:600; margin-left:6px;">دوره:</label>
                    <select class="ta-select" style="width:auto"
                            onchange="window.location.href='<?= esc_url($url_without_product) ?>&ta_product='+this.value">
                        <option value="">همه</option>
                        <?php foreach ( $products_list as $prod ) : ?>
                            <option value="<?= (int) $prod->ID ?>" <?= (string)$product_filter === (string)$prod->ID ? 'selected' : '' ?>>
                                <?= esc_html( $prod->post_title ) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <?php $url_without_grade = remove_query_arg( 'ta_grade' ); ?>
                <div>
                    <label style="font-weight:600; margin-left:6px;">نمره:</label>
                    <select class="ta-select" style="width:auto"
                            onchange="window.location.href='<?= esc_url($url_without_grade) ?>&ta_grade='+this.value">
                       <option value=""         <?= $grade_filter === ''         ? 'selected' : '' ?>>همه نمرات</option>
<option value="none"  <?= $grade_filter === 'none'  ? 'selected' : '' ?>>ثبت نشده</option>
<option value="pass"     <?= $grade_filter === 'pass'     ? 'selected' : '' ?>>قبولی</option>
<option value="repeat"   <?= $grade_filter === 'repeat'   ? 'selected' : '' ?>>تکرار دوره </option>
<option value="critique" <?= $grade_filter === 'critique' ? 'selected' : '' ?>>نقد اثر</option>

                    </select>
                </div>
            </div>

            <table class="ta-table">
                <thead>
                    <tr>
                        <th style="width:36px;"><input type="checkbox" id="ta-select-all" title="انتخاب همه" onchange="taToggleSelectAll(this.checked)"></th>
                        <th>نام</th><th>ترم</th><th>دوره</th><th>پیامرسان</th><th>گروه</th><th>وضعیت</th><th>نمره</th><th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ( empty($students) ) : ?>
                    <tr><td colspan="9" style="text-align:center;">هنرجویی یافت نشد.</td></tr>
                <?php else : ?>
                    <?php foreach ( $students as $s ) : ?>
                    <tr id="student-row-<?= $s->id ?>">
                        <td><input type="checkbox" class="ta-row-check" data-id="<?= $s->id ?>" onchange="taOnRowCheck()"></td>
                        <td>
                            <?= esc_html($s->display_name) ?>
                            <?php if ( ! empty( $s->is_blacklisted ) ) : ?>
                                <span class="ta-badge ta-badge-fail" style="font-size:10px; margin-right:5px;">در لیست سیاه</span>
                            <?php endif; ?>
                            <br><small><?= esc_html($s->user_email) ?></small>
                        </td>
                        <td><?= esc_html($s->term_name ?? '—') ?></td>
                        <td><?= $course_labels[$s->course_type] ?? '' ?></td>
                        <td><?= $m_labels[$s->messenger] ?? $s->messenger ?></td>
                        <td>
                            <?php if ($s->group_link) : ?>
                                <a href="<?= esc_url($s->group_link) ?>" target="_blank">ورود به گروه</a>
                            <?php else : ?>—<?php endif; ?>
                        </td>
                        <td>
    <?php if ( $s->status === 'completed' ) : ?>
        <span class="ta-badge ta-badge-pass">تکمیل‌شده</span>
    <?php elseif ( $s->status === 'canceled' ) : ?>
        <span class="ta-badge ta-badge-fail" style="background-color:#dc3545;color:#fff;">انصرافی</span>
    <?php else : ?>
        <span class="ta-badge ta-badge-pending">فعال</span>
    <?php endif; ?>
</td>

                        <td>
                            <?php if ($s->grade) : ?>
                                <span class="ta-badge ta-badge-<?= $s->grade ?>"><?= TA_Grade::grade_label($s->grade) ?></span>
                            <?php else : ?>
                                <span class="ta-badge ta-badge-pending">ثبت‌نشده</span>
                            <?php endif; ?>
                        </td>
                        <td>
<?php if ( $s->status !== 'canceled' ) : ?>
    <?php if ( TA_Settings_Helper::is_enabled( 'ta_grading_enabled' ) ) : ?>
    <button class="ta-btn ta-btn-sm" onclick="taShowGradeForm(<?= $s->student_id ?>, <?= $s->product_id ?>, '<?= esc_js($s->course_type) ?>', <?= $s->id ?>)">ثبت نمره</button>
    <?php endif; ?>
<?php endif; ?>
                            <?php if ( ! empty( $s->is_blacklisted ) ) : ?>
                                <button class="ta-btn ta-btn-sm" style="background-color:#6c757d;color:white;border-color:#6c757d;" onclick="taRemoveBlacklist(<?= $s->student_id ?>, '<?= esc_js($s->display_name) ?>')">لیست سیاه</button>
                            <?php else : ?>
                                <button class="ta-btn ta-btn-sm ta-btn-danger" onclick="taBlacklist(<?= $s->student_id ?>, '<?= esc_js($s->display_name) ?>')">لیست سیاه</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php if ( TA_Settings_Helper::is_enabled( 'ta_grading_enabled' ) ) : ?>
                    <tr id="grade-form-<?= $s->student_id ?>-<?= $s->product_id ?>" style="display:none">
                        <td colspan="9">
                            <div class="ta-grade-form">
                                <input type="hidden" id="assignment-id-<?= $s->student_id ?>-<?= $s->product_id ?>" value="<?= $s->id ?>">
                                <select class="ta-select" id="grade-select-<?= $s->student_id ?>-<?= $s->product_id ?>">
                                    <option value="pending">ثبت‌نشده</option>
                                    <option value="pass">قبولی</option>
                                    <option value="repeat">تکرار دوره</option>
                                    <?php if ($s->course_type === 'intro') : ?><option value="critique">نقد اثر</option><?php endif; ?>
                                </select>
                                <textarea class="ta-input" id="grade-notes-<?= $s->student_id ?>-<?= $s->product_id ?>" placeholder="توضیحات (اختیاری)" rows="2"></textarea>
                                <label style="display:flex; align-items:center; gap:6px; margin:8px 0; cursor:pointer;">
                                    <input type="checkbox" id="grade-complete-<?= $s->student_id ?>-<?= $s->product_id ?>" checked>
                                    <span>تکمیل (وضعیت تخصیص به «تکمیل‌شده» تغییر کند)</span>
                                </label>
                                <button class="ta-btn ta-btn-primary" onclick="taSubmitGrade(<?= $s->student_id ?>, <?= $s->product_id ?>)">ثبت نمره</button>
                                <button class="ta-btn" onclick="taHideGradeForm(<?= $s->student_id ?>, <?= $s->product_id ?>)">انصراف</button>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

  

    // ── حق‌الزحمه ────────────────────────────────────────────────────────────
    private function tab_payroll( object $ta ): void {
        $nonce = wp_create_nonce('ta_dashboard_nonce');
        ?>
        <div class="ta-section ta-payroll-ta-wrap" dir="rtl">

            <div class="tapr-header">
                <h3>💰 حق‌الزحمه من</h3>
                <p class="tapr-subtitle">درخواست‌های تایید حق‌الزحمه که ادمین برای شما ارسال کرده است</p>
            </div>

            <div id="tapr-loading" class="tapr-loading">
                <div class="ta-spinner"></div> در حال بارگذاری…
            </div>

            <div id="tapr-empty" class="tapr-empty" style="display:none">
                هیچ درخواست حق‌الزحمه‌ای وجود ندارد.
            </div>

            <div id="tapr-list" style="display:none"></div>

        </div>

        <!-- مودال تاریخچه استادیار -->
        <div id="tapr-history-overlay" class="ta-modal-overlay" style="display:none">
            <div class="ta-modal-box" style="width:520px;max-width:95vw">
                <div class="ta-modal-box-header">
                    <h4>📋 تاریخچه درخواست</h4>
                    <button id="tapr-history-close" class="ta-modal-close-btn">✕</button>
                </div>
                <div class="ta-modal-box-body" style="max-height:55vh;overflow-y:auto" id="tapr-history-body">
                </div>
                <div class="ta-modal-box-footer">
                    <button class="ta-btn" id="tapr-history-cancel">بستن</button>
                </div>
            </div>
        </div>

        <!-- مودال پاسخ استادیار -->
        <div id="tapr-respond-overlay" class="ta-modal-overlay" style="display:none">
            <div class="ta-modal-box">
                <div class="ta-modal-box-header">
                    <h4 id="tapr-respond-title">پاسخ به درخواست</h4>
                    <button id="tapr-respond-close" class="ta-modal-close-btn">✕</button>
                </div>
                <div class="ta-modal-box-body">
                    <div id="tapr-respond-info" class="tapr-respond-info"></div>
                    <div class="tapr-field">
                        <label>توضیحات شما (اختیاری)</label>
                        <textarea id="tapr-respond-note" rows="3" placeholder="دلیل تایید یا رد، سوالات و…"></textarea>
                    </div>
                </div>
                <div class="ta-modal-box-footer" style="flex-wrap:wrap;gap:8px">
                    <button class="ta-btn ta-btn-success" id="tapr-approve-btn">✅ تایید مبلغ جدید</button>
                    <div id="tapr-approve-prev-wrap" style="display:none">
                        <button class="ta-btn" id="tapr-approve-prev-btn" style="background:#8b5cf6;color:#fff">✅ تایید مبلغ قبلی</button>
                    </div>
                    <button class="ta-btn ta-btn-danger"  id="tapr-reject-btn">❌ رد می‌کنم</button>
                    <button class="ta-btn" id="tapr-respond-cancel">انصراف</button>
                </div>
            </div>
        </div>

        <style>
        .ta-payroll-ta-wrap{padding:0}
        .tapr-header{margin-bottom:20px}
        .tapr-header h3{margin:0 0 4px;font-size:18px;font-weight:800;color:#111827}
        .tapr-subtitle{margin:0;font-size:13px;color:#6b7280}
        .tapr-loading,.tapr-empty{display:flex;align-items:center;gap:10px;padding:40px 0;color:#6b7280;font-size:14px}
        .tapr-card{background:#fff;border:1.5px solid #e5e7eb;border-radius:14px;padding:20px;margin-bottom:16px;box-shadow:0 1px 4px rgba(0,0,0,.06)}
        .tapr-card-header{display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:14px}
        .tapr-term-name{font-size:16px;font-weight:800;color:#111827}
        .tapr-req-date{font-size:11px;color:#9ca3af;margin-top:2px}
        .tapr-status-badge{display:inline-flex;align-items:center;gap:5px;padding:5px 12px;border-radius:99px;font-size:12px;font-weight:700}
        .tapr-fee-row{display:flex;align-items:center;gap:8px;margin-bottom:14px;padding:12px;background:#f0fdf4;border-radius:10px;border:1px solid #bbf7d0}
        .tapr-fee-label{font-size:13px;color:#374151;font-weight:600}
        .tapr-fee-amount{font-size:20px;font-weight:900;color:#059669;font-family:monospace}
        .tapr-fee-unit{font-size:12px;color:#6b7280}
        .tapr-notes-row{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px}
        .tapr-note-box{padding:10px;background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px}
        .tapr-note-box-label{font-size:11px;font-weight:700;color:#6b7280;margin-bottom:5px}
        .tapr-note-box-content{font-size:13px;color:#374151;line-height:1.5}
        .tapr-actions{display:flex;gap:8px;flex-wrap:wrap}
        .tapr-paid-banner{display:flex;align-items:center;gap:8px;padding:10px 14px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;font-size:13px;font-weight:700;color:#1d4ed8}
        .tapr-field{display:flex;flex-direction:column;gap:6px}
        .tapr-field label{font-size:12px;font-weight:700;color:#374151}
        .tapr-field textarea{padding:8px 10px;border:1.5px solid #e5e7eb;border-radius:8px;font-size:13px;font-family:inherit;resize:vertical;min-height:80px;outline:none}
        .tapr-field textarea:focus{border-color:#3b82f6}
        .tapr-respond-info{background:#fffbeb;border:1px solid #fde68a;border-radius:8px;padding:12px;font-size:13px;margin-bottom:14px}
        .ta-modal-box-footer{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
        .tapr-card-diff{border-color:#fde68a;background:#fffbeb}
        .tapr-diff-alert{background:#fef3c7;border:1px solid #fde68a;border-radius:8px;padding:10px 14px;font-size:12px;color:#92400e;margin-bottom:12px}
        .tapr-sep{margin:0 8px;color:#d1d5db}
        .tapr-approved-fee{color:#1d4ed8!important}
        /* جدول مبالغ */
        .tapr-fee-table{width:100%;border-collapse:collapse;margin-bottom:14px;font-size:13px}
        .tapr-fee-table tbody tr{border-bottom:1px solid #f3f4f6}
        .tapr-fee-table tbody tr:last-child{border-bottom:none}
        .tapr-ft-label{padding:8px 10px;color:#374151;font-weight:600;width:55%}
        .tapr-ft-amount{padding:8px 10px;font-family:monospace;font-weight:800;font-size:15px;color:#059669;white-space:nowrap}
        .tapr-ft-unit{font-size:11px;font-weight:400;color:#9ca3af}
        .tapr-ft-status{padding:8px 10px;text-align:left}
        .tapr-ft-diff-row{background:#fef9ee}
        .tapr-ft-diff-row .tapr-ft-label,.tapr-ft-diff-row .tapr-ft-amount{font-weight:800}
        /* بخش تفاوت مستقل */
        .tapr-diff-section{border:2px solid #fde68a;background:#fffbeb;border-radius:12px;padding:14px;margin:12px 0}
        .tapr-diff-section-header{display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap}
        .tapr-diff-section-title{font-weight:800;font-size:13px;color:#92400e}
        .tapr-diff-section-badge{padding:2px 10px;border-radius:99px;font-size:11px;font-weight:700;white-space:nowrap}
        .tapr-diff-admin-note{font-size:12px;color:#6b7280;background:#f3f4f6;border-radius:6px;padding:6px 10px;margin-top:8px}
        /* جدول جزئیات breakdown */
        .tapr-section-title{font-size:12px;font-weight:700;color:#6b7280;margin:14px 0 6px;letter-spacing:.03em;text-transform:uppercase}
        .tapr-breakdown-toggle{margin:10px 0 4px}
        .tapr-breakdown-table-wrap{margin:6px 0 12px;overflow-x:auto;border-radius:10px;border:1.5px solid #e5e7eb}
        .tapr-bd-table{width:100%;border-collapse:collapse;font-size:12px}
        .tapr-bd-table thead tr{background:#f3f4f6}
        .tapr-bd-table thead th{padding:8px 10px;text-align:right;font-weight:700;color:#374151;border-bottom:2px solid #e5e7eb;white-space:nowrap}
        .tapr-bd-row{border-bottom:1px solid #f3f4f6}
        .tapr-bd-row:last-child{border-bottom:none}
        .tapr-bd-row td{padding:8px 10px;color:#374151}
        .tapr-bd-excluded td{color:#9ca3af;background:#fafafa}
        .tapr-bd-product{max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .tapr-bd-mono{font-family:monospace;font-weight:700;white-space:nowrap}
        .tapr-bd-fee{font-family:monospace;font-weight:800;color:#059669}
        .tapr-bd-fee-ex{color:#9ca3af!important}
        .tapr-bd-total{background:#eff6ff}
        .tapr-bd-total td{padding:8px 10px;font-size:13px}
        .tapr-excluded-lbl{background:#fee2e2;color:#991b1b;border-radius:4px;padding:1px 5px;font-size:10px;margin-right:4px}
        .tapr-course-chip{background:#ede9fe;color:#6d28d9;border-radius:6px;padding:2px 7px;font-size:11px;font-weight:700;white-space:nowrap}
        .tapr-chg-list{list-style:none;padding:0;margin:0;border-right:3px solid #e5e7eb;margin-right:8px}
        .tapr-chg-item{position:relative;padding:0 20px 12px 0;margin-right:-3px}
        .tapr-chg-item:last-child{padding-bottom:0}
        .tapr-chg-pay{background:linear-gradient(90deg,#eff6ff 0%,transparent 100%);border-radius:6px;padding-right:20px}
        .tapr-chg-dot{position:absolute;right:-7px;top:4px;width:12px;height:12px;border-radius:50%;border:2px solid #fff;box-shadow:0 0 0 2px #e5e7eb}
        .tapr-chg-body{display:flex;flex-direction:column;gap:4px}
        .tapr-chg-amount{font-size:15px;font-weight:800;font-family:monospace}
        .tapr-chg-meta{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
        .tapr-chg-date{font-size:11px;color:#9ca3af}
        .tapr-chg-status{padding:1px 8px;border-radius:99px;font-size:10px;font-weight:700;white-space:nowrap}
        .tapr-chg-note{font-size:11px;color:#6b7280;background:#f9fafb;border-radius:5px;padding:3px 7px;border:1px solid #e5e7eb}
        .tapr-changes-inline{padding:4px 0}
        /* جدول breakdown همیشه باز */
        .tapr-breakdown-table-wrap{margin:6px 0 12px;overflow-x:auto;border-radius:10px;border:1.5px solid #e5e7eb}
        /* تاریخچه */
        .tapr-timeline{padding:0;margin:0;list-style:none;border-right:3px solid #e5e7eb;margin-right:10px}
        .tapr-timeline-item{position:relative;padding:0 22px 14px 0;margin-right:-3px}
        .tapr-timeline-item:last-child{padding-bottom:0}
        .tapr-timeline-dot{position:absolute;right:-7px;top:4px;width:12px;height:12px;border-radius:50%;border:2px solid #fff;box-shadow:0 0 0 2px #e5e7eb}
        .tapr-dot-sent,.tapr-dot-resent{background:#8b5cf6}
        .tapr-dot-approved,.tapr-dot-ta_approved,.tapr-dot-admin_approved{background:#10b981}
        .tapr-dot-rejected,.tapr-dot-admin_rejected{background:#ef4444}
        .tapr-dot-ta_rejected{background:#f97316}
        .tapr-dot-paid{background:#1d4ed8}
        .tapr-tl-meta{font-size:11px;color:#9ca3af;margin-bottom:2px}
        .tapr-tl-action{font-size:13px;font-weight:700;color:#111827}
        .tapr-tl-fee{font-size:12px;color:#059669;font-family:monospace;font-weight:700}
        .tapr-tl-note{font-size:12px;color:#6b7280;margin-top:3px;background:#f9fafb;border-radius:6px;padding:4px 8px}
        .tapr-tl-empty{color:#9ca3af;font-size:13px;text-align:center;padding:20px}
        .ta-modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;display:flex;align-items:center;justify-content:center}
        .ta-modal-box{background:#fff;border-radius:14px;width:460px;max-width:95vw;box-shadow:0 20px 60px rgba(0,0,0,.2)}
        .ta-modal-box-header{padding:16px 20px 12px;border-bottom:1px solid #e5e7eb;display:flex;align-items:center;justify-content:space-between}
        .ta-modal-box-header h4{margin:0;font-size:15px;font-weight:700}
        .ta-modal-close-btn{background:none;border:none;font-size:18px;cursor:pointer;color:#888;line-height:1;padding:0}
        .ta-modal-box-body{padding:18px 20px}
        .ta-modal-box-footer{padding:14px 20px;border-top:1px solid #e5e7eb;display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}
        .ta-btn-danger{background:#ef4444;color:#fff;padding:7px 16px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;border:none}
        </style>

        <script>
        (function($){
            var ajaxUrl = '<?= admin_url('admin-ajax.php') ?>';
            var nonce   = '<?= $nonce ?>';

            // ── بارگذاری ─────────────────────────────────────────────────────
            function loadPayroll(){
                $.post(ajaxUrl, {action:'ta_payroll_ta_get_items', nonce:nonce}, function(res){
                    $('#tapr-loading').hide();
                    if(!res.success){ $('#tapr-empty').show(); return; }
                    var items=res.data;
                    if(!items||!items.length){ $('#tapr-empty').show(); return; }
                    renderItems(items);
                });
            }

            var STATUS_LABELS = {
                pending:     {label:'در انتظار پاسخ شما',       color:'#f59e0b', icon:'⏳'},
                ta_approved: {label:'تایید شما — منتظر ادمین', color:'#8b5cf6', icon:'✅'},
                ta_rejected: {label:'رد کردید',                 color:'#f97316', icon:'↩️'},
                approved:    {label:'تایید نهایی ادمین',         color:'#10b981', icon:'✅'},
                rejected:    {label:'رد شده توسط ادمین',        color:'#ef4444', icon:'❌'},
                paid:        {label:'پرداخت شده',                color:'#3b82f6', icon:'💳'},
            };

            // نگاشت نوع دوره به برچسب فارسی
            var COURSE_LABELS = {
                'خلاق':'خلاق','مقدماتی':'مقدماتی','پیشرفته':'پیشرفته','نقد اثر':'نقد اثر'
            };
            var DIFF_ST_LABELS = {
                'pending'    :{color:'#f59e0b',icon:'⏳',label:'انتظار تایید شما'},
                'ta_approved':{color:'#8b5cf6',icon:'✅',label:'تایید شما'},
                'ta_rejected':{color:'#f97316',icon:'↩️',label:'رد شده توسط شما'},
                'approved'   :{color:'#10b981',icon:'✅',label:'تایید نهایی ادمین'},
                'rejected'   :{color:'#ef4444',icon:'❌',label:'رد شده'},
                'paid'       :{color:'#3b82f6',icon:'💳',label:'پرداخت شده'},
            };

            function renderItems(items){
                var html='';
                $.each(items, function(i,r){
                    var st=STATUS_LABELS[r.status]||{label:r.status,color:'#888',icon:'•'};
                    var approvedFee    = parseFloat(r.approved_fee||0);
                    var prevApprovedFee= parseFloat(r.prev_approved_fee||0);
                    var sentFee        = parseFloat(r.total_fee||0);
                    var refFee         = approvedFee>0 ? approvedFee : (prevApprovedFee>0 ? prevApprovedFee : 0);
                    var hasDiff        = refFee>0 && Math.abs(refFee-sentFee)>1;

                    // داده‌های مسیر تفاوت مستقل
                    var diffStatus     = r.diff_status||null;
                    var diffAmount     = parseFloat(r.diff_amount||0);
                    var diffStInfo     = diffStatus ? (DIFF_ST_LABELS[diffStatus]||null) : null;

                    // تفاوت کنونی با آخرین تایید (ستون تفاوت)
                    var finalApproved  = approvedFee>0 ? approvedFee : (prevApprovedFee>0 ? prevApprovedFee : 0);
                    var realDiff       = finalApproved>0 ? (sentFee - finalApproved) : 0;

                    html+='<div class="tapr-card'+(hasDiff?' tapr-card-diff':'')+'" data-req-id="'+r.id+'">';

                    // ── هدر ─────────────────────────────────────────────────────
                    html+='<div class="tapr-card-header">';
                    html+='<div>';
                    html+='<div class="tapr-term-name">📅 ترم: '+esc(r.term_name)+'</div>';
                    html+='<div class="tapr-req-date">ارسال شده: '+esc(r.requested_at)+'</div>';
                    html+='</div>';
                    html+='</div>';

                    // ── جدول مبالغ اصلی ─────────────────────────────────────────
                    html+='<div class="tapr-section-title">💰 خلاصه مالی</div>';
                    html+='<table class="tapr-fee-table">';
                    html+='<tbody>';
                    html+='<tr><td class="tapr-ft-label">💸 مبلغ درخواست شده</td>';
                    html+='<td class="tapr-ft-amount">'+nfFa(sentFee)+' <span class="tapr-ft-unit">ت</span></td>';
                    html+='<td class="tapr-ft-status"></td></tr>';
                    if(refFee>0){
                        var refLbl=approvedFee>0?(r.status==='paid'?'💳 مبلغ پرداخت شده':'✅ مبلغ تایید شده'):'🔒 مبلغ قبلی تایید/پرداخت‌شده';
                        var refCol=approvedFee>0?'#10b981':'#6b7280';
                        html+='<tr><td class="tapr-ft-label" style="color:'+refCol+'">'+refLbl+'</td>';
                        html+='<td class="tapr-ft-amount" style="color:'+refCol+'">'+nfFa(refFee)+' <span class="tapr-ft-unit">ت</span></td>';
                        html+='<td class="tapr-ft-status"></td></tr>';
                    }
                    // نمایش تفاوت کنونی با آخرین تایید
                    if(finalApproved>0 && Math.abs(realDiff)>1){
                        var diffColor=realDiff>0?'#ef4444':'#059669';
                        var diffIcon=realDiff>0?'▲':'▼';
                        html+='<tr style="background:#fffbeb"><td class="tapr-ft-label" style="color:'+diffColor+'">⚡ تفاوت (کنونی − تایید شده)</td>';
                        html+='<td class="tapr-ft-amount" style="color:'+diffColor+'">'+diffIcon+' '+nfFa(Math.abs(realDiff))+' <span class="tapr-ft-unit">ت</span></td>';
                        html+='<td class="tapr-ft-status"></td></tr>';
                    }
                    html+='</tbody></table>';



                    // ── جدول جزئیات کامل تخصیص‌ها (مشابه صفحه حسابداری ادمین) ──
                    if(r.breakdown && r.breakdown.length>0){
                        html+='<div class="tapr-section-title" style="margin-top:14px">📊 جزئیات محاسبه حق‌الزحمه</div>';
                        html+='<div class="tapr-breakdown-table-wrap" id="tapr-bd-'+r.id+'">';
                        html+='<table class="tapr-bd-table">';
                        html+='<thead><tr>';
                        html+='<th>#</th><th>هنرجو</th><th>دوره</th><th>نوع دوره</th><th>قیمت محاسبه</th><th>درصد</th><th>حق‌الزحمه</th><th>شامل محاسبه</th>';
                        html+='</tr></thead><tbody>';
                        var totalBd=0;
                        $.each(r.breakdown, function(j,b){
                            var excCls=b.excluded?' tapr-bd-excluded':'';
                            html+='<tr class="tapr-bd-row'+excCls+'">';
                            html+='<td style="color:#9ca3af;font-size:11px">'+toFa(j+1)+'</td>';
                            html+='<td style="font-weight:600">'+esc(b.student_name)+'</td>';
                            html+='<td class="tapr-bd-product">'+esc(b.product_name||'—')+'</td>';
                            var chipColors={'مقدماتی':'#dbeafe:#1e40af','پیشرفته':'#d1fae5:#065f46','خلاق':'#ede9fe:#6d28d9','حرفه‌ای':'#fef3c7:#92400e','نقد اثر':'#fee2e2:#991b1b'};
                            var cLabel=courseLabel(b.course_type);
                            var cColors=(chipColors[cLabel]||'#f3f4f6:#374151').split(':');
                            html+='<td><span class="tapr-course-chip" style="background:'+cColors[0]+';color:'+cColors[1]+'">'+esc(cLabel)+'</span></td>';
                            html+='<td class="tapr-bd-mono">'+nfFa(b.calc_price)+' ت</td>';
                            html+='<td class="tapr-bd-mono">'+toFa(b.rate)+'٪</td>';
                            html+='<td class="tapr-bd-fee'+(b.excluded?' tapr-bd-fee-ex':'')+'">'+
                                (b.excluded?'<s style="color:#9ca3af">'+nfFa(b.fee)+'</s> <span class="tapr-excluded-lbl">خارج</span>':nfFa(b.fee)+' ت')+'</td>';
                            html+='<td>'+(b.excluded?'<span style="color:#9ca3af;font-size:12px">خارج</span>':'<span style="color:#10b981;font-weight:700">✔ بله</span>')+'</td>';
                            html+='</tr>';
                            if(!b.excluded) totalBd+=b.fee;
                        });
                        html+='<tr class="tapr-bd-total">';
                        html+='<td colspan="6" style="font-weight:700;color:#374151">🔢 جمع کل حق‌الزحمه این ترم</td>';
                        html+='<td class="tapr-bd-fee" style="color:#1d4ed8;font-size:14px">'+nfFa(totalBd)+' ت</td><td></td></tr>';
                        html+='</tbody></table></div>';
                    }

                    // ── یادداشت‌ها ─────────────────────────────────────────────
                    html+='<div class="tapr-notes-row">';
                    html+='<div class="tapr-note-box"><div class="tapr-note-box-label">📋 توضیح ادمین</div>';
                    html+='<div class="tapr-note-box-content">'+(r.admin_note?esc(r.admin_note):'—')+'</div></div>';
                    html+='<div class="tapr-note-box"><div class="tapr-note-box-label">👤 پاسخ من</div>';
                    html+='<div class="tapr-note-box-content">'+(r.ta_note?esc(r.ta_note):'—')+'</div></div>';
                    html+='</div>';

                    // ── ستون تغییرات: Timeline کامل پرداخت‌ها ─────────────────
                    html+='<div class="tapr-section-title" style="margin-top:14px">📜 تاریخچه تغییرات</div>';
                    html+='<div class="tapr-changes-inline" id="tapr-changes-'+r.id+'">';
                    html+='<div style="color:#9ca3af;font-size:12px;padding:8px 0">⏳ در حال بارگذاری تاریخچه…</div>';
                    html+='</div>';

                    // ── اکشن مبلغ اصلی ────────────────────────────────────────
                    if(r.status==='paid'){
                        html+='<div class="tapr-paid-banner">💳 حق‌الزحمه اصلی پرداخت شده است';
                        if(r.paid_at) html+=' — تاریخ: '+esc(r.paid_at);
                        html+='</div>';
                    } else if(r.status==='pending' || r.status==='ta_rejected'){
                        html+='<div class="tapr-actions">';
                        var prevFee=prevApprovedFee>0?prevApprovedFee:(approvedFee>0?approvedFee:0);
                        var hasPrevDiff=prevFee>0&&Math.abs(prevFee-sentFee)>1;
                        html+='<button class="ta-btn ta-btn-primary tapr-respond-btn"'+
                            ' data-req-id="'+r.id+'"'+
                            ' data-fee="'+sentFee+'"'+
                            ' data-prev-fee="'+prevFee+'"'+
                            ' data-has-diff="'+(hasPrevDiff?1:0)+'"'+
                            ' data-term="'+esc(r.term_name)+'">💬 پاسخ به درخواست</button>';
                        html+='</div>';
                    }

                    html+='</div>'; // end card
                });
                $('#tapr-list').html(html).show();

                // بارگذاری تاریخچه تغییرات برای هر کارت
                $.each(items, function(i,r){
                    loadChanges(r.id);
                });
            }

            // ── تابع بارگذاری تاریخچه تغییرات (inline) ──────────────────────
            var CHANGE_LABELS_TA={
                sent:          {icon:'📨', label:'درخواست دریافت شد',             color:'#3b82f6'},
                resent:        {icon:'🔄', label:'درخواست مجدد دریافت شد',        color:'#8b5cf6'},
                ta_approved:   {icon:'✅', label:'شما تایید کردید',               color:'#8b5cf6'},
                ta_rejected:   {icon:'↩️', label:'شما رد کردید',                  color:'#f97316'},
                ta_approved_prev:{icon:'✅',label:'تایید مبلغ قبلی (توسط شما)',   color:'#8b5cf6'},
                admin_approved:{icon:'✅', label:'تایید نهایی ادمین',              color:'#10b981'},
                admin_rejected:{icon:'❌', label:'ادمین رد کرد',                  color:'#ef4444'},
                approved:      {icon:'✅', label:'تایید نهایی',                   color:'#10b981'},
                rejected:      {icon:'❌', label:'رد شد',                         color:'#ef4444'},
                paid:          {icon:'💳', label:'پرداخت انجام شد',               color:'#1d4ed8'},
                diff_ta_approved:{icon:'✅',label:'تایید تفاوت (توسط شما)',       color:'#8b5cf6'},
                diff_ta_rejected:{icon:'↩️',label:'رد تفاوت (توسط شما)',          color:'#f97316'},
                diff_admin_approved:{icon:'✅',label:'تایید تفاوت توسط ادمین',   color:'#10b981'},
                diff_admin_rejected:{icon:'❌',label:'رد تفاوت توسط ادمین',      color:'#ef4444'},
                diff_paid:     {icon:'💳', label:'پرداخت تفاوت انجام شد',         color:'#1d4ed8'},
            };

            function loadChanges(reqId){
                $.post(ajaxUrl,{action:'ta_payroll_ta_get_logs',nonce:nonce,req_id:reqId})
                .done(function(res){
                    var $wrap=$('#tapr-changes-'+reqId);
                    if(!$wrap.length) return;
                    if(!res||!res.success||!res.data||!res.data.length){
                        $wrap.html('<div style="color:#9ca3af;font-size:12px;padding:6px 0">هنوز سابقه‌ای ثبت نشده.</div>');
                        return;
                    }
                    var logs=res.data;
                    var html='<ul class="tapr-chg-list">';
                    var prevChgFee=0;
                    $.each(logs,function(i,l){
                        var a=CHANGE_LABELS_TA[l.action]||{icon:'•',label:l.action,color:'#888'};
                        var isPay=(l.action==='paid'||l.action==='diff_paid');
                        var curChgFee=parseFloat(l.total_fee||0);
                        html+='<li class="tapr-chg-item'+(isPay?' tapr-chg-pay':'')+'">';
                        html+='<div class="tapr-chg-dot" style="background:'+a.color+'"></div>';
                        html+='<div class="tapr-chg-body">';
                        // مبلغ + تفاوت
                        if(curChgFee>0){
                            html+='<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">';
                            html+='<div class="tapr-chg-amount" style="color:'+a.color+'">'+a.icon+' '+nfFa(curChgFee)+' تومان</div>';
                            if(prevChgFee>0 && Math.abs(curChgFee-prevChgFee)>1){
                                var chgDiff=curChgFee-prevChgFee;
                                var chgClr=chgDiff>0?'#10b981':'#ef4444';
                                var chgIco=chgDiff>0?'▲':'▼';
                                var chgLbl=chgDiff>0?'افزایش':'کاهش';
                                html+='<span style="display:inline-flex;align-items:center;gap:3px;background:'+(chgDiff>0?'#d1fae5':'#fee2e2')+';color:'+chgClr+';padding:2px 8px;border-radius:99px;font-size:10px;font-weight:700">'+chgIco+' '+nfFa(Math.abs(chgDiff))+' ت '+chgLbl+'</span>';
                            }
                            html+='</div>';
                            prevChgFee=curChgFee;
                        }
                        // تاریخ و وضعیت
                        html+='<div class="tapr-chg-meta">';
                        html+='<span class="tapr-chg-date">📅 '+esc(l.created_at)+'</span>';
                        html+='<span class="tapr-chg-status" style="background:'+a.color+'18;color:'+a.color+';border:1px solid '+a.color+'33">'+a.label+'</span>';
                        html+='</div>';
                        // یادداشت
                        if(l.note) html+='<div class="tapr-chg-note">💬 '+esc(l.note)+'</div>';
                        html+='</div></li>';
                    });
                    html+='</ul>';
                    $wrap.html(html);
                })
                .fail(function(){
                    $('#tapr-changes-'+reqId).html('<div style="color:#9ca3af;font-size:12px">خطا در بارگذاری</div>');
                });
            }

            // ── مودال پاسخ ───────────────────────────────────────────────────
            var _curReqId=0;

            var _curPrevFee=0, _curHasDiff=false;

            $(document).on('click','.tapr-respond-btn',function(){
                _curReqId   = $(this).data('req-id');
                _curPrevFee = parseFloat($(this).data('prev-fee')||0);
                _curHasDiff = $(this).data('has-diff')==1;
                var fee  = parseFloat($(this).data('fee'));
                var term = $(this).data('term');

                var infoHtml = 'ترم: <strong>'+esc(term)+'</strong>';
                infoHtml += ' &nbsp;|&nbsp; مبلغ جدید: <strong style="color:#1d4ed8">'+nfFa(fee)+'</strong> تومان';

                if(_curHasDiff && _curPrevFee>0){
                    var diff=fee-_curPrevFee;
                    infoHtml+='<br><span style="color:#f59e0b;font-size:12px">⚠️ مبلغ قبلی تایید شده: <strong>'+nfFa(_curPrevFee)+'</strong> ت';
                    infoHtml+=' &nbsp;(تفاوت: '+(diff>0?'<span style=color:#ef4444>+':'<span style=color:#059669>')+nfFa(Math.abs(diff))+'</span> ت)</span>';
                    // نمایش دکمه تایید مبلغ قبلی
                    $('#tapr-approve-prev-wrap').show();
                    $('#tapr-approve-prev-btn').text('✅ تایید مبلغ قبلی ('+nfFa(_curPrevFee)+' ت)');
                } else {
                    $('#tapr-approve-prev-wrap').hide();
                }

                $('#tapr-respond-info').html(infoHtml);
                $('#tapr-respond-note').val('');
                $('#tapr-respond-overlay').fadeIn(150);
            });

            function doRespond(action){
                var $btn;
                if(action==='approve')      $btn=$('#tapr-approve-btn');
                else if(action==='reject')  $btn=$('#tapr-reject-btn');
                else                        $btn=$('#tapr-approve-prev-btn');
                $btn.prop('disabled',true).text('…');

                var postData={
                    action:'ta_payroll_ta_respond', nonce:nonce,
                    req_id:_curReqId, ta_action:action, ta_note:$('#tapr-respond-note').val()
                };
                if(action==='approve_prev') postData.prev_fee=_curPrevFee;

                $.post(ajaxUrl, postData, function(res){
                    var origLabel = action==='approve'?'✅ تایید مبلغ جدید':
                                   action==='reject' ?'❌ رد می‌کنم':
                                                      '✅ تایید مبلغ قبلی ('+nfFa(_curPrevFee)+' ت)';
                    $btn.prop('disabled',false).text(origLabel);
                    if(res.success){
                        $('#tapr-respond-overlay').fadeOut(150);
                        $('#tapr-loading').show(); $('#tapr-list').hide();
                        loadPayroll();
                    } else alert(res.data||'خطا');
                });
            }

            $('#tapr-approve-btn').on('click',function(){ doRespond('approve'); });
            $('#tapr-reject-btn').on('click', function(){ doRespond('reject');  });
            $('#tapr-approve-prev-btn').on('click',function(){ doRespond('approve_prev'); });
            $('#tapr-respond-close,#tapr-respond-cancel').on('click',function(){ $('#tapr-respond-overlay').fadeOut(150); });
            $('#tapr-respond-overlay').on('click',function(e){ if($(e.target).is(this)) $(this).fadeOut(150); });

            // ── تاریخچه (modal همچنان برای compatibility) ───────────────────────────────────────
            var TA_ACTION_LABELS={
                ta_approved_prev:{icon:'✅', label:'تایید مبلغ قبلی (توسط شما)',  cls:'tapr-dot-ta_approved'},
                sent:          {icon:'📨', label:'درخواست دریافت شد',            cls:'tapr-dot-sent'},
                resent:        {icon:'🔄', label:'درخواست مجدد دریافت شد',       cls:'tapr-dot-resent'},
                ta_approved:   {icon:'✅', label:'شما تایید کردید',               cls:'tapr-dot-ta_approved'},
                ta_rejected:   {icon:'↩️', label:'شما رد کردید',                  cls:'tapr-dot-ta_rejected'},
                admin_approved:{icon:'✅', label:'ادمین تایید نهایی کرد',          cls:'tapr-dot-approved'},
                admin_rejected:{icon:'❌', label:'ادمین رد کرد',                  cls:'tapr-dot-rejected'},
                approved:      {icon:'✅', label:'تایید نهایی ادمین',              cls:'tapr-dot-approved'},
                rejected:      {icon:'❌', label:'رد شد',                         cls:'tapr-dot-rejected'},
                paid:          {icon:'💳', label:'پرداخت انجام شد',               cls:'tapr-dot-paid'},
            };

            $(document).on('click','.tapr-history-btn',function(){
                var reqId=$(this).data('req-id');
                $('#tapr-history-body').html('<div style="padding:20px;text-align:center;color:#9ca3af">در حال بارگذاری…</div>');
                $('#tapr-history-overlay').fadeIn(150);
                $.post(ajaxUrl,{action:'ta_payroll_ta_get_logs',nonce:nonce,req_id:reqId})
                .done(function(res){
                    if(!res||!res.success){
                        $('#tapr-history-body').html('<div class="tapr-tl-empty" style="color:#ef4444">⚠️ خطا در بارگذاری'+(res&&res.data?' ('+res.data+')':'')+'</div>');
                        return;
                    }
                    var logs=res.data;
                    if(!logs||!logs.length){$('#tapr-history-body').html('<div class="tapr-tl-empty">هیچ سابقه‌ای ثبت نشده.</div>');return;}
                    var html='<ul class="tapr-timeline">';
                    $.each(logs,function(i,l){
                        var a=TA_ACTION_LABELS[l.action]||{icon:'•',label:l.action,cls:''};
                        html+='<li class="tapr-timeline-item">';
                        html+='<span class="tapr-timeline-dot '+a.cls+'"></span>';
                        html+='<div class="tapr-tl-meta">'+esc(l.created_at)+'</div>';
                        html+='<div><span class="tapr-tl-action">'+a.icon+' '+a.label+'</span>';
                        if(parseFloat(l.total_fee)>0) html+=' &nbsp;<span class="tapr-tl-fee">'+nfFa(l.total_fee)+' ت</span>';
                        html+='</div>';
                        if(l.note) html+='<div class="tapr-tl-note">'+esc(l.note)+'</div>';
                        html+='</li>';
                    });
                    html+='</ul>';
                    $('#tapr-history-body').html(html);
                })
                .fail(function(xhr,status,err){
                    $('#tapr-history-body').html('<div class="tapr-tl-empty" style="color:#ef4444">⚠️ خطای شبکه</div>');
                });
            });
            $('#tapr-history-close,#tapr-history-cancel').on('click',function(){$('#tapr-history-overlay').fadeOut(150);});
            $('#tapr-history-overlay').on('click',function(e){if($(e.target).is(this))$(this).fadeOut(150);});

            function nf(n){ return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g,','); }
            function esc(s){ return $('<div>').text(s||'').html(); }

            function toFa(n){ return Math.round(n).toString(); }
            function nfFa(n){ return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g,','); }

            // نگاشت نوع دوره انگلیسی به فارسی
            var COURSE_LABEL_MAP={
                'intro':'مقدماتی','advanced':'پیشرفته','creative':'خلاق',
                'professional':'حرفه‌ای','critique':'نقد اثر'
            };
            function courseLabel(ct){ return COURSE_LABEL_MAP[ct]||ct||'—'; }

            loadPayroll();

        })(jQuery);
        </script>
        <?php
    }

    // ── نقد داستان ──────────────────────────────────────────────────────────
    private function tab_story_critique( object $ta ): void {
        $nonce    = wp_create_nonce( 'ta_dashboard_nonce' );
        $enabled  = TA_Settings_Helper::is_enabled( 'story_critique_enabled' );
        $bale_link = 'ble.ir/join/CqUvdvAhhB';
        ?>
        <div class="ta-section ta-sc-wrap" dir="rtl">

            <div class="ta-sc-header">
                <h3>✍️ نقد داستان</h3>
                <p class="ta-sc-subtitle">اگر در حوزه نقد داستان فعالیت می‌کنید، فرم زیر را تکمیل کنید تا به گروه ما بپیوندید.</p>
            </div>

            <?php if ( ! $enabled ) : ?>
            <div class="ta-sc-disabled-notice">
                🔒 درخواست نقد داستان در حال حاضر غیرفعال است.
            </div>
            <?php else : ?>

            <!-- فرم -->
            <!-- لودر اولیه -->
            <div id="ta-sc-init-loading" style="display:flex;align-items:center;gap:10px;padding:32px 0;color:#6b7280;font-size:14px">
                <div class="ta-spinner"></div> در حال بارگذاری…
            </div>

            <div id="ta-sc-form-wrap" style="display:none">
                <div class="ta-sc-form-card">

                    <!-- ردیف ۱: اطلاعات شخصی -->
                    <div class="ta-sc-grid-3">
                        <div class="ta-sc-field">
                            <label>نام و نام‌خانوادگی <span class="ta-sc-req">*</span></label>
                            <input type="text" id="ta-sc-full-name" placeholder="مثلاً: علی محمدی" maxlength="100">
                        </div>
                        <div class="ta-sc-field">
                            <label>شماره تماس <span class="ta-sc-req">*</span></label>
                            <input type="tel" id="ta-sc-phone" placeholder="09123456789" maxlength="15" dir="ltr">
                        </div>
                        <div class="ta-sc-field">
                            <label>آیدی بله <span class="ta-sc-req">*</span></label>
                            <input type="text" id="ta-sc-bale-id" placeholder="@username" maxlength="80" dir="ltr">
                        </div>
                    </div>

                    <!-- تخصص‌ها -->
                    <div class="ta-sc-field ta-sc-field-full">
                        <label>در چه حوزه‌ای تخصص نقد دارید؟ <span class="ta-sc-req">*</span> <span class="ta-sc-hint">(چند گزینه قابل انتخاب)</span></label>
                        <div class="ta-sc-chips-grid" id="ta-sc-specialties">
                            <?php
                            $specs = ['کودک','نوجوان','رمان','طنز','داستان','روایت','فیلمنامه','مرورنویسی','نقد فیلم','تسهیلگر در حوزه کتاب‌خوانی'];
                            $colors = ['#dbeafe:#1e40af','#d1fae5:#065f46','#ede9fe:#6d28d9','#fef3c7:#92400e','#fee2e2:#991b1b','#e0f2fe:#0369a1','#fdf4ff:#7e22ce','#fff7ed:#c2410c','#f0fdf4:#166534','#fce7f3:#9d174d'];
                            foreach($specs as $i => $s):
                                $c = explode(':', $colors[$i % count($colors)]);
                            ?>
                            <label class="ta-sc-chip-label" style="--chip-bg:<?= $c[0] ?>;--chip-fg:<?= $c[1] ?>">
                                <input type="checkbox" class="ta-sc-spec" value="<?= esc_attr($s) ?>">
                                <span><?= esc_html($s) ?></span>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- سایر موارد -->
                    <div class="ta-sc-field ta-sc-field-full">
                        <label>اگر موردی هست که اینجا ذکر نشده، بنویسید <span class="ta-sc-hint">(اختیاری)</span></label>
                        <textarea id="ta-sc-other" rows="2" placeholder="توضیح دهید…"></textarea>
                    </div>

                    <!-- ساعات -->
                    <div class="ta-sc-field ta-sc-field-full">
                        <label>چند ساعت در روز می‌توانید وقت بگذارید؟ (چند متن در هفته نقد می‌کنید؟) <span class="ta-sc-req">*</span></label>
                        <input type="text" id="ta-sc-hours" placeholder="مثلاً: ۲ ساعت در روز / ۳ تا ۵ متن در هفته">
                    </div>

                    <!-- ارسال -->
                    <div class="ta-sc-actions">
                        <button id="ta-sc-submit" class="ta-btn ta-btn-primary ta-sc-submit-btn">
                            📨 ارسال درخواست نقد
                        </button>
                        <div id="ta-sc-msg" class="ta-sc-msg" style="display:none"></div>
                    </div>

                </div>
            </div>

            <!-- بعد از ارسال -->
            <div id="ta-sc-success-wrap" style="display:none">
                <div class="ta-sc-success-card">
                    <div class="ta-sc-success-icon">✅</div>
                    <h4>فرم با موفقیت ثبت شد!</h4>
                    <p>برای ارتباط بیشتر و عضویت در گروه روی دکمه زیر کلیک کنید:</p>
                    <a href="https://<?= esc_attr($bale_link) ?>" target="_blank" class="ta-btn ta-sc-join-btn">
                        💬 عضویت در گروه نقد داستان
                    </a>
                    <p class="ta-sc-link-raw"><?= esc_html($bale_link) ?></p>
                    <button id="ta-sc-edit-btn" class="ta-btn ta-sc-edit-btn">✏️ ویرایش اطلاعات</button>
                </div>
            </div>

            <?php endif; ?>

        </div>

        <style>
        .ta-sc-wrap { padding: 0; }
        .ta-sc-header { margin-bottom: 20px; }
        .ta-sc-header h3 { margin: 0 0 4px; font-size: 18px; font-weight: 800; color: #111827; }
        .ta-sc-subtitle { margin: 0; font-size: 13px; color: #6b7280; }
        .ta-sc-disabled-notice { padding: 20px; background: #f9fafb; border: 1.5px solid #e5e7eb; border-radius: 12px; color: #6b7280; font-size: 14px; text-align: center; }
        .ta-sc-form-card { background: #fff; border: 1.5px solid #e5e7eb; border-radius: 14px; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,.05); }
        .ta-sc-grid-3 { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 16px; margin-bottom: 18px; }
        .ta-sc-field { display: flex; flex-direction: column; gap: 6px; margin-bottom: 16px; }
        .ta-sc-field-full { margin-bottom: 16px; }
        .ta-sc-field label, .ta-sc-field-full label { font-size: 13px; font-weight: 700; color: #374151; }
        .ta-sc-req { color: #ef4444; }
        .ta-sc-hint { font-weight: 400; color: #9ca3af; font-size: 11px; }
        .ta-sc-field input, .ta-sc-field textarea, .ta-sc-field-full input, .ta-sc-field-full textarea {
            padding: 9px 12px; border: 1.5px solid #e5e7eb; border-radius: 8px; font-size: 13px; font-family: inherit; outline: none; transition: border-color .15s;
        }
        .ta-sc-field input:focus, .ta-sc-field-full input:focus, .ta-sc-field-full textarea:focus { border-color: #6c5ce7; }
        .ta-sc-chips-grid { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 6px; }
        .ta-sc-chip-label { display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; border-radius: 99px; cursor: pointer; font-size: 13px; font-weight: 600; border: 2px solid transparent; transition: all .15s; background: #f3f4f6; color: #374151; user-select: none; }
        .ta-sc-chip-label input { display: none; }
        .ta-sc-chip-label.active { background: var(--chip-bg); color: var(--chip-fg); border-color: var(--chip-fg); }
        .ta-sc-actions { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; margin-top: 4px; }
        .ta-sc-submit-btn { font-size: 14px; padding: 10px 24px; border-radius: 10px; font-weight: 700; }
        .ta-sc-msg { font-size: 13px; padding: 8px 14px; border-radius: 8px; }
        .ta-sc-msg.error { background: #fee2e2; color: #991b1b; }
        .ta-sc-msg.info { background: #eff6ff; color: #1e40af; }
        .ta-sc-success-card { background: #f0fdf4; border: 2px solid #86efac; border-radius: 14px; padding: 32px 24px; text-align: center; }
        .ta-sc-success-icon { font-size: 3rem; margin-bottom: 10px; }
        .ta-sc-success-card h4 { margin: 0 0 8px; font-size: 18px; font-weight: 800; color: #166534; }
        .ta-sc-success-card p { color: #374151; font-size: 14px; margin: 0 0 14px; }
        .ta-sc-join-btn { background: #0369a1; color: #fff; padding: 10px 24px; border-radius: 10px; font-size: 14px; font-weight: 700; text-decoration: none; display: inline-block; }
        .ta-sc-link-raw { font-size: 12px; color: #9ca3af; margin-top: 10px !important; direction: ltr; }
        .ta-sc-edit-btn { background: #f3f4f6; color: #374151; padding: 8px 18px; border-radius: 8px; font-size: 12px; margin-top: 12px; border: 1.5px solid #e5e7eb; cursor: pointer; }
        </style>

        <script>
        (function($){
            var ajaxUrl = '<?= admin_url('admin-ajax.php') ?>';
            var nonce   = '<?= $nonce ?>';

            // بارگذاری داده‌های موجود
            $.post(ajaxUrl, {action:'ta_story_critique_get', nonce:nonce}, function(res){
                $('#ta-sc-init-loading').hide();
                if(res.success && res.data){
                    prefillForm(res.data);
                    if(res.data.is_saved){
                        // فرم قبلاً ارسال شده — فقط حالت موفقیت نمایش داده می‌شود
                        showSuccess();
                    } else {
                        // فرم جدید — نام/تلفن پیش‌پر شده، منتظر ارسال
                        $('#ta-sc-form-wrap').show();
                    }
                } else {
                    // هیچ داده‌ای نیست — فرم خالی
                    $('#ta-sc-form-wrap').show();
                }
            }).fail(function(){
                $('#ta-sc-init-loading').hide();
                $('#ta-sc-form-wrap').show();
            });

            function prefillForm(d){
                $('#ta-sc-full-name').val(d.full_name||'');
                $('#ta-sc-phone').val(d.phone||'');
                $('#ta-sc-bale-id').val(d.bale_id||'');
                $('#ta-sc-other').val(d.other_specialty||'');
                $('#ta-sc-hours').val(d.hours_per_day||'');
                if(Array.isArray(d.specialties)){
                    d.specialties.forEach(function(s){
                        $('.ta-sc-spec').filter(function(){ return $(this).val()===s; }).closest('.ta-sc-chip-label').addClass('active').find('input').prop('checked',true);
                    });
                }
            }

            function showSuccess(){
                $('#ta-sc-form-wrap').hide();
                $('#ta-sc-success-wrap').show();
            }
            function showForm(){
                $('#ta-sc-success-wrap').hide();
                $('#ta-sc-form-wrap').show();
            }

            // chip toggle
            $(document).on('click','.ta-sc-chip-label',function(){
                var $l=$(this);
                var $cb=$l.find('input');
                $cb.prop('checked',!$cb.prop('checked'));
                $l.toggleClass('active',$cb.prop('checked'));
            });

            // ارسال فرم
            $('#ta-sc-submit').on('click',function(){
                var fullName=$('#ta-sc-full-name').val().trim();
                var phone   =$('#ta-sc-phone').val().trim();
                var baleId  =$('#ta-sc-bale-id').val().trim();
                var other   =$('#ta-sc-other').val().trim();
                var hours   =$('#ta-sc-hours').val().trim();
                var specs   =[];
                $('.ta-sc-spec:checked').each(function(){ specs.push($(this).val()); });

                if(!fullName||!phone||!baleId||!hours){
                    showMsg('لطفاً فیلدهای ضروری را پر کنید.','error'); return;
                }

                var $btn=$(this).prop('disabled',true).text('در حال ارسال…');
                var data={action:'ta_story_critique_submit',nonce:nonce,full_name:fullName,phone:phone,bale_id:baleId,other_specialty:other,hours_per_day:hours};
                specs.forEach(function(s,i){ data['specialties['+i+']']=s; });

                $.post(ajaxUrl,data,function(res){
                    $btn.prop('disabled',false).text('📨 ارسال درخواست نقد');
                    if(res.success){
                        showSuccess();
                    } else {
                        showMsg(res.data||'خطا در ارسال','error');
                    }
                });
            });

            $('#ta-sc-edit-btn').on('click', showForm);

            function showMsg(msg,type){
                var $m=$('#ta-sc-msg').text(msg).removeClass('error info').addClass(type).show();
                setTimeout(function(){ $m.fadeOut(); },4000);
            }

        })(jQuery);
        </script>
        <?php
    }

    // ── لیست سیاه ───────────────────────────────────────────────────────────
    private function tab_blacklist( object $ta ): void {
        $bl_table = TA_Database::table( 'blacklist' );
        global $wpdb;

        $list = $wpdb->get_results( $wpdb->prepare(
            "SELECT bl.*, u.display_name, u.user_email
             FROM {$bl_table} bl
             JOIN {$wpdb->users} u ON u.ID = bl.student_id
             WHERE bl.ta_id = %d
             ORDER BY bl.created_at DESC",
            [ $ta->id ]
        ) );
        ?>
        <div class="ta-section">
            <h3>لیست سیاه</h3>
            <?php if ( empty($list) ) : ?>
                <p>لیست سیاه خالی است.</p>
            <?php else : ?>
            <table class="ta-table">
                <thead>
                    <tr><th>هنرجو</th><th>دلیل</th><th>تاریخ</th><th>عملیات</th></tr>
                </thead>
                <tbody>
                <?php foreach ($list as $row) : ?>
                    <tr>
                        <td><?= esc_html($row->display_name) ?><br><small><?= esc_html($row->user_email) ?></small></td>
                        <td><?= esc_html($row->reason ?: '—') ?></td>
                        <td><?= esc_html($row->created_at) ?></td>
                        <td>
                            <button class="ta-btn ta-btn-sm" 
                                onclick="taRemoveBlacklist(<?= $row->student_id ?>)">
                                حذف از لیست
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <?php
    }
}
