<?php
/**
 * Plugin Name:       TA System – تخصیص استادیار
 * Plugin URI:        https://yoursite.com
 * Description:       سیستم تخصیص استادیار به هنرجویان دوره‌های نویسندگی
 * Version: 1.5.0
 * Author:            جمال جمشیدی
 * Text Domain:       ta-system
 * Domain Path:       /languages
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * WC requires at least: 7.0
 */

defined( 'ABSPATH' ) || exit;

// ─────────────────────────────────────────────────────────────────────────────
// ثوابت
// ─────────────────────────────────────────────────────────────────────────────
define( 'TA_SYSTEM_VERSION',  '1.3.3' );
define( 'TA_SYSTEM_PATH',     plugin_dir_path( __FILE__ ) );
define( 'TA_SYSTEM_URL',      plugin_dir_url( __FILE__ ) );
define( 'TA_SYSTEM_BASENAME', plugin_basename( __FILE__ ) );

// ─────────────────────────────────────────────────────────────────────────────
// بررسی پیش‌نیازها (PHP + WP + WooCommerce)
// این بررسی‌ها پیش از هر autoload انجام می‌شوند تا هیچ Fatal Error رخ ندهد
// ─────────────────────────────────────────────────────────────────────────────
if ( ! ta_system_check_requirements() ) {
    return; // بقیه فایل اجرا نمی‌شود
}

// ─────────────────────────────────────────────────────────────────────────────
// Autoloader
// ─────────────────────────────────────────────────────────────────────────────
spl_autoload_register( function ( string $class ): void {
    static $map = [
        // includes
        'TA_Database'          => 'includes/class-database.php',
        'TA_Roles'             => 'includes/class-roles.php',
        'TA_Product_Meta'      => 'includes/class-product-meta.php',
        'TA_Eligibility'       => 'includes/class-eligibility.php',
        'TA_Assignment'        => 'includes/class-assignment.php',
        'TA_Grade'             => 'includes/class-grade.php',
        'TA_Level_Assessment'  => 'includes/class-level-assess.php',
        'TA_Ajax'              => 'includes/class-ajax.php',
        'TA_User_Helper'       => 'includes/class-user-helper.php',
        'TA_Xlsx_Reader'       => 'includes/class-xlsx-reader.php',
        // admin
        'TA_Admin_Menu'        => 'admin/class-admin-menu.php',
        'TA_Admin_TA_Manager'  => 'admin/class-ta-manager.php',
        'TA_Admin_Import'      => 'admin/class-import.php',
        'TA_Admin_Assignments' => 'admin/class-assignment-manager.php',
        'TA_Product_Settings'  => 'admin/class-product-settings.php',
        'TA_Admin_Customers'   => 'admin/class-admin-customers.php',
        'TA_Grades_Manager'    => 'admin/class-grades-manager.php',
        'TA_Payroll'           => 'admin/class-payroll.php',
        'TA_Settings'          => 'admin/class-settings.php',
        'TA_Settings_Helper'   => 'includes/class-settings-helper.php',
        // [FIX-UNASSIGNED] اضافه شد به autoloader
        'TA_Admin_Unassigned_Orders' => 'admin/class-unassigned-orders.php',
        // frontend
        'TA_Dashboard_TA'      => 'frontend/class-dashboard-ta.php',
        'TA_Product_Widget'    => 'frontend/class-product-widget.php',
        'TA_Student_Portal'    => 'frontend/class-student-portal.php',
    ];

    if ( isset( $map[ $class ] ) ) {
        $file = TA_SYSTEM_PATH . $map[ $class ];
        if ( file_exists( $file ) ) {
            require_once $file;
        }
    }
} );

// ─────────────────────────────────────────────────────────────────────────────
// Activation / Deactivation
// ─────────────────────────────────────────────────────────────────────────────
register_activation_hook( __FILE__, static function (): void {
    if ( ! ta_system_woocommerce_active() ) {
        deactivate_plugins( TA_SYSTEM_BASENAME );
        wp_die(
            '<p>افزونه TA System برای فعال‌شدن نیاز به <strong>WooCommerce</strong> دارد.</p>',
            'خطای فعال‌سازی',
            [ 'back_link' => true ]
        );
    }
    TA_Database::install();
    TA_Roles::add_roles();
} );

register_deactivation_hook( __FILE__, [ 'TA_Roles', 'remove_roles' ] );

// ─────────────────────────────────────────────────────────────────────────────
// Boot — اجرای اصلی افزونه
// ─────────────────────────────────────────────────────────────────────────────
add_action( 'plugins_loaded', static function (): void {

    // WooCommerce بررسی مجدد (ممکن است بعد از activation غیرفعال شده باشد)
    if ( ! ta_system_woocommerce_active() ) {
        add_action( 'admin_notices', static function (): void {
            $link = admin_url( 'plugin-install.php?s=woocommerce&tab=search&type=term' );
            echo wp_kses_post(
                '<div class="notice notice-error">'
                . '<p><strong>TA System:</strong> این افزونه نیاز به '
                . '<a href="' . esc_url( $link ) . '">WooCommerce</a>'
                . ' دارد. لطفاً ابتدا WooCommerce را نصب و فعال کنید.</p>'
                . '</div>'
            );
        } );
        return;
    }

    // اطمینان از به‌روز بودن جداول دیتابیس
    TA_Database::maybe_install();

    // هسته
    new TA_Product_Meta();
    new TA_Ajax();

    // ادمین
    if ( is_admin() ) {
        new TA_Admin_Menu();       // منو را ثبت می‌کند (TA_Capacity_Manager داخل register_menus ساخته می‌شود)
        new TA_Product_Settings();
        new TA_Admin_TA_Manager();
        new TA_Admin_Import();
        new TA_Admin_Assignments();
        // [FIX-DOUBLE-SETTINGS] TA_Settings فقط یک‌بار اینجا ساخته می‌شود
        // page_settings() در admin-menu فقط render() را صدا می‌زند، نه new TA_Settings()
        new TA_Settings();
        new TA_Payroll();

        // [FIX-DOUBLE-CAPACITY] TA_Capacity_Manager فقط از TA_Admin_Menu::register_menus() ساخته می‌شود
        // نمونه‌سازی اینجا حذف شد تا از ثبت تکراری AJAX hooks جلوگیری شود
    }

    // فرانت‌اند
    new TA_Product_Widget();
    new TA_Dashboard_TA();
    new TA_Student_Portal();

}, 10 );

// ─────────────────────────────────────────────────────────────────────────────
// توابع کمکی
// ─────────────────────────────────────────────────────────────────────────────

/**
 * بررسی اینکه آیا WooCommerce فعال است
 */
function ta_system_woocommerce_active(): bool {
    return class_exists( 'WooCommerce' );
}

/**
 * بررسی تمام پیش‌نیازها و نمایش نوتیس در صورت مشکل.
 * اگر همه چیز درست باشد true برمی‌گرداند.
 */
function ta_system_check_requirements(): bool {
    $errors = [];

    // PHP
    if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
        $errors[] = sprintf(
            'TA System نیاز به PHP نسخه ۸.۰ یا بالاتر دارد. نسخه فعلی: %s',
            PHP_VERSION
        );
    }

    // WordPress
    global $wp_version;
    if ( isset( $wp_version ) && version_compare( $wp_version, '6.0', '<' ) ) {
        $errors[] = sprintf(
            'TA System نیاز به WordPress نسخه ۶.۰ یا بالاتر دارد. نسخه فعلی: %s',
            $wp_version
        );
    }

    // افزونه‌های مورد نیاز
    $required_plugins = [
        'WooCommerce' => [
            'class'  => 'WooCommerce',
            'name'   => 'WooCommerce',
            'url'    => 'https://wordpress.org/plugins/woocommerce/',
        ],
    ];

    // WooCommerce ممکن است در plugins_loaded هنوز بارگذاری نشده باشد
    // پس این بررسی فقط اگر is_admin() باشد و plugins لود شده باشند اجرا می‌شود
    if ( did_action( 'plugins_loaded' ) || doing_action( 'plugins_loaded' ) ) {
        foreach ( $required_plugins as $id => $plugin ) {
            if ( ! class_exists( $plugin['class'] ) ) {
                $errors[] = sprintf(
                    'TA System نیاز به <a href="%s" target="_blank">%s</a> دارد.',
                    esc_url( $plugin['url'] ),
                    esc_html( $plugin['name'] )
                );
            }
        }
    }

    if ( empty( $errors ) ) {
        return true;
    }

    // نمایش نوتیس‌های خطا فقط در پنل ادمین
    add_action( 'admin_notices', static function () use ( $errors ): void {
        foreach ( $errors as $msg ) {
            echo wp_kses_post(
                '<div class="notice notice-error is-dismissible"><p>'
                . '<strong>TA System:</strong> ' . $msg
                . '</p></div>'
            );
        }
    } );

    // اگر فقط مشکل PHP یا WP version است (نه WooCommerce که بعداً چک می‌شود) برگردان false
    $hard_errors = array_filter( $errors, fn($e) => str_contains($e, 'PHP') || str_contains($e, 'WordPress') );
    return empty( $hard_errors );
}
