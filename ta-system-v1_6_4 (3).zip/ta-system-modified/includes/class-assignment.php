<?php
defined( 'ABSPATH' ) || exit;

class TA_Assignment {

    public static function get_available_tas(
        string $course_type,
        int    $term_id,
        string $messenger,
        string $student_gender,
        int    $student_id
    ): array {
        global $wpdb;

        $ta_table    = TA_Database::table( 'assistants' );
        $cap_table   = TA_Database::table( 'capacities' );
        $bl_table    = TA_Database::table( 'blacklist' );
        $group_table = TA_Database::table( 'groups' );

        // کوئری پایه با تمام ستون‌های مورد نیاز فرانت‌اند از جمله ta_name و remaining
        $sql_base = "
            SELECT
                ta.*,
                cap.id             AS capacity_id,
                cap.total_capacity,
                cap.used_capacity,
                cap.student_gender AS cap_gender,
                (cap.total_capacity - cap.used_capacity) AS remaining,
                u.display_name     AS ta_name
            FROM {$ta_table}    ta
            JOIN {$cap_table}   cap ON cap.ta_id       = ta.id
                                   AND cap.course_type  = %s
                                   AND cap.term_id      = %d
                                   AND cap.student_gender IN (%s, 'both')
                                   AND cap.messenger IN (%s, 'both')
            JOIN {$wpdb->users} u   ON u.ID = ta.user_id
            LEFT JOIN {$bl_table} bl ON bl.ta_id = ta.id AND bl.student_id = %d
            WHERE ta.is_active  = 1
              AND bl.id         IS NULL
              AND cap.used_capacity < cap.total_capacity
        ";

        // آرایه پارامترها برای بایند شدن به کوئری
        $params = [ $course_type, $term_id, $student_gender, $messenger, $student_id ];

        // دریافت وضعیت تنظیمات دریافت لینک از هنرجو
        $allow_custom_link = TA_Settings_Helper::is_enabled( 'allow_custom_group_link' );

        // شرط ویژه برای دوره خلاق: 
        // فقط در صورتی چک کن که گروه آزاد حتماً وجود داشته باشد، که مدیر دریافت لینک را غیرفعال کرده باشد!
        if ( $course_type === 'creative' && ! $allow_custom_link ) {
            $sql_base .= "
                AND EXISTS (
                    SELECT 1 FROM {$group_table} g 
                    WHERE g.capacity_id = cap.id 
                      AND g.messenger_type = %s 
                      AND g.is_used = 0
                )
            ";
            $params[] = $messenger;
        }

        // مرتب‌سازی نهایی
        $sql_base .= " ORDER BY " . TA_Settings_Helper::ta_sort_sql();

        // اجرای کوئری
        $sql = $wpdb->prepare( $sql_base, ...$params );
        $rows = $wpdb->get_results( $sql );

        if ( ! $rows ) {
            return [];
        }

        // فیلتر نهایی در PHP
        $seen     = [];
        $filtered = [];
        foreach ( $rows as $row ) {
            if ( isset( $seen[ $row->id ] ) ) continue;
            $seen[ $row->id ] = true;
            $filtered[] = $row;
        }

        return $filtered;
    }

    /**
     * تخصیص استادیار به هنرجو — نویسندگی خلاق
     * در صورت نبود گروه آزاد و فعال بودن تنظیمات، لینک را از کاربر دریافت و ثبت می‌کند
     */
    public static function assign_creative(
        int    $student_id,
        int    $ta_id,
        int    $product_id,
        int    $term_id,
        string $messenger,
        string $student_gender,
        string $custom_group_link = '' // پارامتر جدید برای دریافت لینک کاربر
    ): array {
        global $wpdb;

        if ( TA_Eligibility::already_assigned( $student_id, $product_id ) ) {
            return [ 'success' => false, 'message' => 'شما قبلاً استادیار انتخاب کرده‌اید.' ];
        }

        $group_table = TA_Database::table( 'groups' );
        $cap_table   = TA_Database::table( 'capacities' );

        // پیدا کردن گروه آزاد با پیامرسان درست
        $group = $wpdb->get_row( $wpdb->prepare(
            "SELECT g.* FROM {$group_table} g
             JOIN {$cap_table} c ON c.id = g.capacity_id
             WHERE g.ta_id = %d
               AND g.messenger_type = %s
               AND g.is_used = 0
               AND c.course_type = 'creative'
               AND c.term_id = %d
               AND c.student_gender IN (%s, 'both')
               AND c.used_capacity < c.total_capacity
             ORDER BY c.student_gender DESC, g.id ASC
             LIMIT 1",
            $ta_id,
            $messenger,
            $term_id,
            $student_gender
        ) );

        $group_id         = 0;
        $final_group_link = '';
        $needs_new_group  = false;
        $capacity_id      = 0;

        // اگر گروه آزادی یافت نشد
        if ( ! $group ) {
            // بررسی فعال بودن قابلیت دریافت لینک از کاربر در تنظیمات
            $allow_custom_link = TA_Settings_Helper::is_enabled( 'allow_custom_group_link' );

            if ( $allow_custom_link ) {
                if ( empty( $custom_group_link ) ) {
                    // درخواست لینک از کاربر (بازگشت به فرانت‌اند برای نمایش فرم)
                    return [
                        'success'    => false,
                        'needs_link' => true,
                        'message'    => 'لطفا در پیامرسانی که انتخاب کرده‌اید یک گروه بسازید و لینک آن را اینجا وارد کنید. به زودی استادیار انتخاب شده به گروه ملحق خواهد شد.'
                    ];
                }

                // پیدا کردن ظرفیت برای ساخت گروه جدید
                $capacity = $wpdb->get_row( $wpdb->prepare(
                    "SELECT id FROM {$cap_table}
                     WHERE ta_id = %d
                       AND course_type = 'creative'
                       AND term_id = %d
                       AND messenger IN (%s, 'both')
                       AND student_gender IN (%s, 'both')
                       AND used_capacity < total_capacity
                     ORDER BY student_gender DESC
                     LIMIT 1",
                    $ta_id, $term_id, $messenger, $student_gender
                ) );

                if ( ! $capacity ) {
                    return [ 'success' => false, 'message' => 'متأسفانه ظرفیت این استادیار به طور کامل پر شده است.' ];
                }

                $needs_new_group  = true;
                $capacity_id      = (int) $capacity->id;
                $final_group_link = $custom_group_link;

            } else {
                return [ 'success' => false, 'message' => 'متأسفانه ظرفیت این استادیار با پیامرسان انتخابی پر شده است.' ];
            }
        } else {
            $group_id         = (int) $group->id;
            $final_group_link = $group->group_link;
            $capacity_id      = (int) $group->capacity_id; // مقدارگیری دقیق ظرفیت گروه یافت‌شده
        }

        $wpdb->query( 'START TRANSACTION' );
        try {
            // ساخت گروه جدید با لینک کاربر در صورت نیاز
            if ( $needs_new_group ) {
                TA_Database::insert( 'ta_groups', [
                    'ta_id'               => $ta_id,
                    'capacity_id'         => $capacity_id, // استفاده از capacity_id
                    'messenger_type'      => $messenger,
                    'group_link'          => $final_group_link,
                    'is_used'             => 1,
                    'assigned_to_user_id' => $student_id,
                    'assigned_at'         => current_time( 'mysql' )
                ] );
                $group_id = $wpdb->insert_id;
            } else {
                // به‌روزرسانی گروه از پیش ساخته شده
                TA_Database::update( 'ta_groups', [
                    'is_used'             => 1,
                    'assigned_to_user_id' => $student_id,
                    'assigned_at'         => current_time( 'mysql' ),
                ], [ 'id' => $group_id ] );
            }

            // ثبت تخصیص نهایی (تغییر مهم: ذخیره capacity_id انجام شد)
            TA_Database::insert( 'ta_assignments', [
                'student_id'     => $student_id,
                'ta_id'          => $ta_id,
                'capacity_id'    => $capacity_id, // <-- اضافه شدن شماره ظرفیت
                'product_id'     => $product_id,
                'term_id'        => $term_id,
                'course_type'    => 'creative',
                'messenger'      => $messenger,
                'student_gender' => $student_gender,
                'group_id'       => $group_id,
                'group_link'     => $final_group_link,
                'status'         => TA_Settings_Helper::default_assignment_status(),
                'created_at'     => current_time( 'mysql' ),
            ] );

            // افزایش used_capacity — فقط اگر auto_sync_capacity فعال باشد
            if ( TA_Settings_Helper::is_enabled( 'auto_sync_capacity' ) ) {
                $wpdb->query( $wpdb->prepare(
                    "UPDATE {$cap_table} SET used_capacity = used_capacity + 1 
                     WHERE id = %d 
                     AND used_capacity < total_capacity",
                    $capacity_id
                ) );
            }

            $wpdb->query( 'COMMIT' );

            TA_Settings_Helper::log( "assign_creative: student={$student_id} ta={$ta_id} product={$product_id}" );
            TA_Settings_Helper::send_notification( 'admin_new_assignment', [
                'student_name' => get_userdata($student_id)->display_name ?? '',
                'ta_name'      => get_userdata($ta_id)->display_name ?? '',
                'product_name' => get_the_title($product_id),
            ] );
            TA_Settings_Helper::send_notification( 'student_assigned', [
                'student_email' => get_userdata($student_id)->user_email ?? '',
                'ta_name'       => get_userdata($ta_id)->display_name ?? '',
                'product_name'  => get_the_title($product_id),
            ] );
            return [
                'success'    => true,
                'message'    => TA_Settings_Helper::get_text('text_assignment_success'),
                'group_link' => $final_group_link,
            ];
            
        } catch ( Throwable $e ) {
            $wpdb->query( 'ROLLBACK' );
            
            TA_Settings_Helper::log( 'assign_creative error: ' . $e->getMessage() );
            return [ 'success' => false, 'message' => 'خطایی رخ داد. لطفاً دوباره تلاش کنید.' ];
        }
    }

    /**
     * تخصیص استادیار — مقدماتی و پیشرفته (گروه از هنرجو می‌آید)
     */
    public static function assign_with_student_group(
        int    $student_id,
        int    $ta_id,
        int    $product_id,
        int    $term_id,
        string $course_type,
        string $messenger,
        string $student_gender,
        string $group_link
    ): array {
        global $wpdb;

        if ( TA_Eligibility::already_assigned( $student_id, $product_id ) ) {
            return [ 'success' => false, 'message' => 'شما قبلاً استادیار انتخاب کرده‌اید.' ];
        }

        $cap_table = TA_Database::table( 'capacities' );

        $wpdb->query( 'START TRANSACTION' );
        try {

            // تغییر مهم: ابتدا ظرفیت مناسب را پیدا می‌کنیم تا capacity_id را داشته باشیم
            $capacity = $wpdb->get_row( $wpdb->prepare(
                "SELECT id FROM {$cap_table}
                 WHERE ta_id = %d 
                   AND term_id = %d 
                   AND course_type = %s
                   AND messenger IN (%s, 'both')
                   AND (student_gender = %s OR student_gender = 'both')
                   AND used_capacity < total_capacity
                 ORDER BY (student_gender = 'both') ASC, (messenger = 'both') ASC
                 LIMIT 1",
                $ta_id, $term_id, $course_type, $messenger, $student_gender
            ) );

            if ( ! $capacity ) {
                $wpdb->query( 'ROLLBACK' );
                return [ 'success' => false, 'message' => 'متأسفانه ظرفیت این استادیار پر شده است.' ];
            }

            $capacity_id = (int) $capacity->id;

            // ثبت رکورد همراه با capacity_id
            TA_Database::insert( 'ta_assignments', [
                'student_id'     => $student_id,
                'ta_id'          => $ta_id,
                'capacity_id'    => $capacity_id, // <-- اضافه شدن شماره ظرفیت
                'product_id'     => $product_id,
                'term_id'        => $term_id,
                'course_type'    => $course_type,
                'messenger'      => $messenger,
                'student_gender' => $student_gender,
                'group_id'       => null,
                'group_link'     => $group_link,
                'status'         => TA_Settings_Helper::default_assignment_status(),
                'created_at'     => current_time( 'mysql' ),
            ] );

            // تخصیص ظرفیت — فقط اگر auto_sync_capacity فعال باشد
            if ( TA_Settings_Helper::is_enabled( 'auto_sync_capacity' ) ) {
                $wpdb->query( $wpdb->prepare(
                    "UPDATE {$cap_table}
                     SET used_capacity = used_capacity + 1
                     WHERE id = %d",
                    $capacity_id
                ) );
            }

            $wpdb->query( 'COMMIT' );
            TA_Settings_Helper::log( "assign_with_group: student={$student_id} product={$product_id}" );
            TA_Settings_Helper::send_notification( 'admin_new_assignment', [
                'student_name' => get_userdata($student_id)->display_name ?? '',
                'ta_name'      => get_userdata($ta_id)->display_name ?? '',
                'product_name' => get_the_title($product_id),
            ] );
            TA_Settings_Helper::send_notification( 'student_assigned', [
                'student_email' => get_userdata($student_id)->user_email ?? '',
                'ta_name'       => get_userdata($ta_id)->display_name ?? '',
                'product_name'  => get_the_title($product_id),
            ] );
            return [ 'success' => true, 'message' => TA_Settings_Helper::get_text('text_assignment_success') ];
        } catch ( \Exception $e ) {
            $wpdb->query( 'ROLLBACK' );
            return [ 'success' => false, 'message' => 'خطایی رخ داد. لطفاً دوباره تلاش کنید.' ];
        }
    }

    /**
     * دریافت تخصیص هنرجو برای یک محصول
     */
    public static function get_assignment( int $student_id, int $product_id ): ?object {
        $table = TA_Database::table( 'assignments' );
        return TA_Database::get_row(
            "SELECT a.*, u.display_name AS ta_name
             FROM {$table} a
             JOIN {$GLOBALS['wpdb']->users} u ON u.ID = (
                SELECT user_id FROM {$GLOBALS['wpdb']->prefix}ta_assistants WHERE id = a.ta_id
             )
             WHERE a.student_id = %d AND a.product_id = %d",
            [ $student_id, $product_id ]
        );
    }
    
    public static function assign_professional_course( $student_id, $ta_id, $product_id ) {
    global $wpdb;

    // ۱. استخراج ترم جاری (سیستم شما احتمالا متدی شبیه به این دارد)
    $current_term = TA_Capacity_Manager::get_current_term(); 
    if ( ! $current_term ) {
        return [ 'success' => false, 'message' => 'ترم جاری در سیستم تعریف نشده است.' ];
    }

    // ۲. بررسی ظرفیت استادیار اختصاصی برای دوره حرفه‌ای در ترم جاری
    $capacity_table = $wpdb->prefix . 'ta_capacities';
    $capacity_row = $wpdb->get_row( $wpdb->prepare(
        "SELECT id, capacity, used_capacity FROM {$capacity_table} 
         WHERE ta_id = %d AND term = %s AND course_type = 'professional'",
        $ta_id, $current_term
    ) );

    if ( ! $capacity_row ) {
        return [ 'success' => false, 'message' => 'ظرفیتی برای این استادیار در ترم جاری تعریف نشده است.' ];
    }

    if ( $capacity_row->used_capacity >= $capacity_row->capacity ) {
        return [ 'success' => false, 'message' => 'متأسفانه ظرفیت استادیار اختصاصی این دوره تکمیل شده است.' ];
    }

    // ۳. ثبت رکورد تخصیص در دیتابیس
    $assignment_table = $wpdb->prefix . 'ta_assignments';
    $inserted = $wpdb->insert(
        $assignment_table,
        [
            'student_id'  => $student_id,
            'ta_id'       => $ta_id,
            'product_id'  => $product_id,
            'term'        => $current_term,
            'course_type' => 'professional',
            'status'      => 'active',
            'created_at'  => current_time( 'mysql' )
        ],
        [ '%d', '%d', '%d', '%s', '%s', '%s', '%s' ]
    );

    if ( ! $inserted ) {
        return [ 'success' => false, 'message' => 'خطا در ثبت اطلاعات در پایگاه داده.' ];
    }

    // ۴. به‌روزرسانی (افزایش) ظرفیت استفاده‌شده
    $wpdb->query( $wpdb->prepare(
        "UPDATE {$capacity_table} SET used_capacity = used_capacity + 1 WHERE id = %d",
        $capacity_row->id
    ) );

    return [ 'success' => true ];
    }
/**
 * تخصیص استاندارد بر اساس ظرفیت
 * برای دوره‌های: standard, critique, professional
 *
 * @return array ['success'=>bool, 'message'=>string, 'group_link'=>string|null]
 */



public static function assign_standard_with_capacity(
    int $student_id,
    int $ta_id,
    int $product_id,
    int $capacity_id,
    string $messenger,
    string $student_gender,
    string $custom_group_link = ''
): array {
    global $wpdb;

    // ۱. بررسی واجد شرایط بودن هنرجو
    $eligibility = TA_Eligibility::check( $student_id, $product_id );
    if ( ! $eligibility['eligible'] ) {
        return [
            'success'    => false,
            'message'    => $eligibility['message'],
            'group_link' => null
        ];
    }

    // ۲. دریافت اطلاعات ظرفیت
    $cap_table = TA_Database::table( 'capacities' );
    $capacity  = $wpdb->get_row( $wpdb->prepare(
        "SELECT ta_id, course_type, term_id, student_gender, messenger,
                total_capacity, used_capacity
         FROM {$cap_table}
         WHERE id = %d",
        $capacity_id
    ) );

    if ( ! $capacity ) {
        return [
            'success'    => false,
            'message'    => 'ظرفیت مورد نظر یافت نشد.',
            'group_link' => null
        ];
    }

    // ۳. بررسی تطابق ta_id
    if ( (int) $capacity->ta_id !== $ta_id ) {
        return [
            'success'    => false,
            'message'    => 'ظرفیت انتخابی متعلق به این استادیار نیست.',
            'group_link' => null
        ];
    }

    // ۴. بررسی ظرفیت باقیمانده
    if ( $capacity->used_capacity >= $capacity->total_capacity ) {
        return [
            'success'    => false,
            'message'    => 'ظرفیت این استادیار تکمیل شده است.',
            'group_link' => null
        ];
    }

    // ۵. بررسی تطابق جنسیت
    if ( $capacity->student_gender !== 'both' && $capacity->student_gender !== $student_gender ) {
        return [
            'success'    => false,
            'message'    => 'جنسیت هنرجو با ظرفیت استادیار مطابقت ندارد.',
            'group_link' => null
        ];
    }

    // ۶. بررسی تطابق پیام‌رسان
    if ( $capacity->messenger !== 'both' && $capacity->messenger !== $messenger ) {
        return [
            'success'    => false,
            'message'    => 'پیام‌رسان انتخابی با ظرفیت استادیار مطابقت ندارد.',
            'group_link' => null
        ];
    }

    // ۷. یافتن لینک گروه — ابتدا از ta_groups
    $groups_table = TA_Database::table( 'groups' );
    $group = $wpdb->get_row( $wpdb->prepare(
        "SELECT id, group_link
         FROM {$groups_table}
         WHERE capacity_id = %d
           AND messenger_type = %s
           AND is_used = 0
         LIMIT 1",
        $capacity_id,
        $messenger
    ) );

    $group_id   = 0;
    $group_link = '';

    if ( $group ) {
        // ✅ گروه آزاد پیدا شد
        $group_id   = (int) $group->id;
        $group_link = $group->group_link;

    } elseif ( ! empty( $custom_group_link ) ) {
        // ✅ لینک از بیرون (AJAX handler) داده شده
        $group_link = $custom_group_link;

    } else {
        // ❌ نه گروه آزاد هست نه لینک جایگزین

        $course_type = $capacity->course_type;

        if ( $course_type === 'creative' ) {
            // دوره خلاق: بررسی تنظیم دریافت لینک از کاربر
            $allow_custom = TA_Settings_Helper::is_enabled( 'allow_custom_group_link' );
            if ( $allow_custom ) {
                return [
                    'success'    => false,
                    'needs_link' => true,
                    'message'    => 'لطفا در پیامرسانی که انتخاب کرده‌اید یک گروه بسازید و لینک آن را اینجا وارد کنید.'
                ];
            }
            return [
                'success'    => false,
                'message'    => 'گروه آزاد برای این ظرفیت موجود نیست.',
                'group_link' => null
            ];
        }

        // مقدماتی/پیشرفته/نقد/حرفه‌ای — نباید به اینجا برسه
        // چون AJAX handler باید لینک رو آماده کرده باشه
        return [
            'success'    => false,
            'message'    => 'لینک گروه برای این ظرفیت و پیام‌رسان موجود نیست.',
            'group_link' => null
        ];
    }

    // ۸. ثبت تخصیص
  /*  $wpdb->query( 'START TRANSACTION' );
    try {
        TA_Database::insert( 'ta_assignments', [
            'student_id'     => $student_id,
            'ta_id'          => $ta_id,
            'product_id'     => $product_id,
            'term_id'        => $capacity->term_id,
            'capacity_id'    => $capacity_id,
            'course_type'    => $capacity->course_type,
            'messenger'      => $messenger,
            'student_gender' => $student_gender,
            'group_id'       => $group_id,
            'group_link'     => $group_link,
            'status'         => 'active',
            'created_at'     => current_time( 'mysql' ),
        ] );

        // ۹. اگر گروه از ta_groups بود، علامت‌گذاری
        if ( $group_id > 0 ) {
            TA_Database::update( 'ta_groups', [
                'is_used'             => 1,
                'assigned_to_user_id' => $student_id,
                'assigned_at'         => current_time( 'mysql' ),
            ], [
                'id' => $group_id,
            ] );
        }*/
        
        
            // ۸. ثبت تخصیص
    $wpdb->query( 'START TRANSACTION' );
    try {
        // ۹. بررسی وضعیت گروه: به‌روزرسانی گروه موجود یا درج گروه جدید (لینک کاربر)
        if ( $group_id > 0 ) {
            TA_Database::update( 'ta_groups', [
                'is_used'             => 1,
                'assigned_to_user_id' => $student_id,
                'assigned_at'         => current_time( 'mysql' ),
            ], [
                'id' => $group_id,
            ] );
        } elseif ( ! empty( $group_link ) ) {
            // ساخت گروه جدید برای لینک‌های وارد شده توسط کاربر (از جمله خلاق)
            TA_Database::insert( 'ta_groups', [
                'ta_id'               => $ta_id,
                'capacity_id'         => $capacity_id,
                'messenger_type'      => $messenger,
                'group_link'          => $group_link,
                'is_used'             => 1,
                'assigned_to_user_id' => $student_id,
                'assigned_at'         => current_time( 'mysql' )
            ] );
            $group_id = $wpdb->insert_id; // دریافت آیدی گروه جدید
        }

        // ثبت در جدول تخصیص‌ها
        TA_Database::insert( 'ta_assignments', [
            'student_id'     => $student_id,
            'ta_id'          => $ta_id,
            'product_id'     => $product_id,
            'term_id'        => $capacity->term_id,
            'capacity_id'    => $capacity_id,
            'course_type'    => $capacity->course_type,
            'messenger'      => $messenger,
            'student_gender' => $student_gender,
            'group_id'       => $group_id, // حالا آیدی به درستی ثبت می‌شود
            'group_link'     => $group_link,
            'status'         => 'active',
            'created_at'     => current_time( 'mysql' ),
        ] );

        

        // ۱۰. افزایش ظرفیت استفاده‌شده
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$cap_table}
             SET used_capacity = used_capacity + 1
             WHERE id = %d",
            $capacity_id
        ) );

        $wpdb->query( 'COMMIT' );

        return [
            'success'    => true,
            'message'    => 'تخصیص با موفقیت انجام شد.',
            'group_link' => $group_link,
        ];

    } catch ( \Exception $e ) {
        $wpdb->query( 'ROLLBACK' );
        return [
            'success'    => false,
            'message'    => 'خطا در ثبت تخصیص. لطفاً دوباره تلاش کنید.',
            'group_link' => null,
        ];
    }
}







}
