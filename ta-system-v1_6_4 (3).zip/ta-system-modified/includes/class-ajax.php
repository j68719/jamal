<?php
defined( 'ABSPATH' ) || exit;

/**
 * تمام درخواست‌های AJAX سیستم
 *
 * اصلاحات نسخه 1.1.1:
 * - [FIX-01] admin_assign_with_custom_link: امضای تابع assign_standard_with_capacity کامل شد (product_id + student_gender)
 * - [FIX-02] get_prev_course_info: احراز هویت اضافه شد (admin: ta_admin_nonce | frontend: ta_product_nonce)
 * - [FIX-03] ثبت تکراری action حذف شد
 * - [FIX-04] update_assignment_group: nonce اصلاح شد (ta_ajax_nonce → ta_admin_nonce)
 * - [FIX-05] admin_get_available_tas: پیام‌های DEBUG از production حذف شدند
 * - [FIX-06] grade_student: بررسی status=active قبل از ثبت نمره اضافه شد
 * - [FIX-07] save_capacity: whitelist برای course_type اضافه شد
 */
class TA_Ajax {

    /** انواع دوره معتبر */
    private const VALID_COURSE_TYPES = [ 'creative', 'intro', 'advanced', 'professional', 'critique' ];

    public function __construct() {
        $actions = [
            'ta_get_available_tas'             => 'get_available_tas',
            'ta_assign_creative'               => 'assign_creative',
            'ta_assign_with_group'             => 'assign_with_group',
            'ta_grade_student'                 => 'grade_student',
            'ta_save_capacity'                 => 'save_capacity',
            'ta_add_group_slot'                => 'add_group_slot',
            'ta_update_capacity'               => 'update_capacity',
            'ta_delete_capacity'               => 'delete_capacity',
            'ta_update_group_slot'             => 'update_group_slot',
            'ta_delete_group_slot'             => 'delete_group_slot',
            'ta_blacklist_student'             => 'blacklist_student',
            'ta_remove_from_blacklist'         => 'remove_from_blacklist',
            'ta_assign_critique'               => 'assign_critique',
            'ta_assign_professional'           => 'assign_professional',
            'ta_bulk_update_assignment_status' => 'bulk_update_assignment_status',
            'ta_admin_get_available_tas'       => 'admin_get_available_tas',
            'ta_admin_assign_by_capacity'      => 'admin_assign_by_capacity',
            'ta_get_capacity_groups'           => 'get_capacity_groups',
            'ta_get_capacity_assignments'      => 'get_capacity_assignments',
            'ta_get_term_stats'                => 'get_term_stats',
        ];

        foreach ( $actions as $action => $method ) {
            add_action( "wp_ajax_{$action}", [ $this, $method ] );
        }

        // نقد داستان
        add_action( 'wp_ajax_ta_story_critique_submit', [ $this, 'story_critique_submit' ] );
        add_action( 'wp_ajax_ta_story_critique_get',    [ $this, 'story_critique_get' ] );

        // [FIX-03] ثبت بدون تکرار — قبلاً دوبار ثبت می‌شد
        add_action( 'wp_ajax_ta_update_assignment_group',       [ $this, 'update_assignment_group' ] );
        add_action( 'wp_ajax_ta_admin_assign_with_custom_link', [ $this, 'admin_assign_with_custom_link' ] );

        // [FIX-02] دو handler جدا با nonce متفاوت
        add_action( 'wp_ajax_ta_admin_get_prev_course_info', [ $this, 'admin_get_prev_course_info' ] );
        add_action( 'wp_ajax_ta_get_prev_course_info',       [ $this, 'frontend_get_prev_course_info' ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // [FIX-02] اطلاعات دوره قبلی — نسخه ادمین (با ta_admin_nonce)
    // ─────────────────────────────────────────────────────────────────────────

    public function admin_get_prev_course_info(): void {
        check_ajax_referer( 'ta_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'دسترسی غیرمجاز.' ] );
        }

        $this->process_prev_course_info();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // [FIX-02] اطلاعات دوره قبلی — نسخه فرانت (با ta_product_nonce)
    // ─────────────────────────────────────────────────────────────────────────

    public function frontend_get_prev_course_info(): void {
        $this->verify( 'ta_product_nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => 'برای این عملیات باید وارد شوید.' ] );
        }

        // هنرجو فقط اطلاعات خودش را می‌تواند ببیند
        $student_id = get_current_user_id();
        $product_id = absint( $_POST['product_id'] ?? 0 );

        $prereqs        = TA_Product_Meta::get_prerequisites( $product_id );
        $prev_messenger = 'نامشخص';
        $prev_link      = 'نامشخص';

        foreach ( $prereqs as $prereq_id ) {
            $prev_assignment = TA_Assignment::get_assignment( $student_id, (int) $prereq_id );
            if ( $prev_assignment && ! empty( $prev_assignment->group_link ) ) {
                $prev_messenger = $prev_assignment->messenger;
                $prev_link      = $prev_assignment->group_link;
                break;
            }
        }

        wp_send_json_success( [ 'messenger' => $prev_messenger, 'group_link' => $prev_link ] );
    }

    /**
     * منطق مشترک دریافت اطلاعات دوره قبلی (برای admin handler)
     */
    private function process_prev_course_info(): void {
        $student_id = absint( $_POST['student_id'] ?? 0 );
        $product_id = absint( $_POST['product_id'] ?? 0 );

        $prereqs        = TA_Product_Meta::get_prerequisites( $product_id );
        $prev_messenger = 'نامشخص';
        $prev_link      = 'نامشخص';

        foreach ( $prereqs as $prereq_id ) {
            $prev_assignment = TA_Assignment::get_assignment( $student_id, (int) $prereq_id );
            if ( $prev_assignment && ! empty( $prev_assignment->group_link ) ) {
                $prev_messenger = $prev_assignment->messenger;
                $prev_link      = $prev_assignment->group_link;
                break;
            }
        }

        wp_send_json_success( [ 'messenger' => $prev_messenger, 'group_link' => $prev_link ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // آپدیت وضعیت گروهی تخصیص‌ها
    // ─────────────────────────────────────────────────────────────────────────

    public function bulk_update_assignment_status(): void {
        $this->verify( 'ta_dashboard_nonce' );

        $ids        = array_map( 'absint', (array) ( $_POST['ids'] ?? [] ) );
        $new_status = sanitize_text_field( $_POST['new_status'] ?? '' );

        if ( empty( $ids ) || ! in_array( $new_status, [ 'active', 'completed' ], true ) ) {
            wp_send_json_error( [ 'message' => 'داده‌های نامعتبر.' ] );
        }

        [, $ta] = $this->require_ta();

        global $wpdb;
        $table        = TA_Database::table( 'assignments' );
        $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table} SET status = %s
                 WHERE id IN ({$placeholders}) AND ta_id = %d",
                array_merge( [ $new_status ], $ids, [ $ta->id ] )
            )
        );

        wp_send_json_success( [
            'message' => $updated . ' تخصیص به‌روز شد.',
            'updated' => $updated,
        ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // [FIX-04] آپدیت گروه تخصیص — nonce اصلاح شد به ta_admin_nonce
    // ─────────────────────────────────────────────────────────────────────────

    public function update_assignment_group(): void {
        // [FIX-04] قبلاً ta_ajax_nonce بود که با taSystem.nonce سازگار نبود
        check_ajax_referer( 'ta_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'دسترسی غیرمجاز.' ] );
        }

        $assignment_id = absint( $_POST['assignment_id'] ?? 0 );
        $messenger     = sanitize_text_field( $_POST['messenger'] ?? '' );
        $group_link    = esc_url_raw( $_POST['group_link'] ?? '' );

        if ( ! $assignment_id ) {
            wp_send_json_error( [ 'message' => 'شناسه نامعتبر.' ] );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'ta_assignments';

        $updated = $wpdb->update(
            $table,
            [ 'messenger' => $messenger, 'group_link' => $group_link ],
            [ 'id'        => $assignment_id ],
            [ '%s', '%s' ],
            [ '%d' ]
        );

        if ( $updated === false ) {
            wp_send_json_error( [ 'message' => 'خطا در به‌روزرسانی.' ] );
        }

        wp_send_json_success( [ 'message' => 'اطلاعات گروه به‌روز شد.' ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // تخصیص نقد اثر
    // ─────────────────────────────────────────────────────────────────────────

    public function assign_critique(): void {
        try {
            $this->verify( 'ta_product_nonce' );

            if ( ! is_user_logged_in() ) {
                wp_send_json_error( [ 'message' => 'لطفاً ابتدا وارد سایت شوید.' ] );
            }

            $product_id = absint( $_POST['product_id'] ?? 0 );
            $student_id = get_current_user_id();

            if ( ! $product_id ) {
                wp_send_json_error( [ 'message' => 'اطلاعات ارسالی نامعتبر است.' ] );
            }

            $settings = TA_Product_Meta::get_settings( $product_id );

            if ( ! $settings ) {
                wp_send_json_error( [ 'message' => 'تنظیمات این دوره یافت نشد.' ] );
            }

            if ( $settings->course_type !== 'critique' ) {
                wp_send_json_error( [ 'message' => 'این دوره برای نقد اثر تنظیم نشده است.' ] );
            }

            $ta_user_id = get_post_meta( $product_id, '_ta_critique_ta_id', true );

            if ( ! $ta_user_id ) {
                wp_send_json_error( [ 'message' => 'استادیار این دوره در تنظیمات محصول مشخص نشده است.' ] );
            }

            global $wpdb;
            $assistant_row = $wpdb->get_row( $wpdb->prepare(
                "SELECT id FROM " . TA_Database::table( 'assistants' ) . " WHERE user_id = %d",
                $ta_user_id
            ) );

            if ( ! $assistant_row ) {
                wp_send_json_error( [ 'message' => 'کاربر انتخاب شده در لیست استادیاران فعال یافت نشد.' ] );
            }

            $real_ta_id     = (int) $assistant_row->id;
            $course_type    = $settings->course_type;
            $messenger      = $settings->messenger ?? 'telegram';
            $student_gender = get_user_meta( $student_id, 'gender', true ) ?: 'unknown';
            $group_link     = $settings->pro_group_link ?? '';

            $assigned = TA_Assignment::assign_with_student_group(
                $student_id, $real_ta_id, $product_id,
                $settings->term_id, $course_type,
                $messenger, $student_gender, $group_link
            );

            if ( is_array( $assigned ) && ( $assigned['success'] ?? false ) ) {
                wp_send_json_success( [
                    'message'  => 'ثبت‌نام شما با موفقیت انجام شد.',
                    'redirect' => $group_link,
                ] );
            } else {
                wp_send_json_error( [ 'message' => $assigned['message'] ?? 'خطا در تخصیص استادیار.' ] );
            }

        } catch ( Throwable $e ) {
            wp_send_json_error( [ 'message' => 'خطای سیستم. لطفاً دوباره تلاش کنید.' ] );
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ویرایش ظرفیت
    // ─────────────────────────────────────────────────────────────────────────

    public function update_capacity(): void {
        $this->verify( 'ta_dashboard_nonce' );
        [, $ta] = $this->require_ta();

        $capacity_id    = absint( $_POST['capacity_id'] ?? 0 );
        $term_id        = absint( $_POST['term_id']     ?? 0 );
        $course_type    = sanitize_text_field( $_POST['course_type']    ?? '' );
        $student_gender = sanitize_text_field( $_POST['student_gender'] ?? 'both' );
        $total_capacity = absint( $_POST['total_capacity'] ?? 0 );
        $messenger      = sanitize_text_field( $_POST['messenger']      ?? 'both' );

        // [FIX-07] اعتبارسنجی course_type
        if ( ! in_array( $course_type, self::VALID_COURSE_TYPES, true ) ) {
            wp_send_json_error( [ 'message' => 'نوع دوره نامعتبر است.' ] );
        }

        if ( ! in_array( $messenger, [ 'telegram', 'bale', 'eitaa', 'both' ], true ) ) {
            $messenger = 'both';
        }

        if ( ! in_array( $student_gender, [ 'male', 'female', 'both' ], true ) ) {
            wp_send_json_error( [ 'message' => 'جنسیت نامعتبر است.' ] );
        }

        $cap_table = TA_Database::table( 'capacities' );
        $cap       = TA_Database::get_row(
            "SELECT * FROM {$cap_table} WHERE id = %d AND ta_id = %d",
            [ $capacity_id, $ta->id ]
        );

        if ( ! $cap ) {
            wp_send_json_error( [ 'message' => 'ظرفیت یافت نشد.' ] );
        }

        if ( $total_capacity < $cap->used_capacity ) {
            wp_send_json_error( [ 'message' => "ظرفیت کل نمی‌تواند کمتر از {$cap->used_capacity} (استفاده‌شده) باشد." ] );
        }

        TA_Database::update( 'ta_capacities', [
            'term_id'        => $term_id,
            'course_type'    => $course_type,
            'student_gender' => $student_gender,
            'total_capacity' => $total_capacity,
            'messenger'      => $messenger,
        ], [ 'id' => $capacity_id ] );

        wp_send_json_success( [ 'message' => 'ظرفیت با موفقیت ویرایش شد.' ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // حذف ظرفیت
    // ─────────────────────────────────────────────────────────────────────────

    public function delete_capacity(): void {
        $this->verify( 'ta_dashboard_nonce' );
        [, $ta] = $this->require_ta();

        $capacity_id = absint( $_POST['capacity_id'] ?? 0 );
        $cap_table   = TA_Database::table( 'capacities' );

        $cap = TA_Database::get_row(
            "SELECT * FROM {$cap_table} WHERE id = %d AND ta_id = %d",
            [ $capacity_id, $ta->id ]
        );

        if ( ! $cap ) {
            wp_send_json_error( [ 'message' => 'ظرفیت یافت نشد.' ] );
        }

        if ( $cap->used_capacity > 0 ) {
            wp_send_json_error( [ 'message' => 'این ظرفیت در حال استفاده است و قابل حذف نیست.' ] );
        }

        TA_Database::delete( 'ta_groups',    [ 'capacity_id' => $capacity_id ] );
        TA_Database::delete( 'ta_capacities', [ 'id'         => $capacity_id ] );

        wp_send_json_success( [ 'message' => 'ظرفیت با موفقیت حذف شد.' ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ویرایش گروه
    // ─────────────────────────────────────────────────────────────────────────

    public function update_group_slot(): void {
        $this->verify( 'ta_dashboard_nonce' );

        $group_id       = absint( $_POST['group_id']       ?? 0 );
        $messenger_type = sanitize_text_field( $_POST['messenger_type'] ?? '' );
        $group_link     = esc_url_raw( $_POST['group_link'] ?? '' );

        $gr_table = TA_Database::table( 'groups' );
        $is_admin = current_user_can( 'manage_options' );

        if ( $is_admin ) {
            $group = TA_Database::get_row( "SELECT * FROM {$gr_table} WHERE id = %d", [ $group_id ] );
        } else {
            [, $ta] = $this->require_ta();
            $group  = TA_Database::get_row(
                "SELECT * FROM {$gr_table} WHERE id = %d AND ta_id = %d",
                [ $group_id, $ta->id ]
            );
        }

        if ( ! $group ) {
            wp_send_json_error( [ 'message' => 'گروه یافت نشد یا دسترسی ندارید.' ] );
        }

        if ( $group->is_used ) {
            wp_send_json_error( [ 'message' => 'این گروه در حال استفاده است و قابل ویرایش نیست.' ] );
        }

        TA_Database::update( 'ta_groups', [
            'messenger_type' => $messenger_type,
            'group_link'     => $group_link,
        ], [ 'id' => $group_id ] );

        wp_send_json_success( [ 'message' => 'گروه با موفقیت ویرایش شد.' ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // حذف گروه
    // ─────────────────────────────────────────────────────────────────────────

    public function delete_group_slot(): void {
        $this->verify( 'ta_dashboard_nonce' );

        $group_id = absint( $_POST['group_id'] ?? 0 );
        $gr_table = TA_Database::table( 'groups' );
        $is_admin = current_user_can( 'manage_options' );

        if ( $is_admin ) {
            $group = TA_Database::get_row( "SELECT * FROM {$gr_table} WHERE id = %d", [ $group_id ] );
        } else {
            [, $ta] = $this->require_ta();
            $group  = TA_Database::get_row(
                "SELECT * FROM {$gr_table} WHERE id = %d AND ta_id = %d",
                [ $group_id, $ta->id ]
            );
        }

        if ( ! $group ) {
            wp_send_json_error( [ 'message' => 'گروه یافت نشد یا دسترسی ندارید.' ] );
        }

        if ( $group->is_used ) {
            wp_send_json_error( [ 'message' => 'این گروه در حال استفاده است و قابل حذف نیست.' ] );
        }

        TA_Database::delete( 'ta_groups', [ 'id' => $group_id ] );

        wp_send_json_success( [ 'message' => 'گروه با موفقیت حذف شد.' ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ابزار مشترک
    // ─────────────────────────────────────────────────────────────────────────

    private function verify( string $nonce_action ): void {
        if ( ! check_ajax_referer( $nonce_action, 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'توکن امنیتی نامعتبر است.' ] );
        }
    }

    private function require_login(): int {
        $uid = get_current_user_id();
        if ( ! $uid ) {
            wp_send_json_error( [ 'message' => 'برای این عملیات باید وارد شوید.' ] );
        }
        return $uid;
    }

    private function require_ta(): array {
        $uid = $this->require_login();
        if ( ! TA_Roles::is_ta( $uid ) ) {
            wp_send_json_error( [ 'message' => 'دسترسی غیرمجاز.' ] );
        }
        $ta_table = TA_Database::table( 'assistants' );
        $ta       = TA_Database::get_row( "SELECT * FROM {$ta_table} WHERE user_id = %d", [ $uid ] );
        if ( ! $ta ) {
            wp_send_json_error( [ 'message' => 'استادیار یافت نشد.' ] );
        }
        return [ $uid, $ta ];
    }

    // ─────────────────────────────────────────────────────────────────────────
    // دریافت استادیارهای موجود
    // ─────────────────────────────────────────────────────────────────────────

    public function get_available_tas(): void {
        $this->verify( 'ta_product_nonce' );
        $uid = $this->require_login();

        $product_id     = absint( $_POST['product_id']     ?? 0 );
        $messenger      = sanitize_text_field( $_POST['messenger']      ?? '' );
        $student_gender = sanitize_text_field( $_POST['student_gender'] ?? '' );

        $settings = TA_Eligibility::get_product_settings( $product_id );
        if ( ! $settings ) {
            wp_send_json_error( [ 'message' => 'تنظیمات محصول یافت نشد.' ] );
        }

        if ( $settings->course_type !== 'creative' ) {
            $prerequisites   = TA_Product_Meta::get_prerequisites( $product_id );
            $found_messenger = '';

            foreach ( $prerequisites as $prereq_id ) {
                $assignment = TA_Assignment::get_assignment( $uid, (int) $prereq_id );
                if ( $assignment && ! empty( $assignment->messenger ) ) {
                    $found_messenger = $assignment->messenger;
                    break;
                }
            }

            if ( empty( $found_messenger ) ) {
                wp_send_json_error( [ 'message' => 'اطلاعات پیام‌رسان از دوره‌های پیش‌نیاز یافت نشد. لطفاً با پشتیبانی تماس بگیرید.' ] );
            }
            $messenger = $found_messenger;
        }

        // بررسی پیامرسان در برابر لیست پیامرسان‌های فعال از تنظیمات
        $supported = (array) TA_Settings_Helper::get( 'supported_messengers', [ 'telegram', 'bale', 'eitaa' ] );
        if ( ! empty( $messenger ) && ! in_array( $messenger, $supported, true ) ) {
            wp_send_json_error( [ 'message' => 'پیامرسان انتخابی در این سیستم پشتیبانی نمی‌شود.' ] );
        }

        $tas  = TA_Assignment::get_available_tas(
            $settings->course_type,
            (int) $settings->term_id,
            $messenger,
            $student_gender,
            $uid
        );

        // اگر show_ta_remaining غیرفعال باشد، ظرفیت باقیمانده را پنهان کن
        $show_remaining = TA_Settings_Helper::is_enabled( 'show_ta_remaining' );

        $list = array_map( fn( $ta ) => [
            'id'        => $ta->id,
            'name'      => $ta->ta_name,
            'remaining' => $show_remaining ? $ta->remaining : null,
        ], $tas );

        wp_send_json_success( [ 'tas' => $list ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // تخصیص استادیار — خلاق
    // ─────────────────────────────────────────────────────────────────────────

    public function assign_creative(): void {
        $this->verify( 'ta_product_nonce' );
        $uid = $this->require_login();

        $product_id        = absint( $_POST['product_id']  ?? 0 );
        $ta_id             = absint( $_POST['ta_id']        ?? 0 );
        $messenger         = sanitize_text_field( $_POST['messenger']         ?? '' );
        $student_gender    = sanitize_text_field( $_POST['student_gender']    ?? '' );
        $custom_group_link = esc_url_raw( wp_unslash( $_POST['custom_group_link'] ?? '' ) );

        if ( ! $product_id || ! $ta_id || ! $messenger || ! $student_gender ) {
            wp_send_json_error( [ 'message' => 'اطلاعات ارسالی ناقص است.' ] );
        }

        // بررسی پیامرسان در برابر لیست فعال
        $supported = (array) TA_Settings_Helper::get( 'supported_messengers', [ 'telegram', 'bale', 'eitaa' ] );
        if ( ! in_array( $messenger, $supported, true ) ) {
            wp_send_json_error( [ 'message' => 'پیامرسان انتخابی در این سیستم پشتیبانی نمی‌شود.' ] );
        }

        if ( in_array( $student_gender, [ 'male', 'female' ], true ) ) {
            update_user_meta( $uid, 'student_gender', $student_gender );
            update_user_meta( $uid, 'gender', $student_gender );
        }

        $settings = TA_Eligibility::get_product_settings( $product_id );
        if ( ! $settings ) {
            wp_send_json_error( [ 'message' => 'تنظیمات محصول یافت نشد.' ] );
        }

        $result = TA_Assignment::assign_creative(
            $uid, $ta_id, $product_id,
            (int) $settings->term_id,
            $messenger, $student_gender,
            $custom_group_link
        );

        if ( $result['success'] ) {
            wp_send_json_success( $result );
        } else {
            wp_send_json_error( $result );
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // تخصیص استادیار — مقدماتی / پیشرفته (گروه از هنرجو)
    // ─────────────────────────────────────────────────────────────────────────

    public function assign_with_group(): void {
        $this->verify( 'ta_product_nonce' );
        $uid = $this->require_login();

        $product_id     = absint( $_POST['product_id'] ?? 0 );
        $ta_id          = absint( $_POST['ta_id']       ?? 0 );
        $student_gender = sanitize_text_field( $_POST['student_gender'] ?? '' );

        $check = TA_Eligibility::check( $uid, $product_id );
        if ( ! $check['eligible'] || $check['path'] !== 'normal' ) {
            wp_send_json_error( [ 'message' => $check['message'] ?: 'مجوز انتخاب استادیار ندارید.' ] );
        }

        if ( in_array( $student_gender, [ 'male', 'female' ], true ) ) {
            update_user_meta( $uid, 'student_gender', $student_gender );
            update_user_meta( $uid, 'gender', $student_gender );
        }

        $settings      = TA_Eligibility::get_product_settings( $product_id );
        if ( ! $settings ) {
            wp_send_json_error( [ 'message' => 'تنظیمات محصول یافت نشد.' ] );
        }

        $prerequisites = TA_Product_Meta::get_prerequisites( $product_id );
        $messenger     = '';
        $group_link    = '';

        foreach ( $prerequisites as $prereq_id ) {
            $assignment = TA_Assignment::get_assignment( $uid, (int) $prereq_id );
            if ( ! $assignment ) continue;

            if ( isset( $settings->course_type ) && $settings->course_type === 'advanced'
                 && isset( $assignment->course_type ) && $assignment->course_type === 'critique' ) {
                continue;
            }

            if ( ! empty( $assignment->messenger ) && empty( $messenger ) ) {
                $messenger = $assignment->messenger;
            }
            if ( ! empty( $assignment->group_link ) && empty( $group_link ) ) {
                $group_link = $assignment->group_link;
            }

            if ( ! empty( $messenger ) && ! empty( $group_link ) ) break;
        }

        if ( empty( $group_link ) ) {
            wp_send_json_error( [ 'message' => 'لینک گروه از دوره پیش‌نیاز یافت نشد. لطفاً با پشتیبانی تماس بگیرید.' ] );
        }
        if ( empty( $messenger ) ) {
            wp_send_json_error( [ 'message' => 'اطلاعات پیام‌رسان از دوره پیش‌نیاز یافت نشد.' ] );
        }

        $result = TA_Assignment::assign_with_student_group(
            $uid, $ta_id, $product_id,
            (int) $settings->term_id, $settings->course_type,
            $messenger, $student_gender, $group_link
        );

        if ( $result['success'] ) {
            $result['redirect'] = $group_link;
            wp_send_json_success( $result );
        } else {
            wp_send_json_error( $result );
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // [FIX-06] ثبت نمره — بررسی status=active اضافه شد
    // ─────────────────────────────────────────────────────────────────────────

    public function grade_student(): void {
        $this->verify( 'ta_dashboard_nonce' );
        [, $ta] = $this->require_ta();

        // ── بررسی تنظیم ta_grading_enabled ───────────────────────────────────
        if ( ! TA_Settings_Helper::is_enabled( 'ta_grading_enabled' ) ) {
            wp_send_json_error( [ 'message' => 'نمره‌دهی توسط استادیار در حال حاضر غیرفعال است.' ] );
        }
        // ─────────────────────────────────────────────────────────────────────

        $student_id = absint( $_POST['student_id'] ?? 0 );
        $product_id = absint( $_POST['product_id'] ?? 0 );
        $grade      = sanitize_text_field( $_POST['grade'] ?? '' );
        $notes      = sanitize_textarea_field( $_POST['notes'] ?? '' );

        $valid_grades = [ 'pass', 'repeat', 'critique', 'pending' ];
        if ( ! in_array( $grade, $valid_grades, true ) ) {
            wp_send_json_error( [ 'message' => 'نمره نامعتبر.' ] );
        }

        $assign_table = TA_Database::table( 'assignments' );
        $assignment   = TA_Database::get_row(
            "SELECT * FROM {$assign_table} WHERE student_id = %d AND product_id = %d AND ta_id = %d",
            [ $student_id, $product_id, $ta->id ]
        );

        if ( ! $assignment ) {
            wp_send_json_error( [ 'message' => 'این هنرجو متعلق به شما نیست.' ] );
        }

        // [FIX-06] نمره روی تخصیص لغوشده یا تکمیل‌شده مجاز نیست
        if ( ! in_array( $assignment->status, [ 'active', 'pending' ], true ) ) {
            wp_send_json_error( [ 'message' => 'این تخصیص فعال نیست و امکان ثبت نمره وجود ندارد.' ] );
        }

        // ── بررسی تنظیم allow_grade_edit ─────────────────────────────────────
        $grade_table   = TA_Database::table( 'grades' );
        $existing_grade = TA_Database::get_row(
            "SELECT * FROM {$grade_table} WHERE student_id = %d AND product_id = %d",
            [ $student_id, $product_id ]
        );

        if ( $existing_grade ) {
            // نمره قبلاً ثبت شده — بررسی مجوز ویرایش
            if ( ! TA_Settings_Helper::is_enabled( 'allow_grade_edit' ) ) {
                wp_send_json_error( [ 'message' => 'ویرایش نمره غیرفعال است. نمره قبلاً ثبت شده و قابل تغییر نیست.' ] );
            }

            // بررسی مهلت ویرایش
            $limit_days = (int) TA_Settings_Helper::get( 'grade_edit_limit_days', 0 );
            if ( $limit_days > 0 && ! empty( $existing_grade->created_at ) ) {
                $created_ts  = strtotime( $existing_grade->created_at );
                $elapsed_days = ( time() - $created_ts ) / DAY_IN_SECONDS;
                if ( $elapsed_days > $limit_days ) {
                    wp_send_json_error( [ 'message' => sprintf(
                        'مهلت ویرایش نمره (%d روز) به پایان رسیده است.',
                        $limit_days
                    ) ] );
                }
            }
        }
        // ─────────────────────────────────────────────────────────────────────

        $settings = TA_Eligibility::get_product_settings( $product_id );

        if ( $grade === 'critique' && $settings && $settings->course_type !== 'intro' ) {
            wp_send_json_error( [ 'message' => 'نمره «نقد اثر» فقط برای مقدماتی قابل ثبت است.' ] );
        }

        $ok = TA_Grade::set_grade(
            $student_id, $product_id,
            (int) $settings->term_id, $settings->course_type,
            $grade, $ta->id, $notes
        );

        if ( $ok ) {
            // ارسال اعلان ایمیل به هنرجو پس از ثبت نمره
            TA_Settings_Helper::send_notification( 'student_graded', [
                'student_email' => get_userdata( $student_id )->user_email ?? '',
                'product_name'  => get_the_title( $product_id ),
                'grade_label'   => TA_Grade::grade_label( $grade ),
                'notes'         => $notes,
            ] );

            if ( ! empty( $_POST['mark_complete'] ) && (int) $_POST['mark_complete'] === 1 ) {
                $assignment_id = absint( $_POST['assignment_id'] ?? 0 );
                if ( $assignment_id ) {
                    global $wpdb;
                    $wpdb->update(
                        TA_Database::table( 'assignments' ),
                        [ 'status' => 'completed' ],
                        [ 'id'     => $assignment_id ],
                        [ '%s' ], [ '%d' ]
                    );
                }
            }
            wp_send_json_success( [ 'message' => 'نمره با موفقیت ثبت شد.' ] );
        } else {
            wp_send_json_error( [ 'message' => 'خطا در ثبت نمره.' ] );
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // [FIX-07] ذخیره ظرفیت — whitelist برای course_type اضافه شد
    // ─────────────────────────────────────────────────────────────────────────

    public function save_capacity(): void {
        $this->verify( 'ta_dashboard_nonce' );
        [, $ta] = $this->require_ta();

        $course_type    = sanitize_text_field( $_POST['course_type']    ?? '' );
        $term_id        = absint( $_POST['term_id']        ?? 0 );
        $student_gender = sanitize_text_field( $_POST['student_gender'] ?? 'both' );
        $total_capacity = absint( $_POST['total_capacity'] ?? 0 );
        $messenger      = sanitize_text_field( $_POST['messenger']      ?? 'both' );

        // [FIX-07] اعتبارسنجی course_type
        if ( ! in_array( $course_type, self::VALID_COURSE_TYPES, true ) ) {
            wp_send_json_error( [ 'message' => 'نوع دوره نامعتبر است.' ] );
        }

        if ( ! in_array( $messenger, [ 'telegram', 'bale', 'eitaa', 'both' ], true ) ) {
            $messenger = 'both';
        }

        if ( ! in_array( $student_gender, [ 'male', 'female', 'both' ], true ) ) {
            $student_gender = 'both';
        }

        $cap_table = TA_Database::table( 'capacities' );
        // بررسی existing با تمام فیلدهای UNIQUE KEY (شامل messenger)
        $existing  = TA_Database::get_row(
            "SELECT id FROM {$cap_table}
             WHERE ta_id = %d AND course_type = %s AND term_id = %d
               AND student_gender = %s AND messenger = %s",
            [ $ta->id, $course_type, $term_id, $student_gender, $messenger ]
        );

        if ( $existing ) {
            TA_Database::update( 'ta_capacities',
                [ 'total_capacity' => $total_capacity ],
                [ 'id' => $existing->id ]
            );
        } else {
            TA_Database::insert( 'ta_capacities', [
                'ta_id'          => $ta->id,
                'course_type'    => $course_type,
                'term_id'        => $term_id,
                'student_gender' => $student_gender,
                'total_capacity' => $total_capacity,
                'used_capacity'  => 0,
                'messenger'      => $messenger,
                'created_at'     => current_time( 'mysql' ),
            ] );
        }

        wp_send_json_success( [ 'message' => 'ظرفیت ذخیره شد.' ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // افزودن گروه برای ظرفیت خلاق
    // ─────────────────────────────────────────────────────────────────────────

    public function add_group_slot(): void {
        $this->verify( 'ta_dashboard_nonce' );

        $capacity_id    = absint( $_POST['capacity_id']    ?? 0 );
        $messenger_type = sanitize_text_field( $_POST['messenger_type'] ?? '' );
        $group_link     = esc_url_raw( $_POST['group_link'] ?? '' );

        $cap_table = TA_Database::table( 'capacities' );
        $is_admin  = current_user_can( 'manage_options' );

        if ( $is_admin ) {
            $cap   = TA_Database::get_row(
                "SELECT * FROM {$cap_table} WHERE id = %d AND course_type = %s",
                [ $capacity_id, 'creative' ]
            );
            $ta_id = $cap ? $cap->ta_id : 0;
        } else {
            [, $ta] = $this->require_ta();
            $ta_id  = $ta->id;
            $cap    = TA_Database::get_row(
                "SELECT * FROM {$cap_table} WHERE id = %d AND ta_id = %d AND course_type = %s",
                [ $capacity_id, $ta_id, 'creative' ]
            );
        }

        if ( ! $cap ) {
            wp_send_json_error( [ 'message' => 'ظرفیت یافت نشد یا دسترسی ندارید.' ] );
        }

        TA_Database::insert( 'ta_groups', [
            'capacity_id'    => $capacity_id,
            'ta_id'          => $ta_id,
            'messenger_type' => $messenger_type,
            'group_link'     => $group_link,
            'is_used'        => 0,
        ] );

        wp_send_json_success( [ 'message' => 'گروه با موفقیت ثبت شد.' ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // لیست سیاه
    // ─────────────────────────────────────────────────────────────────────────

    public function blacklist_student(): void {
        $this->verify( 'ta_dashboard_nonce' );
        [, $ta] = $this->require_ta();

        $student_id = absint( $_POST['student_id'] ?? 0 );
        $reason     = sanitize_textarea_field( $_POST['reason'] ?? '' );

        $bl_table   = TA_Database::table( 'blacklist' );
        $assign_tbl = TA_Database::table( 'assignments' );
        global $wpdb;

        $exists = TA_Database::get_row(
            "SELECT id FROM {$bl_table} WHERE ta_id = %d AND student_id = %d",
            [ $ta->id, $student_id ]
        );
        if ( $exists ) {
            wp_send_json_error( [ 'message' => 'این هنرجو قبلاً در لیست سیاه است.' ] );
        }

        $term_id = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT term_id FROM {$assign_tbl} WHERE ta_id = %d AND student_id = %d ORDER BY id DESC LIMIT 1",
            $ta->id, $student_id
        ) );

        if ( $term_id ) {
            $total_students    = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(DISTINCT student_id) FROM {$assign_tbl} WHERE ta_id = %d AND term_id = %d",
                $ta->id, $term_id
            ) );
            $blacklisted_count = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(DISTINCT a.student_id)
                 FROM {$assign_tbl} a
                 INNER JOIN {$bl_table} b ON a.ta_id = b.ta_id AND a.student_id = b.student_id
                 WHERE a.ta_id = %d AND a.term_id = %d",
                $ta->id, $term_id
            ) );
            $max_pct     = TA_Settings_Helper::blacklist_max_pct(); // از تنظیمات می‌خواند
            $max_allowed = (int) ceil( $total_students * $max_pct / 100 );

            if ( $blacklisted_count >= $max_allowed ) {
                wp_send_json_error( [ 'message' => sprintf(
                    'شما به سقف مجاز لیست سیاه در این ترم (%d نفر از کل %d هنرجو) رسیده‌اید.',
                    $max_allowed, $total_students
                ) ] );
            }
        }

        TA_Database::insert( 'ta_blacklist', [
            'ta_id'      => $ta->id,
            'student_id' => $student_id,
            'reason'     => $reason,
            'created_at' => current_time( 'mysql' ),
        ] );

        wp_send_json_success( [ 'message' => 'هنرجو با موفقیت به لیست سیاه اضافه شد.' ] );
    }

    public function remove_from_blacklist(): void {
        $this->verify( 'ta_dashboard_nonce' );
        [, $ta] = $this->require_ta();

        $student_id = absint( $_POST['student_id'] ?? 0 );
        TA_Database::delete( 'ta_blacklist', [ 'ta_id' => $ta->id, 'student_id' => $student_id ] );
        wp_send_json_success( [ 'message' => 'حذف شد.' ] );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // تخصیص حرفه‌ای
    // ─────────────────────────────────────────────────────────────────────────

    public function assign_professional(): void {
        try {
            $this->verify( 'ta_product_nonce' );

            if ( ! is_user_logged_in() ) {
                wp_send_json_error( [ 'message' => 'لطفاً ابتدا وارد سایت شوید.' ] );
            }

            $product_id = absint( $_POST['product_id'] ?? 0 );
            $student_id = get_current_user_id();
            $messenger  = sanitize_text_field( $_POST['messenger']    ?? 'telegram' );

            if ( ! $product_id ) {
                wp_send_json_error( [ 'message' => 'اطلاعات ارسالی نامعتبر است.' ] );
            }

            $settings = TA_Product_Meta::get_settings( $product_id );

            if ( ! $settings ) {
                wp_send_json_error( [ 'message' => 'تنظیمات این دوره یافت نشد.' ] );
            }

            if ( $settings->course_type !== 'professional' ) {
                wp_send_json_error( [ 'message' => 'این دوره برای تخصیص حرفه‌ای تنظیم نشده است.' ] );
            }

            $eligibility = TA_Eligibility::check( $student_id, $product_id );
            if ( $eligibility['path'] !== 'assign_professional' ) {
                wp_send_json_error( [ 'message' => 'شما مجوز ثبت‌نام در این دوره را ندارید.' ] );
            }

            $ta_user_id = get_post_meta( $product_id, '_ta_professional_ta_id', true );

            if ( ! $ta_user_id ) {
                wp_send_json_error( [ 'message' => 'استادیار این دوره در تنظیمات محصول مشخص نشده است.' ] );
            }

            global $wpdb;
            $assistant_row = $wpdb->get_row( $wpdb->prepare(
                "SELECT id FROM " . TA_Database::table( 'assistants' ) . " WHERE user_id = %d",
                $ta_user_id
            ) );

            if ( ! $assistant_row ) {
                wp_send_json_error( [ 'message' => 'استادیار این دوره در لیست فعال یافت نشد.' ] );
            }

            $real_ta_id     = (int) $assistant_row->id;
            $student_gender = get_user_meta( $student_id, 'gender', true ) ?: 'unknown';
            $group_link     = $settings->pro_group_link ?? '';

            $assigned = TA_Assignment::assign_with_student_group(
                $student_id, $real_ta_id, $product_id,
                $settings->term_id, 'professional',
                $messenger, $student_gender, $group_link
            );

            if ( is_array( $assigned ) && ( $assigned['success'] ?? false ) ) {
                wp_send_json_success( [
                    'message'  => 'ثبت‌نام شما با موفقیت انجام شد.',
                    'redirect' => $group_link,
                ] );
            } else {
                wp_send_json_error( [ 'message' => $assigned['message'] ?? 'خطا در تخصیص استادیار.' ] );
            }

        } catch ( Throwable $e ) {
            wp_send_json_error( [ 'message' => 'خطای سیستم. لطفاً دوباره تلاش کنید.' ] );
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // [FIX-05] دریافت استادیارهای موجود (ادمین) — پیام‌های DEBUG حذف شدند
    // ─────────────────────────────────────────────────────────────────────────

    public function admin_get_available_tas(): void {
        check_ajax_referer( 'ta_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'دسترسی غیرمجاز.' ] );
        }

        global $wpdb;

        $product_id     = absint( $_POST['product_id']     ?? 0 );
        $messenger      = sanitize_text_field( $_POST['messenger']      ?? '' );
        $student_gender = sanitize_text_field( $_POST['student_gender'] ?? '' );

        if ( ! $product_id ) {
            // [FIX-05] پیام ساده بدون اطلاعات داخلی
            wp_send_json_error( [ 'message' => 'شناسه محصول ارسال نشده است.' ] );
        }

        $settings = $wpdb->get_row( $wpdb->prepare(
            "SELECT term_id, course_type FROM {$wpdb->prefix}ta_product_settings WHERE product_id = %d",
            $product_id
        ) );

        if ( ! $settings ) {
            wp_send_json_error( [ 'message' => 'تنظیمات این محصول یافت نشد. لطفاً از بخش تنظیمات محصول، ترم و نوع دوره را تنظیم کنید.' ] );
        }

        $term_id     = (int) $settings->term_id;
        $course_type = $settings->course_type ?? '';

        if ( ! $term_id ) {
            wp_send_json_error( [ 'message' => 'ترم این محصول تنظیم نشده است.' ] );
        }

        $ta_table  = TA_Database::table( 'assistants' );
        $cap_table = TA_Database::table( 'capacities' );

        $results = $wpdb->get_results( $wpdb->prepare(
            "SELECT
                ta.id              AS ta_id,
                cap.id             AS capacity_id,
                cap.total_capacity,
                cap.used_capacity,
                (cap.total_capacity - cap.used_capacity) AS remaining,
                u.display_name     AS ta_name
             FROM {$ta_table} ta
             JOIN {$cap_table} cap
                  ON  cap.ta_id        = ta.id
                  AND cap.term_id      = %d
                  AND cap.course_type  = %s
                  AND cap.student_gender IN (%s, 'both')
                  AND cap.messenger    IN (%s, 'both')
             JOIN {$wpdb->users} u ON u.ID = ta.user_id
             WHERE ta.is_active    = 1
               AND cap.used_capacity < cap.total_capacity",
            $term_id, $course_type, $student_gender, $messenger
        ) );

        if ( empty( $results ) ) {
            // [FIX-05] پیام عمومی بدون hardcode کردن مقادیر (ایتا - آقا)
            wp_send_json_error( [ 'message' => 'در حال حاضر استادیاری با ظرفیت خالی برای شرایط انتخابی یافت نشد.' ] );
        }

        $data = array_map( function ( $row ) {
            return [
                'capacity_id' => (int) $row->capacity_id,
                'ta_id'       => (int) $row->ta_id,
                'name'        => $row->ta_name,
                'remaining'   => (int) $row->remaining,
                'group_link'  => '',
            ];
        }, $results );

        wp_send_json_success( $data );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // [FIX-01] تخصیص با لینک سفارشی (ادمین) — امضای تابع کامل شد
    // ─────────────────────────────────────────────────────────────────────────

    public function admin_assign_with_custom_link(): void {
        check_ajax_referer( 'ta_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'دسترسی غیرمجاز.' ] );
        }

        $order_id       = absint( $_POST['order_id']         ?? 0 );
        $ta_user_id     = absint( $_POST['ta_user_id']       ?? 0 );
        $capacity_id    = absint( $_POST['capacity_id']      ?? 0 );
        // [FIX-01] این دو پارامتر قبلاً پاس نمی‌شدند
        $product_id     = absint( $_POST['product_id']       ?? 0 );
        $student_gender = sanitize_text_field( $_POST['student_gender']  ?? '' );
        $messenger_type = sanitize_text_field( $_POST['messenger_type']  ?? '' );
        $custom_link    = esc_url_raw( $_POST['custom_group_link'] ?? '' );

        if ( ! $order_id || ! $ta_user_id || ! $capacity_id || ! $product_id || ! $messenger_type || empty( $custom_link ) ) {
            wp_send_json_error( [ 'message' => 'پارامترهای ناقص است.' ] );
        }

        // [FIX-01] هفت آرگومان صحیح به تابع پاس می‌شوند
        $result = TA_Assignment::assign_standard_with_capacity(
            $order_id,       // student_id
            $ta_user_id,     // ta_id
            $product_id,     // product_id ← اضافه شد
            $capacity_id,    // capacity_id
            $messenger_type, // messenger
            $student_gender, // student_gender ← اضافه شد
            $custom_link     // custom_group_link
        );

        if ( ! empty( $result['success'] ) ) {
            wp_send_json_success( $result );
        } else {
            wp_send_json_error( $result );
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // تخصیص بر اساس ظرفیت (ادمین)
    // ─────────────────────────────────────────────────────────────────────────

    public function admin_assign_by_capacity(): void {
        $this->verify( 'ta_admin_nonce' );

        $student_id     = absint( $_POST['student_id']     ?? 0 );
        $ta_id          = absint( $_POST['ta_id']           ?? 0 );
        $product_id     = absint( $_POST['product_id']      ?? 0 );
        $capacity_id    = absint( $_POST['capacity_id']     ?? 0 );
        $messenger      = sanitize_text_field( $_POST['messenger']      ?? '' );
        $student_gender = sanitize_text_field( $_POST['student_gender'] ?? '' );
        $custom_link    = esc_url_raw( $_POST['custom_group_link'] ?? '' );

        if ( ! $student_id || ! $ta_id || ! $product_id || ! $capacity_id ) {
            wp_send_json_error( [ 'message' => 'پارامترهای ورودی ناقص است.' ] );
        }

        if ( empty( $custom_link ) ) {
            $cap_table    = TA_Database::table( 'capacities' );
            global $wpdb;
            $capacity_row = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM {$cap_table} WHERE id = %d", $capacity_id
            ) );

            if ( ! $capacity_row ) {
                wp_send_json_error( [ 'message' => 'ظرفیت یافت نشد.' ] );
            }

            $course_type = $capacity_row->course_type;

            if ( in_array( $course_type, [ 'intro', 'advanced' ], true ) ) {
                $prerequisites = TA_Product_Meta::get_prerequisites( $product_id );
                $settings      = TA_Eligibility::get_product_settings( $product_id );

                foreach ( $prerequisites as $prereq_id ) {
                    $assignment = TA_Assignment::get_assignment( $student_id, (int) $prereq_id );
                    if ( ! $assignment ) continue;

                    if ( $course_type === 'advanced'
                         && isset( $assignment->course_type )
                         && $assignment->course_type === 'critique' ) {
                        continue;
                    }

                    if ( ! empty( $assignment->group_link ) ) {
                        $custom_link = $assignment->group_link;
                        if ( empty( $messenger ) && ! empty( $assignment->messenger ) ) {
                            $messenger = $assignment->messenger;
                        }
                        break;
                    }
                }

                if ( empty( $custom_link ) ) {
                    wp_send_json_error( [ 'message' => 'لینک گروه از دوره پیش‌نیاز هنرجو یافت نشد.' ] );
                }

            } elseif ( in_array( $course_type, [ 'critique', 'professional' ], true ) ) {
                $messenger = $capacity_row->messenger;
                $settings  = TA_Eligibility::get_product_settings( $product_id );
                if ( $settings && ! empty( $settings->pro_group_link ) ) {
                    $custom_link = $settings->pro_group_link;
                } else {
                    wp_send_json_error( [ 'message' => 'لینک گروه در تنظیمات محصول تعریف نشده است.' ] );
                }
            }
        }

        $result = TA_Assignment::assign_standard_with_capacity(
            $student_id, $ta_id, $product_id, $capacity_id,
            $messenger, $student_gender, $custom_link
        );

        if ( ! empty( $result['success'] ) ) {
            wp_send_json_success( $result );
        } else {
            wp_send_json_error( $result );
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // دریافت گروه‌های یک ظرفیت خلاق (برای Modal مدیریت ظرفیت)
    // ─────────────────────────────────────────────────────────────────────────

    public function get_capacity_groups(): void {
        $this->verify( 'ta_dashboard_nonce' );

        $capacity_id = absint( $_POST['capacity_id'] ?? 0 );
        if ( ! $capacity_id ) {
            wp_send_json_error( [ 'message' => 'شناسه نامعتبر.' ] );
        }

        $gr_table = TA_Database::table( 'groups' );
        $rows     = TA_Database::get_results(
            "SELECT id, messenger_type, group_link, is_used, assigned_to_user_id
             FROM {$gr_table} WHERE capacity_id = %d ORDER BY id ASC",
            [ $capacity_id ]
        );

        wp_send_json_success( $rows );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // دریافت هنرجویان یک ظرفیت (برای Modal مدیریت ظرفیت)
    // ─────────────────────────────────────────────────────────────────────────

    public function get_capacity_assignments(): void {
        check_ajax_referer( 'ta_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'دسترسی غیرمجاز.' ] );
        }

        $capacity_id = absint( $_POST['capacity_id'] ?? 0 );
        if ( ! $capacity_id ) {
            wp_send_json_error( [ 'message' => 'شناسه نامعتبر.' ] );
        }

        global $wpdb;
        $assign_tbl = TA_Database::table( 'assignments' );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT a.id, u.display_name AS student_name, a.messenger, a.group_link, a.status
             FROM {$assign_tbl} a
             JOIN {$wpdb->users} u ON u.ID = a.student_id
             WHERE a.capacity_id = %d AND a.status = 'active'
             ORDER BY a.id ASC",
            $capacity_id
        ) );

        wp_send_json_success( $rows );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // آمار تفصیلی بر اساس ترم — برای تب خلاصه استادیار
    // ─────────────────────────────────────────────────────────────────────────
    public function get_term_stats(): void {
        $this->verify( 'ta_dashboard_nonce' );
        [ , $ta ] = $this->require_ta();

        global $wpdb;
        $cap_table    = TA_Database::table( 'capacities' );
        $assign_table = TA_Database::table( 'assignments' );
        $grade_table  = TA_Database::table( 'grades' );
        $term_table   = TA_Database::table( 'terms' );

        // ─── آمار کلی همه ترم‌ها ───
        // باگ قبلی: JOIN مستقیم capacities با assignments روی ta_id=ta_id
        // باعث ضرب‌شدن رکوردها می‌شد (هر assignment × تعداد capacity رکوردها).
        // راه‌حل: دو کوئری مجزا و ترکیب در PHP.
        $global_cap = $wpdb->get_row( $wpdb->prepare(
            "SELECT
                SUM(total_capacity) AS total_cap,
                SUM(used_capacity)  AS used_cap
             FROM {$cap_table}
             WHERE ta_id = %d",
            $ta->id
        ) );
        $global_asgn = $wpdb->get_row( $wpdb->prepare(
            "SELECT
                COUNT(*)                                              AS total_students,
                SUM(CASE WHEN status='active'    THEN 1 ELSE 0 END)  AS active_count,
                SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END)  AS completed_count,
                SUM(CASE WHEN status='canceled'  THEN 1 ELSE 0 END)  AS canceled_count
             FROM {$assign_table}
             WHERE ta_id = %d",
            $ta->id
        ) );
        $global = (object) [
            'total_cap'       => $global_cap->total_cap        ?? 0,
            'used_cap'        => $global_cap->used_cap         ?? 0,
            'total_students'  => $global_asgn->total_students  ?? 0,
            'active_count'    => $global_asgn->active_count    ?? 0,
            'completed_count' => $global_asgn->completed_count ?? 0,
            'canceled_count'  => $global_asgn->canceled_count  ?? 0,
        ];

        // ─── آمار نمرات کلی ───
        $grades_global = $wpdb->get_results( $wpdb->prepare(
            "SELECT g.grade, COUNT(*) AS cnt
             FROM {$assign_table} a
             JOIN {$grade_table} g ON g.student_id = a.student_id AND g.product_id = a.product_id
             WHERE a.ta_id = %d
             GROUP BY g.grade",
            $ta->id
        ) );

        // ─── آمار بر اساس ترم ───
        // مرجع ترم‌ها = UNION ترم‌هایی که TA در آن‌ها assignment یا capacity دارد.
        // سپس هر بخش (capacity / assignment) جداگانه GROUP BY می‌شود و در PHP ترکیب می‌شود
        // تا از ضرب‌شدن رکوردها جلوگیری شود.

        // الف) لیست همه ترم‌هایی که این TA در آن‌ها حضور دارد
        $active_term_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT DISTINCT term_id FROM {$assign_table} WHERE ta_id = %d
             UNION
             SELECT DISTINCT term_id FROM {$cap_table}   WHERE ta_id = %d",
            $ta->id, $ta->id
        ) );

        $terms_raw = [];
        if ( ! empty( $active_term_ids ) ) {
            $placeholders = implode( ',', array_fill( 0, count( $active_term_ids ), '%d' ) );

            // ب) اطلاعات پایه ترم‌ها
            $terms_info = $wpdb->get_results( $wpdb->prepare(
                "SELECT id, name, order_index
                 FROM {$term_table}
                 WHERE id IN ($placeholders)
                 ORDER BY order_index DESC",
                ...$active_term_ids
            ) );

            // ج) ظرفیت هر ترم
            $cap_rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT term_id,
                        SUM(total_capacity) AS total_cap,
                        SUM(used_capacity)  AS used_cap
                 FROM {$cap_table}
                 WHERE ta_id = %d AND term_id IN ($placeholders)
                 GROUP BY term_id",
                $ta->id, ...$active_term_ids
            ) );
            $cap_by_term = [];
            foreach ( $cap_rows as $r ) {
                $cap_by_term[ (int) $r->term_id ] = $r;
            }

            // د) آمار هنرجویان هر ترم
            $asgn_rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT term_id,
                        COUNT(*)                                              AS total_students,
                        SUM(CASE WHEN status='active'    THEN 1 ELSE 0 END)  AS active_count,
                        SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END)  AS completed_count,
                        SUM(CASE WHEN status='canceled'  THEN 1 ELSE 0 END)  AS canceled_count
                 FROM {$assign_table}
                 WHERE ta_id = %d AND term_id IN ($placeholders)
                 GROUP BY term_id",
                $ta->id, ...$active_term_ids
            ) );
            $asgn_by_term = [];
            foreach ( $asgn_rows as $r ) {
                $asgn_by_term[ (int) $r->term_id ] = $r;
            }

            // ه) ترکیب
            foreach ( $terms_info as $t ) {
                $tid = (int) $t->id;
                $cr  = $cap_by_term[ $tid ]  ?? null;
                $ar  = $asgn_by_term[ $tid ] ?? null;
                $t->total_cap       = $cr ? (int) $cr->total_cap      : 0;
                $t->used_cap        = $cr ? (int) $cr->used_cap       : 0;
                $t->total_students  = $ar ? (int) $ar->total_students  : 0;
                $t->active_count    = $ar ? (int) $ar->active_count    : 0;
                $t->completed_count = $ar ? (int) $ar->completed_count : 0;
                $t->canceled_count  = $ar ? (int) $ar->canceled_count  : 0;
                $terms_raw[] = $t;
            }
        }

        // ─── آمار نوع دوره هر ترم ───
        $course_stats = $wpdb->get_results( $wpdb->prepare(
            "SELECT
                a.term_id,
                a.course_type,
                COUNT(*) AS cnt,
                SUM(CASE WHEN a.status='completed' THEN 1 ELSE 0 END) AS completed,
                SUM(CASE WHEN a.status='canceled'  THEN 1 ELSE 0 END) AS canceled
             FROM {$assign_table} a
             WHERE a.ta_id = %d
             GROUP BY a.term_id, a.course_type",
            $ta->id
        ) );

        // ─── آمار نمرات هر ترم ───
        $grade_stats = $wpdb->get_results( $wpdb->prepare(
            "SELECT a.term_id, g.grade, COUNT(*) AS cnt
             FROM {$assign_table} a
             JOIN {$grade_table} g ON g.student_id = a.student_id AND g.product_id = a.product_id
             WHERE a.ta_id = %d
             GROUP BY a.term_id, g.grade",
            $ta->id
        ) );

        // ─── ساختاردهی ───
        $course_map = [];
        foreach ( $course_stats as $row ) {
            $course_map[ $row->term_id ][ $row->course_type ] = $row;
        }
        $grade_map = [];
        foreach ( $grade_stats as $row ) {
            $grade_map[ $row->term_id ][ $row->grade ] = (int) $row->cnt;
        }
        $grades_global_map = [];
        foreach ( $grades_global as $row ) {
            $grades_global_map[ $row->grade ] = (int) $row->cnt;
        }

        $terms = [];
        foreach ( $terms_raw as $t ) {
            $terms[] = [
                'id'              => (int) $t->id,
                'name'            => $t->name,
                'total_cap'       => (int) $t->total_cap,
                'used_cap'        => (int) $t->used_cap,
                'remaining_cap'   => max( 0, (int)$t->total_cap - (int)$t->used_cap ),
                'total_students'  => (int) $t->total_students,
                'active_count'    => (int) $t->active_count,
                'completed_count' => (int) $t->completed_count,
                'canceled_count'  => (int) $t->canceled_count,
                'fill_pct'        => $t->total_cap > 0 ? round( ($t->used_cap / $t->total_cap) * 100 ) : 0,
                'courses'         => $course_map[ $t->id ] ?? [],
                'grades'          => $grade_map[ $t->id ] ?? [],
            ];
        }

        wp_send_json_success( [
            'global' => [
                'total_cap'       => (int)( $global->total_cap ?? 0 ),
                'used_cap'        => (int)( $global->used_cap ?? 0 ),
                'remaining_cap'   => max( 0, (int)($global->total_cap ?? 0) - (int)($global->used_cap ?? 0) ),
                'total_students'  => (int)( $global->total_students ?? 0 ),
                'active_count'    => (int)( $global->active_count ?? 0 ),
                'completed_count' => (int)( $global->completed_count ?? 0 ),
                'canceled_count'  => (int)( $global->canceled_count ?? 0 ),
                'fill_pct'        => ($global->total_cap ?? 0) > 0
                                     ? round( ($global->used_cap / $global->total_cap) * 100 ) : 0,
                'grades'          => $grades_global_map,
            ],
            'terms' => $terms,
        ] );
    }

    // ─── نقد داستان ──────────────────────────────────────────────────────────

    public function story_critique_submit(): void {
        $this->verify( 'ta_dashboard_nonce' );
        $uid = get_current_user_id();
        if ( ! TA_Roles::is_ta( $uid ) ) {
            wp_send_json_error( 'دسترسی غیرمجاز' );
        }

        $ta_table = TA_Database::table( 'assistants' );
        $ta       = TA_Database::get_row( "SELECT id FROM {$ta_table} WHERE user_id = %d", [ $uid ] );
        if ( ! $ta ) {
            wp_send_json_error( 'استادیار یافت نشد' );
        }

        $full_name       = sanitize_text_field( $_POST['full_name']       ?? '' );
        $phone           = sanitize_text_field( $_POST['phone']           ?? '' );
        $bale_id         = sanitize_text_field( $_POST['bale_id']         ?? '' );
        $specialties_raw = $_POST['specialties'] ?? [];
        $other           = sanitize_textarea_field( $_POST['other_specialty'] ?? '' );
        $hours           = sanitize_text_field( $_POST['hours_per_day']   ?? '' );

        if ( ! $full_name || ! $phone || ! $bale_id || ! $hours ) {
            wp_send_json_error( 'لطفاً تمام فیلدهای ضروری را پر کنید.' );
        }

        $specialties = is_array( $specialties_raw )
            ? array_map( 'sanitize_text_field', $specialties_raw )
            : [];

        $sc_table = TA_Database::table( 'story_critique_forms' );
        global $wpdb;

        // بررسی ثبت قبلی
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$sc_table} WHERE ta_id = %d", $ta->id
        ) );

        $data = [
            'full_name'       => $full_name,
            'phone'           => $phone,
            'bale_id'         => $bale_id,
            'specialties'     => wp_json_encode( $specialties, JSON_UNESCAPED_UNICODE ),
            'other_specialty' => $other,
            'hours_per_day'   => $hours,
        ];

        if ( $existing ) {
            $wpdb->update( $sc_table, $data, [ 'ta_id' => $ta->id ] );
        } else {
            $data['ta_id']   = $ta->id;
            $data['user_id'] = $uid;
            $wpdb->insert( $sc_table, $data );
        }

        wp_send_json_success( [ 'saved' => true ] );
    }

    public function story_critique_get(): void {
        $this->verify( 'ta_dashboard_nonce' );
        $uid = get_current_user_id();
        if ( ! TA_Roles::is_ta( $uid ) ) {
            wp_send_json_error( 'دسترسی غیرمجاز' );
        }

        $ta_table = TA_Database::table( 'assistants' );
        $ta       = TA_Database::get_row( "SELECT id FROM {$ta_table} WHERE user_id = %d", [ $uid ] );
        if ( ! $ta ) {
            wp_send_json_success( null );
        }

        $sc_table = TA_Database::table( 'story_critique_forms' );
        $row      = TA_Database::get_row( "SELECT * FROM {$sc_table} WHERE ta_id = %d", [ $ta->id ] );

        if ( $row ) {
            $row->specialties = json_decode( $row->specialties, true ) ?: [];
            $row->is_saved    = true;
        } else {
            // فرم هنوز پر نشده — نام و تلفن را از حساب کاربری پیش‌پر می‌کنیم
            $user         = get_userdata( $uid );
            $display_name = $user ? $user->display_name : '';
            // ترجیح: first_name + last_name، در صورت خالی بودن: display_name
            $first = $user ? get_user_meta( $uid, 'first_name', true ) : '';
            $last  = $user ? get_user_meta( $uid, 'last_name',  true ) : '';
            if ( $first || $last ) {
                $display_name = trim( $first . ' ' . $last );
            }
            // شماره تلفن از billing WooCommerce
            $phone = get_user_meta( $uid, 'billing_phone', true ) ?: '';
            $row  = (object) [
                'full_name'       => $display_name,
                'phone'           => $phone,
                'bale_id'         => '',
                'specialties'     => [],
                'other_specialty' => '',
                'hours_per_day'   => '',
                'is_saved'        => false,
            ];
        }
        wp_send_json_success( $row );
    }


}
