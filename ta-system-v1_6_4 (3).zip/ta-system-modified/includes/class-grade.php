<?php
defined( 'ABSPATH' ) || exit;

class TA_Grade {

    const GRADE_PASS     = 'pass';
    const GRADE_REPEAT   = 'repeat';
    const GRADE_CRITIQUE = 'critique';
    const GRADE_PENDING  = 'pending'; // این خط اضافه شود


    /**
     * ثبت یا به‌روزرسانی نمره
     */
    public static function set_grade(
        int    $student_id,
        int    $product_id,
        int    $term_id,
        string $course_type,
        string $grade,
        int    $ta_id,
        string $notes = ''
    ): bool {
        global $wpdb;
        $table = TA_Database::table( 'grades' );

        $existing = TA_Database::get_row(
            "SELECT id FROM {$table} WHERE student_id = %d AND product_id = %d",
            [ $student_id, $product_id ]
        );

        if ( $existing ) {
            return false !== TA_Database::update(
                'ta_grades',
                [
                    'grade'      => $grade,
                    'ta_id'      => $ta_id,
                    'notes'      => $notes,
                    'updated_at' => current_time( 'mysql' ),
                ],
                [ 'id' => $existing->id ]
            );
        }

        return false !== TA_Database::insert(
            'ta_grades',
            [
                'student_id'  => $student_id,
                'product_id'  => $product_id,
                'term_id'     => $term_id,
                'course_type' => $course_type,
                'grade'       => $grade,
                'ta_id'       => $ta_id,
                'notes'       => $notes,
                'created_at'  => current_time( 'mysql' ),
            ]
        );
    }

    /**
     * دریافت نمره هنرجو برای یک محصول
     */
    public static function get_grade( int $student_id, int $product_id ): ?object {
        $table = TA_Database::table( 'grades' );
        return TA_Database::get_row(
            "SELECT * FROM {$table} WHERE student_id = %d AND product_id = %d",
            [ $student_id, $product_id ]
        );
    }

    /**
     * لیبل فارسی نمره
     */
    public static function grade_label( string $grade ): string {
        return match ( $grade ) {
            'pass'     => 'قبولی',
            'repeat'   => 'تکرار دوره',
            'critique' => 'نقد اثر',
            'pending'  => 'ثبت‌نشده', // این خط اضافه شود
            default    => 'نامشخص',
        };
    }
}
