<?php
defined( 'ABSPATH' ) || exit;

/**
 * بررسی صلاحیت هنرجو برای هر نوع دوره
 */
class TA_Eligibility {


    public static function check( int $student_id, int $product_id ): array {
    // بررسی فعال بودن سیستم
    if ( ! TA_Settings_Helper::system_active() ) {
        return self::result( false, 'blocked', 'سیستم انتخاب استادیار در حال حاضر غیرفعال است.' );
    }
    $settings = self::get_product_settings( $product_id );
    if ( ! $settings ) {
        return self::result( false, 'blocked', 'تنظیمات این محصول ناقص است. با پشتیبانی تماس بگیرید.' );
    }

    // ── بررسی خرید ─────────────────────────────────────────────────────
if ( TA_Settings_Helper::is_enabled( 'require_purchase' ) && ! self::student_has_purchased( $student_id, $product_id ) ) {
    
    // تعریف شناسه‌های دوره‌هایی که پیام متفاوتی دارند
    // بر اساس ساختار افزونه، 'professional' برای حرفه‌ای و احتمالاً 'advanced' یا 'creative' برای نقد اثر است
    $custom_message_courses = ['professional', 'critique']; 

    if ( in_array( $settings->course_type, $custom_message_courses, true ) ) {
        // پیام برای دوره‌های نقد اثر و نویسندگی حرفه‌ای
        $error_message = 'برای ورود به دوره، ابتدا ثبت نام کنید سپس از اینجا وارد گروه یا کانال دوره شوید.';
    } else {
        // پیام پیش‌فرض برای سایر دوره‌ها
        $error_message = TA_Settings_Helper::get_text('text_not_purchased');
    }

    return self::result(
        false,
        'blocked',
        $error_message
    );
}












    // ── بررسی اگر قبلاً استادیار انتخاب کرده (برای دوره های غیر حرفه‌ای) ──
    if ( $settings->course_type !== 'professional' && self::already_assigned( $student_id, $product_id ) ) {
        // اگر تغییر استادیار مجاز باشد، بررسی می‌کنیم
        if ( TA_Settings_Helper::is_enabled( 'allow_reassignment' ) ) {
            $limit_days = (int) TA_Settings_Helper::get( 'reassignment_limit_days', 0 );
            if ( $limit_days > 0 ) {
                $assign_table = TA_Database::table( 'assignments' );
                $row = TA_Database::get_row(
                    "SELECT created_at FROM {$assign_table} WHERE student_id = %d AND product_id = %d ORDER BY id DESC LIMIT 1",
                    [ $student_id, $product_id ]
                );
                if ( $row ) {
                    $elapsed = ( time() - strtotime( $row->created_at ) ) / DAY_IN_SECONDS;
                    if ( $elapsed > $limit_days ) {
                        return self::result( false, 'blocked', sprintf(
                            'مهلت تغییر استادیار (%d روز) به پایان رسیده است.',
                            $limit_days
                        ) );
                    }
                }
            }
            // مهلت هنوز باقی است — اجازه ادامه
        } else {
            return self::result( false, 'blocked', TA_Settings_Helper::get_text('text_already_assigned') );
        }
    }

    switch ( $settings->course_type ) {
        case 'creative':
            return self::check_creative( $student_id, $product_id, $settings );
        case 'intro':
            return self::check_intro( $student_id, $product_id, $settings );
        case 'advanced':
            return self::check_advanced( $student_id, $product_id, $settings );
        case 'professional':
            return self::check_professional( $student_id, $product_id, $settings );
        case 'critique':
            return self::check_critique( $student_id, $product_id, $settings );
        default:
            return self::result( false, 'blocked', 'نوع دوره ناشناخته است.' );
    }
}


    // ── نقد ───────────────────────────────────────────────────────
    private static function check_critique( int $student_id, int $product_id, object $settings ): array {
       return self::result( true, 'show_critique_link', 'شما مجاز به ورود به گروه نقد اثر هستید.' );
       
    }
    
    // ── نویسندگی خلاق ───────────────────────────────────────────────────────
    private static function check_creative( int $student_id, int $product_id, object $settings ): array {
        return self::result( true, 'normal', '' );
    }

    // ── نویسندگی مقدماتی ────────────────────────────────────────────────────
    private static function check_intro( int $student_id, int $product_id, object $settings ): array {
    $prereq_ids = TA_Product_Meta::get_prerequisites( $product_id );

    // اگر پیش‌نیازی تعریف نشده
    if ( empty( $prereq_ids ) ) {
        return self::result( false, 'blocked', 'پیش‌نیاز این دوره تعریف نشده است. با پشتیبانی تماس بگیرید.' );
    }

    $has_pass = false;
    $has_repeat = false;
    $passing_grade_obj = null;

    // بررسی دوره‌های پیش‌نیاز
    foreach ( $prereq_ids as $prereq_id ) {
        
        $grade_obj = TA_Grade::get_grade( $student_id, $prereq_id );
        
        if ( $grade_obj ) {
            $intro_ok = (array) TA_Settings_Helper::get('critique_eligible_grades');
            if ( $grade_obj->grade === TA_Grade::GRADE_PASS ) {
                $has_pass = true;
                $passing_grade_obj = $grade_obj;
                break; // اگر حتی در یک پیش‌نیاز قبولی داشت، بررسی متوقف شود
            } elseif ( $grade_obj->grade === TA_Grade::GRADE_REPEAT ) {
                $has_repeat = true;
                // در اینجا break نمی‌کنیم، چون ممکن است در یک پیش‌نیاز دیگر (مثلاً دوره خلاق قبلی) نمره قبولی داشته باشد
            }
        }
    }

    // حالت ۴: قبولی دارد → مسیر عادی (انتخاب استادیار)
    if ( $has_pass ) {
        return self::result( true, 'normal', '', $passing_grade_obj );
    }

    // حالت ۲: نمره «تکرار دوره» دارد (و هیچ قبولی دیگری ندارد) → مسدود با پیام اختصاصی
    if ( $has_repeat ) {
        return self::result( false, 'blocked', 'شما در دوره خلاق نتیجه «تکرار دوره» دریافت کرده‌اید. لطفاً برای ثبت‌نام مجدد در دوره خلاق و بررسی شرایط، از طریق چت سایت با پشتیبانی در تماس باشید.' );
    }

    // حالت ۳: نه قبولی دارد و نه تکرار (یعنی نمره هنوز ثبت نشده، pending است یا اصلا در دوره پیش‌نیاز نبوده)
    
    return self::result( false, 'blocked', 'برای شرکت در این دوره، باید ابتدا در دوره نویسندگی خلاق نمره قبولی دریافت کنید. از طریق چت سایت با پشتیبانی در تماس باشید.' );
}


    // ── نویسندگی پیشرفته ────────────────────────────────────────────────────
    private static function check_advanced( int $student_id, int $product_id, object $settings ): array {
        $prereq_ids = TA_Product_Meta::get_prerequisites( $product_id );

        if ( empty( $prereq_ids ) ) {
            return self::result( false, 'blocked', 'پیش‌نیاز این دوره تعریف نشده است. با پشتیبانی تماس بگیرید.' );
        }

        $best_grade    = null;
        $has_critique  = false;

        foreach ( $prereq_ids as $prereq_id ) {
            $grade = TA_Grade::get_grade( $student_id, $prereq_id );
            if ( ! $grade ) {
                continue;
            }
            if ( $grade->grade === TA_Grade::GRADE_PASS ) {
                $best_grade = $grade;
                break;
            }
            if ( $grade->grade === TA_Grade::GRADE_CRITIQUE ) {
                $has_critique = true;
            }
        }

        if ( $best_grade ) {
            return self::result( true, 'normal', '', $best_grade );
        }

        $advanced_ok_grades = (array) TA_Settings_Helper::get('advanced_eligible_grades');
        if ( $has_critique && in_array('critique', $advanced_ok_grades, true) ) {
            return self::result( false, 'blocked', 'شما باید ابتدا در دوره «نقد اثر» شرکت کنید.' );
        }

        return self::result( false, 'blocked', 'شما مجوز ادامه دوره را ندارید. ابتدا باید دوره نویسندگی مقدماتی را با موفقیت بگذرانید.' );
    }

    // ── نویسندگی حرفه‌ای ────────────────────────────────────────────────────
    private static function check_professional( int $student_id, int $product_id, object $settings ): array {
        
        // ── ① اگر قبلاً تخصیص فعال دارد، مستقیم به show_link ──────────────
    if ( self::already_assigned( $student_id, $product_id ) ) {
        return self::result(
            true,
            'show_link',
            'شما قبلاً در این دوره حرفه‌ای استادیار دارید.'
        );
    }
    // ────────────────────────────────────────────────────────────────────
        
        $prereq_ids = TA_Product_Meta::get_prerequisites( $product_id );

        if ( empty( $prereq_ids ) ) {
            return self::result( false, 'blocked', 'پیش‌نیاز این دوره تعریف نشده است. با پشتیبانی تماس بگیرید.' );
        }

        $best_grade = null;

        foreach ( $prereq_ids as $prereq_id ) {
            $grade = TA_Grade::get_grade( $student_id, $prereq_id );
            if ( ! $grade ) {
                continue;
            }
            if ( $grade->grade === TA_Grade::GRADE_PASS ) {
                $best_grade = $grade;
                break; 
            }
        }

        if ( $best_grade ) {
          
              return self::result( true, 'assign_professional', '', $best_grade );

        }

        return self::result( false, 'blocked', 'شما مجوز شرکت در دوره حرفه‌ای را ندارید. ابتدا باید پیش‌نیازها را با موفقیت بگذرانید.' );
    }

    // ── Helpers ─────────────────────────────────────────────────────────────

    private static function result(
        bool    $eligible,
        string  $path,
        string  $message,
        ?object $grade = null
    ): array {
        return compact( 'eligible', 'path', 'message', 'grade' );
    }

    public static function get_product_settings( int $product_id ): ?object {
        $table = TA_Database::table( 'product_settings' );
        return TA_Database::get_row(
            "SELECT * FROM {$table} WHERE product_id = %d",
            [ $product_id ]
        );
    }

    private static function student_has_purchased( int $student_id, int $product_id ): bool {
        if ( ! function_exists( 'wc_get_orders' ) ) {
            return false;
        }
        $orders = wc_get_orders( [
            'customer_id' => $student_id,
            'status'      => [ 'wc-completed', 'wc-processing', 'wc-partial-payment' ],
            'limit'       => -1,
        ] );

        foreach ( $orders as $order ) {
            foreach ( $order->get_items() as $item ) {
                if ( (int) $item->get_product_id() === $product_id ) {
                    return true;
                }
                if ( (int) $item->get_variation_id() === $product_id ) {
                    return true;
                }
            }
        }
        return false;
    }

    public static function already_assigned( int $student_id, int $product_id ): bool {
        $table = TA_Database::table( 'assignments' );
        $row = TA_Database::get_row(
            "SELECT id FROM {$table} WHERE student_id = %d AND product_id = %d",
            [ $student_id, $product_id ]
        );
        return (bool) $row;
    }

    private static function get_level_assessment( int $student_id, int $product_id ): ?object {
        $table = TA_Database::table( 'level_assessments' );
        return TA_Database::get_row(
            "SELECT * FROM {$table} WHERE student_id = %d AND product_id = %d",
            [ $student_id, $product_id ]
        );
    }

    public static function get_previous_group_link( int $student_id, int $product_id ): ?string {
        $prereq_ids = TA_Product_Meta::get_prerequisites( $product_id );
        if ( empty( $prereq_ids ) ) {
            return null;
        }

        $assign_table = TA_Database::table( 'assignments' );
        foreach ( $prereq_ids as $prereq_id ) {
            $row = TA_Database::get_row(
                "SELECT group_link FROM {$assign_table}
                 WHERE student_id = %d AND product_id = %d AND group_link IS NOT NULL",
                [ $student_id, $prereq_id ]
            );
            if ( $row && $row->group_link ) {
                return $row->group_link;
            }
        }
        return null;
    }
}
