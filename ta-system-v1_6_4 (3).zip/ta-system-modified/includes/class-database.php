<?php
defined( 'ABSPATH' ) || exit;

class TA_Database {

   const SCHEMA_VERSION = '1.3.4';



    /**
     * بررسی خودکار: اگر جداول وجود ندارند، نصب کن
     */
    public static function maybe_install(): void {
        $current = get_option( 'ta_system_db_version', '0' );
        if ( $current !== self::SCHEMA_VERSION ) {
            self::install();
        }
        // migrate همیشه اجرا می‌شود — ستون‌های جدید را safe اضافه می‌کند
        self::migrate( $current );
    }

    /**
     * مایگریشن برای نصب‌های قبلی
     */
   private static function migrate( $from_version ) {
    global $wpdb;
    
    $current_version = get_option( 'ta_system_db_version', '0' );
    
    // Migration for version 1.1.0
    if ( version_compare( $current_version, '1.1.0', '<' ) ) {
        $wpdb->query( "ALTER TABLE {$wpdb->prefix}ta_assignments 
            ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'active'" );
    }
    
    // Migration for version 1.2.0
    if ( version_compare( $current_version, '1.2.0', '<' ) ) {
        $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ta_capacity (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            ta_id bigint(20) NOT NULL,
            product_id bigint(20) NOT NULL,
            max_capacity int(11) DEFAULT 0,
            current_load int(11) DEFAULT 0,
            PRIMARY KEY (id),
            KEY ta_id (ta_id),
            KEY product_id (product_id)
        ) {$wpdb->get_charset_collate()};" );
    }
    
    // Migration for version 1.3.0
    if ( version_compare( $current_version, '1.3.0', '<' ) ) {
        $wpdb->query( "ALTER TABLE {$wpdb->prefix}ta_assignments 
            ADD COLUMN IF NOT EXISTS assigned_date datetime DEFAULT NULL" );
    }
    
    // Migration for version 1.4.0
    if ( version_compare( $current_version, '1.4.0', '<' ) ) {
        $wpdb->query( "ALTER TABLE {$wpdb->prefix}ta_grades 
            ADD COLUMN IF NOT EXISTS feedback_date datetime DEFAULT NULL" );
    }
    
   // آپدیت نسخه 1.6.0
if ( version_compare( $current_version, '1.6.0', '<' ) ) {
    $table_assignments = self::table('assignments');
    
    // چک کردن وجود ستون‌ها قبل از اضافه کردن
    $columns = $wpdb->get_col( "DESCRIBE {$table_assignments}", 0 );
    
    if ( ! in_array( 'cancel_reason', $columns ) ) {
        $wpdb->query("ALTER TABLE {$table_assignments} ADD COLUMN cancel_reason TEXT DEFAULT NULL");
    }
    
    if ( ! in_array( 'cancel_date', $columns ) ) {
        $wpdb->query("ALTER TABLE {$table_assignments} ADD COLUMN cancel_date DATETIME DEFAULT NULL");
    }
}

   

     // Migration for version 1.7.0 - payroll approval requests
    if ( version_compare( $current_version, '1.7.0', '<' ) ) {
        $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ta_payroll_requests (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            ta_id       BIGINT UNSIGNED NOT NULL,
            term_id     BIGINT UNSIGNED NOT NULL,
            total_fee   DECIMAL(15,2) NOT NULL DEFAULT 0,
            status      VARCHAR(20)   NOT NULL DEFAULT 'pending',
            admin_note  TEXT          DEFAULT NULL,
            ta_note     TEXT          DEFAULT NULL,
            requested_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            reviewed_at  DATETIME     DEFAULT NULL,
            paid_at      DATETIME     DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_ta_term (ta_id, term_id),
            KEY idx_ta   (ta_id),
            KEY idx_term (term_id),
            KEY idx_status (status)
        ) " . $wpdb->get_charset_collate() );
    }

    // Migration for version 1.1.3 - payroll request logs + approved_fee column
    if ( version_compare( $current_version, '1.1.3', '<' ) ) {
        $tbl = self::table('payroll_requests');
        $cols = $wpdb->get_col( "DESCRIBE {$tbl}", 0 );
        if ( ! in_array( 'approved_fee', $cols ) ) {
            $wpdb->query( "ALTER TABLE {$tbl} ADD COLUMN approved_fee DECIMAL(15,2) DEFAULT NULL AFTER total_fee" );
        }
        $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ta_payroll_request_logs (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            request_id   BIGINT UNSIGNED NOT NULL,
            ta_id        BIGINT UNSIGNED NOT NULL,
            term_id      BIGINT UNSIGNED NOT NULL,
            action       VARCHAR(30)  NOT NULL,
            actor_type   VARCHAR(10)  NOT NULL DEFAULT 'admin',
            actor_id     BIGINT UNSIGNED NOT NULL DEFAULT 0,
            total_fee    DECIMAL(15,2) NOT NULL DEFAULT 0,
            note         TEXT DEFAULT NULL,
            created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_request (request_id),
            KEY idx_ta      (ta_id),
            KEY idx_term    (term_id)
        ) " . $wpdb->get_charset_collate() );
    }


    // Migration: اطمینان از وجود همه ستون‌های لازم (همیشه اجرا — safe با IF NOT EXISTS)
    {
        $tbl  = self::table('payroll_requests');
        $cols = $wpdb->get_col( "DESCRIBE {$tbl}", 0 );
        $needed = [
            'approved_fee'      => "ALTER TABLE {$tbl} ADD COLUMN approved_fee      DECIMAL(15,2) DEFAULT NULL AFTER total_fee",
            'prev_approved_fee' => "ALTER TABLE {$tbl} ADD COLUMN prev_approved_fee DECIMAL(15,2) DEFAULT NULL AFTER approved_fee",
            'diff_status'       => "ALTER TABLE {$tbl} ADD COLUMN diff_status       VARCHAR(20)   DEFAULT NULL AFTER paid_at",
            'diff_amount'       => "ALTER TABLE {$tbl} ADD COLUMN diff_amount       DECIMAL(15,2) DEFAULT NULL AFTER diff_status",
            'diff_approved_fee' => "ALTER TABLE {$tbl} ADD COLUMN diff_approved_fee DECIMAL(15,2) DEFAULT NULL AFTER diff_amount",
            'diff_ta_note'      => "ALTER TABLE {$tbl} ADD COLUMN diff_ta_note      TEXT          DEFAULT NULL AFTER diff_approved_fee",
            'diff_admin_note'   => "ALTER TABLE {$tbl} ADD COLUMN diff_admin_note   TEXT          DEFAULT NULL AFTER diff_ta_note",
            'diff_reviewed_at'  => "ALTER TABLE {$tbl} ADD COLUMN diff_reviewed_at  DATETIME      DEFAULT NULL AFTER diff_admin_note",
            'diff_paid_at'      => "ALTER TABLE {$tbl} ADD COLUMN diff_paid_at      DATETIME      DEFAULT NULL AFTER diff_reviewed_at",
        ];
        foreach ( $needed as $col => $sql ) {
            if ( ! in_array( $col, $cols ) ) $wpdb->query( $sql );
        }
    }


    // Migration for version 1.3.4 - payroll adjustments (extra/deduction per TA per term)
    {
        $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ta_payroll_adjustments (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            ta_id       BIGINT UNSIGNED NOT NULL,
            term_id     BIGINT UNSIGNED NOT NULL,
            type        ENUM('extra','deduction') NOT NULL DEFAULT 'extra',
            amount      DECIMAL(15,2) NOT NULL DEFAULT 0,
            description TEXT DEFAULT NULL,
            created_by  BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_ta_term (ta_id, term_id),
            KEY idx_term    (term_id),
            KEY idx_ta      (ta_id)
        ) " . $wpdb->get_charset_collate() );
    }

    update_option( 'ta_system_db_version', self::SCHEMA_VERSION );
}

    /**
     * بررسی اینکه آیا جداول اصلی وجود دارند
     */
    public static function tables_exist(): bool {
        global $wpdb;
        $result = $wpdb->get_var(
            "SHOW TABLES LIKE '{$wpdb->prefix}ta_assistants'"
        );
        return ! empty( $result );
    }

    /**
     * ایجاد جداول با CREATE TABLE IF NOT EXISTS
     */
    public static function install(): void {
        global $wpdb;

        $charset = $wpdb->get_charset_collate();

        $tables = [

            // ── ترم‌ها ──────────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ta_terms` (
                `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `name`        VARCHAR(100) NOT NULL,
                `slug`        VARCHAR(100) NOT NULL,
                `order_index` INT NOT NULL DEFAULT 0,
                `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `slug` (`slug`)
            ) {$charset}",

            // ── تنظیمات محصول ───────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ta_product_settings` (
                `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `product_id`     BIGINT UNSIGNED NOT NULL,
                `term_id`        BIGINT UNSIGNED NOT NULL,
                `course_type`    VARCHAR(20) NOT NULL,
                `pro_group_link` VARCHAR(500) DEFAULT NULL,
                `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `product_id` (`product_id`),
                KEY `idx_term` (`term_id`)
            ) {$charset}",

            // ── پیش‌نیازهای چندگانه ──────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ta_product_prerequisites` (
                `id`                      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `product_id`              BIGINT UNSIGNED NOT NULL,
                `prerequisite_product_id` BIGINT UNSIGNED NOT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uniq_prod_prereq` (`product_id`, `prerequisite_product_id`),
                KEY `idx_product` (`product_id`)
            ) {$charset}",

            // ── استادیارها ───────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ta_assistants` (
                `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id`      BIGINT UNSIGNED NOT NULL,
                `rank`         INT UNSIGNED NOT NULL DEFAULT 0,
               
                `bio`          TEXT DEFAULT NULL,
                `is_active`    TINYINT(1) NOT NULL DEFAULT 1,
                `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `user_id` (`user_id`),
                KEY `idx_rank` (`rank`)
            ) {$charset}",

            // ── ظرفیت استادیار ───────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ta_capacities` (
                `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `ta_id`          BIGINT UNSIGNED NOT NULL,
                `course_type`    VARCHAR(20) NOT NULL,
                `term_id`        BIGINT UNSIGNED NOT NULL,
                `student_gender` VARCHAR(10) NOT NULL DEFAULT 'both',
                `messenger`      VARCHAR(20) NOT NULL DEFAULT 'both',
                `total_capacity` INT UNSIGNED NOT NULL DEFAULT 0,
                `used_capacity`  INT UNSIGNED NOT NULL DEFAULT 0,
                `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uniq_ta_course_term_gender` (`ta_id`, `course_type`, `term_id`, `student_gender`),
                KEY `idx_ta` (`ta_id`)
            ) {$charset}",

            // ── گروه‌های نویسندگی خلاق ───────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ta_groups` (
                `id`                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `capacity_id`         BIGINT UNSIGNED NOT NULL,
                `ta_id`               BIGINT UNSIGNED NOT NULL,
                `messenger_type`      VARCHAR(20) NOT NULL,
                `group_link`          VARCHAR(500) NOT NULL,
                `is_used`             TINYINT(1) NOT NULL DEFAULT 0,
                `assigned_to_user_id` BIGINT UNSIGNED DEFAULT NULL,
                `assigned_at`         DATETIME DEFAULT NULL,
                `created_at`          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `idx_capacity` (`capacity_id`),
                KEY `idx_ta` (`ta_id`),
                KEY `idx_used` (`is_used`)
            ) {$charset}",

            // ── تخصیص هنرجو به استادیار ─────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ta_assignments` (
                `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `student_id`     BIGINT UNSIGNED NOT NULL,
                `ta_id`          BIGINT UNSIGNED NOT NULL,
                `product_id`     BIGINT UNSIGNED NOT NULL,
                `term_id`        BIGINT UNSIGNED NOT NULL,
                `capacity_id`    BIGINT UNSIGNED NOT NULL DEFAULT 0,
                `course_type`    VARCHAR(20) NOT NULL,
                `messenger`      VARCHAR(20) DEFAULT NULL,
                `student_gender` VARCHAR(10) DEFAULT NULL,
                `group_id`       BIGINT UNSIGNED DEFAULT NULL,
                `group_link`     VARCHAR(500) DEFAULT NULL,
                `status`         VARCHAR(20) NOT NULL DEFAULT 'active',
                `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `cancel_reason`  text DEFAULT NULL,
                `cancel_date`    datetime DEFAULT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uniq_student_product` (`student_id`, `product_id`),
                KEY `idx_student` (`student_id`),
                KEY `idx_ta` (`ta_id`),
                KEY `idx_term` (`term_id`)
            ) {$charset}",

            // ── نمره‌ها ──────────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ta_grades` (
                `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `student_id`  BIGINT UNSIGNED NOT NULL,
                `product_id`  BIGINT UNSIGNED NOT NULL,
                `term_id`     BIGINT UNSIGNED NOT NULL,
                `course_type` VARCHAR(20) NOT NULL,
                `grade`       VARCHAR(20) NOT NULL,
                `ta_id`       BIGINT UNSIGNED NOT NULL,
                `notes`       TEXT DEFAULT NULL,
                `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uniq_student_product` (`student_id`, `product_id`),
                KEY `idx_student` (`student_id`),
                KEY `idx_term` (`term_id`),
                KEY `idx_grade` (`grade`)
            ) {$charset}",

            // ── تعیین سطح ────────────────────────────────────────────────────
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ta_level_assessments` (
                `id`                    BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `student_id`            BIGINT UNSIGNED NOT NULL,
                `product_id`            BIGINT UNSIGNED NOT NULL,
                `ta_id`                 BIGINT UNSIGNED DEFAULT NULL,
                `file_path`             VARCHAR(500) DEFAULT NULL,
                `file_original_name`    VARCHAR(255) DEFAULT NULL,
                `status`                VARCHAR(30) NOT NULL DEFAULT 'pending_ta',
                `group_link_by_student` VARCHAR(500) DEFAULT NULL,
                `group_messenger`       VARCHAR(20) DEFAULT NULL,
                `result_notes`          TEXT DEFAULT NULL,
                `created_at`            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at`            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uniq_student_product` (`student_id`, `product_id`),
                KEY `idx_student` (`student_id`),
                KEY `idx_ta` (`ta_id`),
                KEY `idx_status` (`status`)
            ) {$charset}",

            // ── درخواست‌های تایید حق‌الزحمه ─────────────────────────────────
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ta_payroll_requests` (
                `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `ta_id`        BIGINT UNSIGNED NOT NULL,
                `term_id`      BIGINT UNSIGNED NOT NULL,
                `total_fee`    DECIMAL(15,2)   NOT NULL DEFAULT 0,
                `approved_fee`      DECIMAL(15,2)   DEFAULT NULL,
                `prev_approved_fee` DECIMAL(15,2)   DEFAULT NULL,
                `status`       VARCHAR(20)     NOT NULL DEFAULT 'pending',
                `admin_note`   TEXT            DEFAULT NULL,
                `ta_note`      TEXT            DEFAULT NULL,
                `requested_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `reviewed_at`  DATETIME        DEFAULT NULL,
                `paid_at`      DATETIME        DEFAULT NULL,
                `diff_status`       VARCHAR(20)     DEFAULT NULL COMMENT 'مسیر مستقل تفاوت: pending|ta_approved|ta_rejected|approved|paid',
                `diff_amount`       DECIMAL(15,2)   DEFAULT NULL COMMENT 'مبلغ تفاوت = total_fee - prev_approved_fee',
                `diff_approved_fee` DECIMAL(15,2)   DEFAULT NULL COMMENT 'مبلغ تایید‌شده تفاوت توسط ادمین',
                `diff_ta_note`      TEXT            DEFAULT NULL,
                `diff_admin_note`   TEXT            DEFAULT NULL,
                `diff_reviewed_at`  DATETIME        DEFAULT NULL,
                `diff_paid_at`      DATETIME        DEFAULT NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uniq_ta_term` (`ta_id`, `term_id`),
                KEY `idx_ta`     (`ta_id`),
                KEY `idx_term`   (`term_id`),
                KEY `idx_status` (`status`)
            ) {$charset}",

            // ── لاگ تاریخچه درخواست‌های حق‌الزحمه ──────────────────────────
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ta_payroll_request_logs` (
                `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `request_id`   BIGINT UNSIGNED NOT NULL,
                `ta_id`        BIGINT UNSIGNED NOT NULL,
                `term_id`      BIGINT UNSIGNED NOT NULL,
                `action`       VARCHAR(30)     NOT NULL,
                `actor_type`   VARCHAR(10)     NOT NULL DEFAULT 'admin',
                `actor_id`     BIGINT UNSIGNED NOT NULL DEFAULT 0,
                `total_fee`    DECIMAL(15,2)   NOT NULL DEFAULT 0,
                `note`         TEXT            DEFAULT NULL,
                `created_at`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `idx_request` (`request_id`),
                KEY `idx_ta`      (`ta_id`),
                KEY `idx_term`    (`term_id`)
            ) {$charset}",


            // ── تعدیلات حق‌الزحمه (مبلغ اضافی / کسورات) ────────────────────────
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ta_payroll_adjustments` (
                `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `ta_id`       BIGINT UNSIGNED NOT NULL,
                `term_id`     BIGINT UNSIGNED NOT NULL,
                `type`        ENUM('extra','deduction') NOT NULL DEFAULT 'extra',
                `amount`      DECIMAL(15,2) NOT NULL DEFAULT 0,
                `description` TEXT DEFAULT NULL,
                `created_by`  BIGINT UNSIGNED NOT NULL DEFAULT 0,
                `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `idx_ta_term` (`ta_id`, `term_id`),
                KEY `idx_term`    (`term_id`),
                KEY `idx_ta`      (`ta_id`)
            ) {$charset}",

            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ta_blacklist` (
                `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `ta_id`      BIGINT UNSIGNED NOT NULL,
                `student_id` BIGINT UNSIGNED NOT NULL,
                `reason`     TEXT DEFAULT NULL,
                `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uniq_ta_student` (`ta_id`, `student_id`),
                KEY `idx_ta` (`ta_id`)
            ) {$charset}",

            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}ta_story_critique_forms` (
                `id`              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `ta_id`           BIGINT UNSIGNED NOT NULL,
                `user_id`         BIGINT UNSIGNED NOT NULL,
                `full_name`       VARCHAR(191) NOT NULL DEFAULT '',
                `phone`           VARCHAR(30)  NOT NULL DEFAULT '',
                `bale_id`         VARCHAR(100) NOT NULL DEFAULT '',
                `specialties`     TEXT         NOT NULL DEFAULT '',
                `other_specialty` TEXT         DEFAULT NULL,
                `hours_per_day`   VARCHAR(100) NOT NULL DEFAULT '',
                `created_at`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `idx_ta` (`ta_id`)
            ) {$charset}",
        ];

        // اجرای هر query به صورت مستقیم
        foreach ( $tables as $sql ) {
            $wpdb->query( $sql ); // phpcs:ignore
        }

        update_option( 'ta_system_db_version', self::SCHEMA_VERSION );
    }

    // ── Helper: اجرای query با کش ─────────────────────────────────────────
    public static function get_row( string $sql, array $args = [] ): ?object {
        global $wpdb;
        if ( $args ) {
            $sql = $wpdb->prepare( $sql, $args );
        }
        return $wpdb->get_row( $sql ) ?: null;
    }

    public static function get_results( string $sql, array $args = [] ): array {
        global $wpdb;
        if ( $args ) {
            $sql = $wpdb->prepare( $sql, $args );
        }
        return $wpdb->get_results( $sql ) ?: [];
    }

    public static function insert( string $table, array $data, array $format = [] ): int|false {
        global $wpdb;
        $result = $wpdb->insert( $wpdb->prefix . $table, $data, $format ?: null );
        return $result ? $wpdb->insert_id : false;
    }

    public static function update( string $table, array $data, array $where, array $format = [], array $where_format = [] ): int|false {
        global $wpdb;
        return $wpdb->update(
            $wpdb->prefix . $table,
            $data,
            $where,
            $format ?: null,
            $where_format ?: null
        );
    }

    public static function delete( string $table, array $where, array $where_format = [] ): int|false {
        global $wpdb;
        return $wpdb->delete( $wpdb->prefix . $table, $where, $where_format ?: null );
    }

    /**
     * دریافت نام جدول با prefix
     */
    public static function table( string $name ): string {
        global $wpdb;
        return $wpdb->prefix . 'ta_' . $name;
    }
}
