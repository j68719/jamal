<?php
defined( 'ABSPATH' ) || exit;

class TA_Product_Meta {

    public function __construct() {}

    /**
     * دریافت تنظیمات محصول با cache
     */
    public static function get_settings( int $product_id ): ?object {
        $cache_key = "ta_product_settings_{$product_id}";
        $cached    = wp_cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached ?: null;
        }

        $table = TA_Database::table( 'product_settings' );
        $row   = TA_Database::get_row(
            "SELECT * FROM {$table} WHERE product_id = %d",
            [ $product_id ]
        );

        wp_cache_set( $cache_key, $row ?: 0, '', 300 );
        return $row ?: null;
    }

    /**
     * دریافت لیست پیش‌نیازهای یک محصول (آرایه‌ای از product_id ها)
     */
    public static function get_prerequisites( int $product_id ): array {
        $cache_key = "ta_prerequisites_{$product_id}";
        $cached    = wp_cache_get( $cache_key );
        if ( $cached !== false ) {
            return $cached ?: [];
        }

        $table = TA_Database::table( 'product_prerequisites' );
        $rows  = TA_Database::get_results(
            "SELECT prerequisite_product_id FROM {$table} WHERE product_id = %d",
            [ $product_id ]
        );

        $ids = array_map( fn( $r ) => (int) $r->prerequisite_product_id, $rows );
        wp_cache_set( $cache_key, $ids, '', 300 );
        return $ids;
    }

    /**
     * ذخیره تنظیمات محصول
     */
    public static function save_settings(
        int    $product_id,
        int    $term_id,
        string $course_type,
        array  $prerequisite_ids = [],   // آرایه‌ای از product_id ها
        string $pro_group_link   = ''    // لینک ثابت برای دوره حرفه‌ای
    ): bool {
        global $wpdb;

        wp_cache_delete( "ta_product_settings_{$product_id}" );
        wp_cache_delete( "ta_prerequisites_{$product_id}" );

        $settings_table = TA_Database::table( 'product_settings' );
        $prereq_table   = TA_Database::table( 'product_prerequisites' );

        $existing = TA_Database::get_row(
            "SELECT id FROM {$settings_table} WHERE product_id = %d",
            [ $product_id ]
        );

        if ( $existing ) {
            TA_Database::update( 'ta_product_settings', [
                'term_id'        => $term_id,
                'course_type'    => $course_type,
                'pro_group_link' => $course_type === 'professional'|| $course_type === 'critique' ? $pro_group_link : null,
            ], [ 'product_id' => $product_id ] );
        } else {
            TA_Database::insert( 'ta_product_settings', [
                'product_id'     => $product_id,
                'term_id'        => $term_id,
                'course_type'    => $course_type,
                'pro_group_link' => $course_type === 'professional'|| $course_type === 'critique' ? $pro_group_link : null,
                'created_at'     => current_time( 'mysql' ),
            ] );
        }

        // بازنویسی کامل پیش‌نیازها
        $wpdb->delete( $wpdb->prefix . 'ta_product_prerequisites', [ 'product_id' => $product_id ] );

        $prerequisite_ids = array_filter( array_map( 'intval', $prerequisite_ids ) );
        foreach ( $prerequisite_ids as $prereq_id ) {
            if ( $prereq_id && $prereq_id !== $product_id ) {
                TA_Database::insert( 'ta_product_prerequisites', [
                    'product_id'              => $product_id,
                    'prerequisite_product_id' => $prereq_id,
                ] );
            }
        }

        return true;
    }

    /**
     * لیبل فارسی نوع دوره
     */
    public static function course_type_label( string $type ): string {
        return match ( $type ) {
            'creative'     => 'نویسندگی خلاق',
            'intro'        => 'نویسندگی مقدماتی',
            'critique'        => 'نقد اثر',
            'advanced'     => 'نویسندگی پیشرفته',
            'professional' => 'نویسندگی حرفه‌ای',
            default        => $type,
        };
    }
}
