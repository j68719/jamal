<?php
defined( 'ABSPATH' ) || exit;

class TA_Roles {

    public static function add_roles(): void {
        add_role(
            'teaching_assistant',
            'استادیار',
            [
                'read'                       => true,
                'ta_view_dashboard'          => true,
                'ta_manage_capacity'         => true,
                'ta_grade_students'          => true,
                'ta_manage_blacklist'        => true,
                'ta_view_assigned_students'  => true,
                'ta_assess_levels'           => true,
            ]
        );
    }

    public static function remove_roles(): void {
        remove_role( 'teaching_assistant' );
    }

    /**
     * آیا کاربر جاری استادیار است؟
     */
    public static function is_ta( int $user_id = 0 ): bool {
        $user = $user_id ? get_user_by( 'id', $user_id ) : wp_get_current_user();
        if ( ! $user ) {
            return false;
        }
        return in_array( 'teaching_assistant', (array) $user->roles, true )
            || user_can( $user, 'manage_options' ); // ادمین هم دسترسی دارد
    }

    /**
     * آیا کاربر جاری استادیار است (با دسترسی تعیین سطح)؟
     * فعلاً همان استادیار معمولی — می‌توان جدا کرد
     */
    public static function is_level_assessor( int $user_id = 0 ): bool {
        return self::is_ta( $user_id );
    }
}
