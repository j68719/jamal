<?php
defined( 'ABSPATH' ) || exit;

class TA_Admin_TA_Manager {

    public function __construct() {
        add_action( 'admin_post_ta_save_assistant',   [ $this, 'handle_save' ] );
        add_action( 'admin_post_ta_delete_assistant', [ $this, 'handle_delete' ] );
        add_action( 'admin_post_ta_toggle_assistant', [ $this, 'handle_toggle' ] );
        add_action( 'wp_ajax_ta_search_users',        [ $this, 'ajax_search_users' ] );
    }

    public function ajax_search_users(): void {
        check_ajax_referer( 'ta_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();
        wp_send_json_success( TA_User_Helper::search( sanitize_text_field( $_POST['q'] ?? '' ), 20 ) );
    }

    public function handle_save(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'دسترسی غیرمجاز' );
        check_admin_referer( 'ta_save_assistant' );

        $user_id      = (int) ( $_POST['ta_user_id'] ?? 0 );
        $rank         = (int) ( $_POST['ta_rank'] ?? 0 );
      //  $gender_teach = sanitize_text_field( $_POST['ta_gender_teach'] ?? 'both' );
       // $messengers   = array_map( 'sanitize_text_field', (array) ( $_POST['ta_messengers'] ?? [] ) );

        if ( ! $user_id ) {
            wp_redirect( admin_url( 'admin.php?page=ta-assistants&error=no_user' ) );
            exit;
        }

        $user = get_user_by( 'id', $user_id );
        if ( $user && ! in_array( 'teaching_assistant', (array) $user->roles, true ) ) {
            $user->add_role( 'teaching_assistant' );
        }

        $ta_table = TA_Database::table( 'assistants' );
        $existing = TA_Database::get_row( "SELECT id FROM {$ta_table} WHERE user_id = %d", [ $user_id ] );

        $data = [
            'rank'         => $rank,
           // 'gender_teach' => $gender_teach,
           // 'messengers'   => json_encode( array_values( array_filter( $messengers ) ) ),
        ];

        if ( $existing ) {
            TA_Database::update( 'ta_assistants', $data, [ 'user_id' => $user_id ] );
        } else {
            TA_Database::insert( 'ta_assistants', array_merge( $data, [
                'user_id'    => $user_id,
                'is_active'  => 1,
                'created_at' => current_time( 'mysql' ),
            ] ) );
        }

        wp_redirect( admin_url( 'admin.php?page=ta-assistants&saved=1' ) );
        exit;
    }

    public function handle_delete(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'دسترسی غیرمجاز' );
        check_admin_referer( 'ta_delete_assistant' );

        $ta_id = (int) ( $_POST['ta_id'] ?? 0 );
        if ( ! $ta_id ) {
            wp_redirect( admin_url( 'admin.php?page=ta-assistants&error=no_id' ) );
            exit;
        }

        $ta_table = TA_Database::table( 'assistants' );
        $ta = TA_Database::get_row( "SELECT user_id FROM {$ta_table} WHERE id = %d", [ $ta_id ] );
        if ( $ta ) {
            $user = get_user_by( 'id', $ta->user_id );
            if ( $user ) {
                $user->remove_role( 'teaching_assistant' );
            }
        }

        TA_Database::delete( 'ta_assistants', [ 'id' => $ta_id ] );
        TA_Database::delete( 'ta_capacities', [ 'ta_id' => $ta_id ] );

        global $wpdb;
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM " . TA_Database::table( 'groups' ) . " WHERE ta_id = %d AND is_used = 0",
            [ $ta_id ]
        ) );

        wp_redirect( admin_url( 'admin.php?page=ta-assistants&deleted=1' ) );
        exit;
    }

    public function handle_toggle(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'دسترسی غیرمجاز' );
        check_admin_referer( 'ta_toggle_assistant' );

        $ta_id     = (int) ( $_POST['ta_id'] ?? 0 );
        $is_active = (int) ( $_POST['is_active'] ?? 0 );
        TA_Database::update( 'ta_assistants', [ 'is_active' => $is_active ? 0 : 1 ], [ 'id' => $ta_id ] );
        wp_redirect( admin_url( 'admin.php?page=ta-assistants&toggled=1' ) );
        exit;
    }

    public function render(): void {
        if ( ! TA_Database::tables_exist() ) {
            echo '<div class="notice notice-error"><p>جداول پایگاه داده وجود ندارند.</p></div>';
            return;
        }

        if ( isset( $_GET['view_caps'] ) ) {
            $this->render_capacity_view( (int) $_GET['view_caps'] );
            return;
        }

        $ta_table = TA_Database::table( 'assistants' );
        global $wpdb;

        $assistants = $wpdb->get_results(
            "SELECT ta.*, u.display_name, u.user_email
             FROM {$ta_table} ta
             JOIN {$wpdb->users} u ON u.ID = ta.user_id
             ORDER BY ta.rank DESC"
        ) ?: [];

        $gender_labels    = [ 'both' => 'هر دو', 'male' => 'آقایان', 'female' => 'خانم‌ها' ];
        $messenger_labels = [ 'telegram' => 'تلگرام', 'bale' => 'بله', 'eitaa' => 'ایتا' ];
        ?>
        <div class="wrap" dir="rtl">
            <h1>مدیریت استادیارها</h1>

            <?php
            if ( isset( $_GET['saved'] ) )   echo '<div class="notice notice-success is-dismissible"><p>✅ استادیار ذخیره شد.</p></div>';
            if ( isset( $_GET['deleted'] ) ) echo '<div class="notice notice-success is-dismissible"><p>🗑️ استادیار حذف شد.</p></div>';
            if ( isset( $_GET['toggled'] ) ) echo '<div class="notice notice-info is-dismissible"><p>وضعیت تغییر کرد.</p></div>';
            if ( isset( $_GET['error'] ) )   echo '<div class="notice notice-error is-dismissible"><p>خطا رخ داد.</p></div>';
            ?>

            <div class="postbox" style="padding:16px 20px; margin-bottom:20px">
                <h2 style="margin-top:0">افزودن / ویرایش استادیار</h2>
                <form method="post" action="<?= admin_url( 'admin-post.php' ) ?>">
                    <?php wp_nonce_field( 'ta_save_assistant' ); ?>
                    <input type="hidden" name="action"     value="ta_save_assistant">
                    <input type="hidden" name="ta_user_id" id="ta_edit_user_id">
                    <table class="form-table" style="direction:rtl">
                        <tr>
                            <th style="width:140px">کاربر <span style="color:red">*</span></th>
                            <td>
                                <div style="position:relative;display:inline-block">
                                    <input type="text"
                                           id="ta_user_search_input"
                                           placeholder="نام، شماره همراه یا ایمیل..."
                                           autocomplete="off"
                                           style="min-width:360px;padding:5px 10px;border:1px solid #8c8f94;border-radius:3px;font-size:14px">
                                    <div id="ta_user_search_results"
                                         style="display:none;position:absolute;right:0;top:100%;min-width:360px;max-height:260px;
                                                overflow-y:auto;background:#fff;border:1px solid #ccc;border-top:none;
                                                border-radius:0 0 4px 4px;z-index:9999;box-shadow:0 4px 12px rgba(0,0,0,.12)"></div>
                                </div>
                                <div id="ta_user_selected"
                                     style="margin-top:8px;display:none;background:#eaf7ee;border:1px solid #b2dfdb;
                                            border-radius:4px;padding:7px 12px;font-size:13px;max-width:420px">
                                    <strong id="ta_user_selected_name"></strong>
                                    <span id="ta_user_selected_meta" style="color:#555;margin-right:8px;font-size:0.85rem"></span>
                                    <button type="button" onclick="taClearUserSelection()"
                                            style="float:left;background:none;border:none;color:#c00;cursor:pointer;font-size:16px;padding:0;line-height:1">✕</button>
                                </div>
                                <p style="margin:4px 0 0;color:#888;font-size:0.82rem">جستجو بر اساس نام، شماره همراه (kerasno-phone) یا ایمیل</p>
                            </td>
                        </tr>
                        <tr>
                            <th>رتبه <small>(کمتر = اول)</small></th>
                            <td><input type="number" name="ta_rank" id="ta_edit_rank" value="0" min="0" class="small-text"></td>
                        </tr>
                        <tr>
                           
                        </tr>
                       
                    </table>
                    <?php submit_button( 'ذخیره استادیار', 'primary', 'submit', false ); ?>
                    <button type="button" class="button" onclick="taResetForm()">پاک‌کردن</button>
                </form>
            </div>

            <h2>لیست استادیارها (<?= count( $assistants ) ?>)</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th width="50">رتبه</th>
                        <th>نام</th>
                        <th>ایمیل</th>
                        
                       
                        <th width="80">ظرفیت</th>
                        <th width="70">وضعیت</th>
                        <th width="170">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ( empty( $assistants ) ) : ?>
                    <tr><td colspan="8" style="text-align:center;padding:20px;color:#999">هنوز استادیاری ثبت نشده</td></tr>
                <?php endif; ?>
                <?php foreach ( $assistants as $ta ) :
                    $messengers = json_decode( $ta->messengers, true ) ?: [];
                ?>
                    <tr style="<?= ! $ta->is_active ? 'opacity:0.5' : '' ?>">
                        <td><?= $ta->rank ?></td>
                        <td><strong><?= esc_html( $ta->display_name ) ?></strong></td>
                        <td><?= esc_html( $ta->user_email ) ?></td>
                      
                        
                        <td>
                            <a href="<?= esc_url( admin_url( 'admin.php?page=ta-assistants&view_caps=' . $ta->id ) ) ?>">
                                <?= $this->get_cap_summary( $ta->id ) ?>
                            </a>
                        </td>
                        <td><?= $ta->is_active ? '<span style="color:green">●&nbsp;فعال</span>' : '<span style="color:#bbb">●&nbsp;غیرفعال</span>' ?></td>
                        <td>
                            <?php
                            $phone_val = esc_js( get_user_meta( $ta->user_id, 'kerasno-phone', true ) ?: '' );
                            ?>
                            <button type="button" class="button button-small"
                                onclick='taEditTA(
                                  <?= (int) $ta->user_id ?>,
                                 "<?= esc_js( $ta->display_name ) ?>",
                                 "<?= esc_js( $ta->user_email ) ?>",
                                 "<?= esc_js( $phone_val ) ?>",
                                  <?= (int) $ta->rank ?>
                                   )'>
                                   
                                ✏️ ویرایش
                            </button>

                            <form method="post" action="<?= admin_url( 'admin-post.php' ) ?>" style="display:inline">
                                <?php wp_nonce_field( 'ta_toggle_assistant' ); ?>
                                <input type="hidden" name="action"    value="ta_toggle_assistant">
                                <input type="hidden" name="ta_id"     value="<?= $ta->id ?>">
                                <input type="hidden" name="is_active" value="<?= $ta->is_active ?>">
                                <button class="button button-small" title="<?= $ta->is_active ? 'غیرفعال' : 'فعال' ?>">
                                    <?= $ta->is_active ? '⏸' : '▶️' ?>
                                </button>
                            </form>

                            <form method="post" action="<?= admin_url( 'admin-post.php' ) ?>" style="display:inline"
                                  onsubmit="return confirm('آیا مطمئنید؟\nظرفیت‌های استفاده‌نشده هم حذف می‌شوند.')">
                                <?php wp_nonce_field( 'ta_delete_assistant' ); ?>
                                <input type="hidden" name="action" value="ta_delete_assistant">
                                <input type="hidden" name="ta_id"  value="<?= $ta->id ?>">
                                <button class="button button-small button-link-delete">🗑️ حذف</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <script>
        var taNonce   = '<?= wp_create_nonce('ta_admin_nonce') ?>';
        var taAjax    = '<?= admin_url('admin-ajax.php') ?>';
        var taSearchT = null;

        // ── Live search ─────────────────────────────────────────
        document.getElementById('ta_user_search_input').addEventListener('input', function () {
            clearTimeout(taSearchT);
            var q = this.value.trim();
            var box = document.getElementById('ta_user_search_results');
            if (q.length < 2) { box.style.display = 'none'; return; }
            taSearchT = setTimeout(function () {
                fetch(taAjax, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=ta_search_users&nonce=' + taNonce + '&q=' + encodeURIComponent(q)
                }).then(r => r.json()).then(function (res) {
                    box.innerHTML = '';
                    if (!res.success || !res.data.length) {
                        box.innerHTML = '<div style="padding:9px 12px;color:#888;font-size:0.85rem">نتیجه‌ای یافت نشد.</div>';
                        box.style.display = 'block'; return;
                    }
                    res.data.forEach(function (u) {
                        var row = document.createElement('div');
                        row.style.cssText = 'padding:9px 14px;cursor:pointer;font-size:0.88rem;border-bottom:1px solid #f0f0f0;line-height:1.4';
                        row.innerHTML = '<strong>' + u.name + '</strong>'
                            + (u.phone ? ' <span style="color:#0073aa;font-size:0.82rem">📱 ' + u.phone + '</span>' : '')
                            + '<br><span style="color:#888;font-size:0.8rem">' + u.email + '</span>';
                        row.addEventListener('mouseover', function(){this.style.background='#f0f6fb'});
                        row.addEventListener('mouseout',  function(){this.style.background=''});
                        row.addEventListener('click', function () {
                            taSelectUser(u.id, u.name, u.phone, u.email);
                            box.style.display = 'none';
                        });
                        box.appendChild(row);
                    });
                    box.style.display = 'block';
                });
            }, 300);
        });

        // بستن dropdown با کلیک خارج
        document.addEventListener('click', function (e) {
            var box = document.getElementById('ta_user_search_results');
            if (!document.getElementById('ta_user_search_input').contains(e.target)) {
                box.style.display = 'none';
            }
        });

        function taSelectUser(id, name, phone, email) {
            document.getElementById('ta_edit_user_id').value    = id;
            document.getElementById('ta_user_search_input').value = name;
            document.getElementById('ta_user_selected_name').textContent = name;
            document.getElementById('ta_user_selected_meta').textContent =
                (phone ? '📱 ' + phone + '  ' : '') + '✉️ ' + email;
            document.getElementById('ta_user_selected').style.display = 'block';
        }

        function taClearUserSelection() {
            document.getElementById('ta_edit_user_id').value     = '';
            document.getElementById('ta_user_search_input').value = '';
            document.getElementById('ta_user_selected').style.display = 'none';
            document.getElementById('ta_user_search_input').focus();
        }

        // ── ویرایش استادیار موجود ───────────────────────────────
        function taEditTA(userId, userName, userEmail, userPhone, rank) {
            taSelectUser(userId, userName, userPhone || '', userEmail);
            document.getElementById('ta_edit_rank').value   = rank;
           
            window.scrollTo({top: 0, behavior: 'smooth'});
        }

        function taResetForm() {
            taClearUserSelection();
            document.getElementById('ta_edit_rank').value   = 0;
           
           
           
        }
        </script>
        <?php
    }

    // ── نمایش ظرفیت‌های استادیار ─────────────────────────────────────────────
    private function render_capacity_view( int $ta_id ): void {
        global $wpdb;

        $ta_table  = TA_Database::table( 'assistants' );
        $cap_table = TA_Database::table( 'capacities' );
        $gr_table  = TA_Database::table( 'groups' );

        $ta = $wpdb->get_row( $wpdb->prepare(
            "SELECT ta.*, u.display_name FROM {$ta_table} ta
             JOIN {$wpdb->users} u ON u.ID = ta.user_id WHERE ta.id = %d",
            [ $ta_id ]
        ) );

        if ( ! $ta ) {
            echo '<div class="wrap"><p>استادیار یافت نشد.</p><a href="' . admin_url( 'admin.php?page=ta-assistants' ) . '" class="button">← بازگشت</a></div>';
            return;
        }

        $caps = $wpdb->get_results( $wpdb->prepare(
            "SELECT c.*, t.name AS term_name
             FROM {$cap_table} c
             LEFT JOIN " . TA_Database::table( 'terms' ) . " t ON t.id = c.term_id
             WHERE c.ta_id = %d
             ORDER BY t.order_index DESC, c.course_type, c.student_gender",
            [ $ta_id ]
        ) ) ?: [];

        $course_labels = [
            'creative'     => 'نویسندگی خلاق',
            'intro'        => 'نویسندگی مقدماتی',
            'advanced'     => 'نویسندگی پیشرفته',
            'level_assess' => 'تعیین سطح',
        ];
       // $gender_labels = [ 'male' => 'آقایان', 'female' => 'خانم‌ها', 'both' => 'هر دو' ];
        $m_labels      = [ 'telegram' => '✈️ تلگرام', 'bale' => '🔵 بله', 'eitaa' => '🟢 ایتا' ];
        ?>
        <div class="wrap" dir="rtl">
            <h1>ظرفیت‌های <?= esc_html( $ta->display_name ) ?></h1>
            <a href="<?= admin_url( 'admin.php?page=ta-assistants' ) ?>" class="button">← بازگشت به لیست</a>
            <hr style="margin:16px 0">

            <?php if ( empty( $caps ) ) : ?>
                <div class="notice notice-warning">
                    <p>هیچ ظرفیتی ثبت نشده. استادیار باید از <strong>داشبورد فرانت‌اند</strong> (<code>[ta_dashboard]</code>) ظرفیت‌های خود را تعریف کند.</p>
                </div>
            <?php else : ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ترم</th>
                        <th>نوع دوره</th>
                        <th>جنسیت هنرجو</th>
                        <th width="80">کل</th>
                        <th width="80">استفاده‌شده</th>
                        <th width="80">باقی‌مانده</th>
                        <th>گروه‌ها (فقط خلاق)</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ( $caps as $cap ) :
                    $groups = [];
                    if ( $cap->course_type === 'creative' ) {
                        $groups = $wpdb->get_results( $wpdb->prepare(
                            "SELECT g.*, u.display_name AS student_name
                             FROM {$gr_table} g
                             LEFT JOIN {$wpdb->users} u ON u.ID = g.assigned_to_user_id
                             WHERE g.capacity_id = %d ORDER BY g.is_used DESC, g.id ASC",
                            [ $cap->id ]
                        ) ) ?: [];
                    }
                    $remaining  = (int) $cap->total_capacity - (int) $cap->used_capacity;
                    $row_color  = match ( $cap->student_gender ) {
                        'female' => '#fce4ec',
                        'male'   => '#e3f2fd',
                        default  => '#f3e5f5',
                    };
                ?>
                    <tr>
                        <td><?= esc_html( $cap->term_name ?? '—' ) ?></td>
                        <td><?= $course_labels[ $cap->course_type ] ?? $cap->course_type ?></td>
                        <td>
                            <span style="background:<?= $row_color ?>;padding:2px 10px;border-radius:12px;font-size:12px">
                                <?= $gender_labels[ $cap->student_gender ] ?? $cap->student_gender ?>
                            </span>
                        </td>
                        <td><?= (int) $cap->total_capacity ?></td>
                        <td><?= (int) $cap->used_capacity ?></td>
                        <td><strong style="color:<?= $remaining > 0 ? 'green' : '#c00' ?>"><?= $remaining ?></strong></td>
                        <td>
                            <?php if ( $cap->course_type !== 'creative' ) : ?>
                                <em style="color:#999">—</em>
                            <?php elseif ( empty( $groups ) ) : ?>
                                <em style="color:#999">بدون گروه</em>
                            <?php else : ?>
                                <details>
                                    <summary style="cursor:pointer"><?= count( $groups ) ?> گروه</summary>
                                    <ul style="margin:6px 0;padding-right:16px;font-size:13px">
                                    <?php foreach ( $groups as $g ) : ?>
                                        <li style="margin-bottom:4px">
                                            <?= $m_labels[ $g->messenger_type ] ?? $g->messenger_type ?>
                                            — <a href="<?= esc_url( $g->group_link ) ?>" target="_blank">مشاهده گروه</a>
                                            — <?php if ( $g->is_used ) : ?>
                                                <span style="color:#c00">اختصاص‌یافته</span>
                                                <?= $g->student_name ? ' به ' . esc_html( $g->student_name ) : '' ?>
                                              <?php else : ?>
                                                <span style="color:green">آزاد</span>
                                              <?php endif; ?>
                                        </li>
                                    <?php endforeach; ?>
                                    </ul>
                                </details>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <?php
    }

    private function get_cap_summary( int $ta_id ): string {
        $table = TA_Database::table( 'capacities' );
        $row   = TA_Database::get_row(
            "SELECT SUM(total_capacity) AS total, SUM(used_capacity) AS used FROM {$table} WHERE ta_id = %d",
            [ $ta_id ]
        );
        if ( ! $row || ! $row->total ) return '0 ظرفیت';
        return (int) $row->used . '/' . (int) $row->total;
    }
}
