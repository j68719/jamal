<?php

/**
 * مدیریت تخصیص‌ها بر اساس سفارشات مشتریان (فقط محصولات دارای ترم)
 */
class TA_Admin_Customers {

    public static function render() {
        global $wpdb;

        if (!class_exists('WooCommerce')) {
            echo '<div class="notice notice-error"><p>افزونه ووکامرس فعال نیست.</p></div>';
            return;
        }
        if (!TA_Database::tables_exist()) {
            echo '<div class="notice notice-error"><p>جداول مورد نیاز وجود ندارند. لطفا ابتدا دیتابیس را نصب کنید.</p></div>';
            return;
        }

        wp_enqueue_script('ta-admin-assignments');
        wp_enqueue_style('ta-admin-style');

        // دریافت مقادیر فیلترها از URL
        $search          = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        $f_product_id    = isset($_GET['f_product_id']) ? intval($_GET['f_product_id']) : 0;
        $f_product_name  = isset($_GET['f_product_name']) ? sanitize_text_field($_GET['f_product_name']) : ''; 
        $f_assign_status = isset($_GET['f_assign_status']) ? sanitize_text_field($_GET['f_assign_status']) : '';
        $f_order_status  = isset($_GET['f_order_status']) ? sanitize_text_field($_GET['f_order_status']) : ''; 
        $f_term_id       = isset($_GET['f_term_id']) ? intval($_GET['f_term_id']) : 0; 
        $f_ta_id         = isset($_GET['f_ta_id']) ? intval($_GET['f_ta_id']) : 0; 
        $paged           = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;

        $per_page = 20000;

        $assign_table = TA_Database::table('assignments');
        $ta_table     = TA_Database::table('assistants');
        $terms_table  = TA_Database::table('terms');
        $product_set_table = TA_Database::table('product_settings');

        $allowed_wc_statuses = "('wc-processing', 'wc-completed', 'wc-partial-payment', 'wc-pending-deposit', 'wc-scheduled-payment')";

        $where_conditions = array("p.post_type = 'shop_order'");
        
        if (!empty($f_order_status)) {
            $where_conditions[] = "p.post_status = %s";
            $where_params[] = $f_order_status;
        } else {
            $where_conditions[] = "p.post_status IN {$allowed_wc_statuses}";
        }
        
        $where_conditions[] = "oi.order_item_type = 'line_item'";
        if (!isset($where_params)) {
            $where_params = array();
        }

        $where_conditions[] = "oim.meta_key IN ('_product_id', '_variation_id')";
        $where_conditions[] = "oim.meta_value != ''";
        $where_conditions[] = "oim.meta_value != '0'";

        if ($f_product_id > 0) {
            $where_conditions[] = "oim.meta_value = %d";
            $where_params[] = $f_product_id;
        }

        if (!empty($f_product_name)) {
            $where_conditions[] = "prod.post_title LIKE %s";
            $where_params[] = '%' . $wpdb->esc_like($f_product_name) . '%';
        }

        if ($f_term_id > 0) {
            $where_conditions[] = "t.id = %d";
            $where_params[] = $f_term_id;
        }

        if ($f_ta_id > 0) {
            $where_conditions[] = "ta.id = %d";
            $where_params[] = $f_ta_id;
        }

        if (!empty($search)) {
            $search_like = '%' . $wpdb->esc_like($search) . '%';
            $user_ids = $wpdb->get_col($wpdb->prepare(
    "SELECT ID FROM {$wpdb->users} WHERE display_name LIKE %s OR user_email LIKE %s
     UNION 
     SELECT DISTINCT user_id FROM {$wpdb->usermeta} 
     WHERE meta_key IN ('kerasno-phone','phone','Mreeir_phone','billing_phone') 
     AND meta_value LIKE %s",
    $search_like, $search_like, $search_like
));

            $search_conditions = array("p.ID = %d");
            $search_params = array(intval($search));

            if (!empty($user_ids)) {
                $placeholders = array_fill(0, count($user_ids), '%d');
                $search_conditions[] = "pm_user.meta_value IN (" . implode(',', $placeholders) . ")";
                $search_params = array_merge($search_params, $user_ids);
            }

            $where_conditions[] = "(" . implode(' OR ', $search_conditions) . ")";
            $where_params = array_merge($where_params, $search_params);
        }

        if ($f_assign_status === 'assigned') {
            $where_conditions[] = "a.id IS NOT NULL";
        } elseif ($f_assign_status === 'unassigned') {
            $where_conditions[] = "a.id IS NULL";
        }

        $where_sql = implode(' AND ', $where_conditions);
        
        $joins = "
            FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->prefix}woocommerce_order_items oi ON p.ID = oi.order_id
            INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim ON oi.order_item_id = oim.order_item_id AND oim.meta_key = '_product_id'
            LEFT JOIN {$wpdb->posts} prod ON prod.ID = oim.meta_value 
            LEFT JOIN {$wpdb->postmeta} pm_user ON p.ID = pm_user.post_id AND pm_user.meta_key = '_customer_user'
            LEFT JOIN {$wpdb->users} u ON u.ID = pm_user.meta_value
            INNER JOIN {$product_set_table} ps ON ps.product_id = oim.meta_value
            INNER JOIN {$terms_table} t ON t.id = ps.term_id
            LEFT JOIN {$assign_table} a ON a.student_id = pm_user.meta_value AND a.product_id = ps.product_id
            LEFT JOIN {$ta_table} ta ON ta.id = a.ta_id
            LEFT JOIN {$wpdb->users} tu ON tu.ID = ta.user_id
        ";

        $count_query = "SELECT COUNT(DISTINCT p.ID) {$joins} WHERE {$where_sql}";
        if (!empty($where_params)) {
            $count_query = $wpdb->prepare($count_query, $where_params);
        }
        $total_items = $wpdb->get_var($count_query);
        $total_pages = ceil($total_items / $per_page);
        $offset = ($paged - 1) * $per_page;

        $select_query = "
            SELECT 
                p.ID as order_id,
                p.post_status as order_status,
                p.post_date as order_date,
                pm_user.meta_value as student_id,
                u.display_name as student_name,
                u.user_email as student_email,
                oim.meta_value as product_id,
                prod.post_title as product_title,
                a.id as assignment_id,
                a.status as assignment_status,
                a.messenger,
                a.group_link,
                tu.display_name as ta_name,
                t.name as term_name
            {$joins} 
            WHERE {$where_sql}
            GROUP BY p.ID
            ORDER BY p.post_date DESC
            LIMIT %d OFFSET %d
        ";

        $query_params = array_merge($where_params, [$per_page, $offset]);
        $rows = $wpdb->get_results($wpdb->prepare($select_query, $query_params));

        // =========================================================
        // اینجا محل درست برای ساخت متغیر است (قبل از استفاده در HTML)
        // =========================================================
        $grouped_rows = [];
        if (!empty($rows)) {
            foreach ($rows as $row) {
                $student_id = $row->student_id;
                $product_id = $row->product_id;
                $group_key = $student_id ? "{$student_id}_{$product_id}" : "guest_{$row->order_id}_{$product_id}";

                if (!isset($grouped_rows[$group_key])) {
                    $grouped_rows[$group_key] = $row;
                    $grouped_rows[$group_key]->all_order_ids = [$row->order_id];
                    $grouped_rows[$group_key]->all_order_statuses = [$row->order_status];
                    $grouped_rows[$group_key]->all_order_dates = [$row->order_date];
                } else {
                    if (!in_array($row->order_id, $grouped_rows[$group_key]->all_order_ids)) {
                        $grouped_rows[$group_key]->all_order_ids[] = $row->order_id;
                        $grouped_rows[$group_key]->all_order_statuses[] = $row->order_status;
                        $grouped_rows[$group_key]->all_order_dates[] = $row->order_date;
                    }
                }
            }
        }

        $all_terms = $wpdb->get_results("SELECT id, name FROM {$terms_table} ORDER BY name ASC");
        $all_tas = $wpdb->get_results("SELECT ta.id, u.display_name FROM {$ta_table} ta INNER JOIN {$wpdb->users} u ON ta.user_id = u.ID ORDER BY u.display_name ASC");

        if (isset($_GET['debug_ta']) && $_GET['debug_ta'] == '1') {
            echo '<div style="direction:ltr; text-align:left; background:#fff; padding:15px; border:2px solid red; margin:10px 0;">';
            echo '<h3 style="color:red; margin-top:0;">حالت دیباگ روشن است</h3>';
            echo '<strong>آخرین خطای دیتابیس (اگر خالی است یعنی ارور سینتکس نداریم):</strong><br><span style="color:darkred;">' . $wpdb->last_error . '</span><br><br>';
            echo '<strong>کوئری تولید شده:</strong><br><textarea style="width:100%; height:150px; font-family:monospace;">' . esc_textarea($wpdb->last_query) . '</textarea>';
            echo '</div>';
        }

        $wc_status_labels = array(
            'wc-processing'      => '<span class="wc-badge wc-processing">در حال انجام</span>',
            'wc-completed'       => '<span class="wc-badge wc-completed">تکمیل شده</span>',
            'wc-partial-payment' => '<span class="wc-badge wc-partial">پرداخت قسطی</span>',
            'wc-pending-deposit' => '<span class="wc-badge wc-pending-deposit">در انتظار پرداخت قسطی</span>',
            'wc-scheduled-payment' => '<span class="wc-scheduled-payment">زمانبندی شده</span>',
        );
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">بررسی سفارشات (فقط محصولات دارای ترم)</h1>
            <a href="?page=<?php echo esc_attr($_GET['page']); ?>&debug_ta=1" class="page-title-action" style="background:red; color:white; border-color:darkred;">روشن کردن حالت دیباگ</a>
            <hr class="wp-header-end">

            <form method="get" action="" class="ta-filter-form" style="margin-bottom: 20px; background: #fff; padding: 15px; border: 1px solid #ccd0d4; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
                <input type="hidden" name="page" value="<?php echo esc_attr($_GET['page']); ?>">
                <div style="display: flex; flex-wrap: wrap; gap: 15px; align-items: flex-end;">
                    <div><label style="display:block; margin-bottom:5px;">جستجو:</label><input type="text" name="s" value="<?php echo esc_attr($search); ?>" class="regular-text" placeholder="نام، ایمیل یا موبایل"></div>
                    <div><label style="display:block; margin-bottom:5px;">نام محصول/دوره:</label><input type="text" name="f_product_name" value="<?php echo esc_attr($f_product_name); ?>" class="regular-text"></div>
                    <div><label style="display:block; margin-bottom:5px;">شناسه محصول:</label><input type="number" name="f_product_id" value="<?php echo $f_product_id ? esc_attr($f_product_id) : ''; ?>" style="width: 100px;"></div>
                    
                    <div>
                        <label style="display:block; margin-bottom:5px;">وضعیت سفارش:</label>
                        <select name="f_order_status">
                            <option value="">پیش‌فرض مجاز</option>
                            <option value="wc-processing" <?php selected($f_order_status, 'wc-processing'); ?>>در حال انجام</option>
                            <option value="wc-completed" <?php selected($f_order_status, 'wc-completed'); ?>>تکمیل شده</option>
                            <option value="wc-partial-payment" <?php selected($f_order_status, 'wc-partial-payment'); ?>>پرداخت قسطی</option>
                            <option value="wc-on-hold" <?php selected($f_order_status, 'wc-on-hold'); ?>>در انتظار بررسی</option>
                            <option value="wc-pending" <?php selected($f_order_status, 'wc-pending'); ?>>در انتظار پرداخت</option>
                            <option value="wc-pending-deposit" <?php selected($f_order_status, 'wc-pending-deposit'); ?>>در انتظار پرداخت قسطی</option>
                            <option value="wc-scheduled-payment" <?php selected($f_order_status, 'wc-scheduled-payment'); ?>>زمانبندی شده</option>
                        </select>
                    </div>

                    <div>
                        <label style="display:block; margin-bottom:5px;">ترم مربوطه:</label>
                        <select name="f_term_id">
                            <option value="0">همه ترم‌ها</option>
                            <?php foreach ($all_terms as $t): ?>
                                <option value="<?php echo $t->id; ?>" <?php selected($f_term_id, $t->id); ?>><?php echo esc_html($t->name); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label style="display:block; margin-bottom:5px;">استادیار:</label>
                        <select name="f_ta_id">
                            <option value="0">همه استادیارها</option>
                            <?php foreach ($all_tas as $ta): ?>
                                <option value="<?php echo $ta->id; ?>" <?php selected($f_ta_id, $ta->id); ?>><?php echo esc_html($ta->display_name); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label style="display:block; margin-bottom:5px;">وضعیت تخصیص:</label>
                        <select name="f_assign_status">
                            <option value="">همه</option>
                            <option value="assigned" <?php selected($f_assign_status, 'assigned'); ?>>تخصیص داده شده</option>
                            <option value="unassigned" <?php selected($f_assign_status, 'unassigned'); ?>>بدون استادیار</option>
                        </select>
                    </div>

                    <div>
                        <button type="submit" class="button button-primary">اعمال فیلتر</button>
                        <a href="?page=<?php echo esc_attr($_GET['page']); ?>" class="button">پاک‌کردن</a>
                    </div>
                </div>
            </form>

            <?php
            $page_links = paginate_links( array(
                'base'      => add_query_arg( 'paged', '%#%' ),
                'format'    => '',
                'prev_text' => '&laquo; قبلی',
                'next_text' => 'بعدی &raquo;',
                'total'     => $total_pages,
                'current'   => $paged,
                'type'      => 'plain'
            ) );
            ?>
            
            <div class="tablenav top">
                <div class="tablenav-pages">
                    <span class="displaying-num">
                        <?php echo number_format_i18n(count($grouped_rows)); ?> تخصیص در این صفحه
                    </span>                    
                    <?php if ( $page_links ) : ?>
                        <span class="pagination-links"><?php echo $page_links; ?></span>
                    <?php endif; ?>
                </div>
            </div>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th scope="col" width="80">سفارش</th>
                        <th scope="col" width="120">وضعیت سفارش</th>
                        <th scope="col">نام محصول/دوره</th>
                        <th scope="col">هنرجو / خریدار</th>
                        <th scope="col" width="120">موبایل</th>
                        <th scope="col" width="120">وضعیت تخصیص</th>
                        <th scope="col">استادیار</th>
                        <th scope="col" width="100">ترم مربوطه</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($grouped_rows)): ?>
                        <tr><td colspan="8" class="text-center" style="padding: 20px;">هیچ سفارش مرتبط با ترم یافت نشد.</td></tr>
                    <?php else: ?>
                        <?php foreach ($grouped_rows as $row):
                            if ( $row->student_id ) {
    $phone = class_exists('TA_User_Helper')
        ? TA_User_Helper::get_phone( $row->student_id )
        : (
            get_user_meta($row->student_id, 'kerasno-phone',  true) ?:
            get_user_meta($row->student_id, 'phone',          true) ?:
            get_user_meta($row->student_id, 'Mreeir_phone',   true) ?:
            get_user_meta($row->student_id, 'billing_phone',  true) ?:
            '—'
        );
} else {
    $phone = '—';
}
                            $product_name = $row->product_title ? $row->product_title : get_the_title($row->product_id);

                            if ($row->assignment_id) {
                                $assign_badge = ($row->assignment_status == 'active')
                                    ? '<span class="status-active">● فعال</span>'
                                    : '<span class="status-completed">تکمیل</span>';
                            } else {
                                $assign_badge = '<span style="color:#d63638; font-weight:bold;">نیازمند تخصیص</span>';
                            }
                        ?>
                            <tr>
                                <td>
                                    <?php foreach ($row->all_order_ids as $index => $oid): ?>
                                        <strong><a href="<?php echo get_edit_post_link($oid); ?>" target="_blank">#<?php echo $oid; ?></a></strong>
                                        <br><small dir="ltr"><?php echo date_i18n('Y/m/d', strtotime($row->all_order_dates[$index])); ?></small><br>
                                    <?php endforeach; ?>
                                </td>
                                
                                <td>
                                    <?php foreach ($row->all_order_statuses as $status): ?>
                                        <div style="margin-bottom:5px;"><?php echo isset($wc_status_labels[$status]) ? $wc_status_labels[$status] : $status; ?></div>
                                    <?php endforeach; ?>
                                </td>
                                
                                <td><a href="<?php echo get_edit_post_link($row->product_id); ?>" target="_blank"><?php echo esc_html($product_name); ?></a><br><small>ID: <?php echo $row->product_id; ?></small></td>
                                <td>
                                    <?php if($row->student_id): ?>
                                        <strong><a href="<?php echo get_edit_user_link($row->student_id); ?>" target="_blank"><?php echo esc_html($row->student_name); ?></a></strong><br>
                                        <small><?php echo esc_html($row->student_email); ?></small>
                                    <?php else: ?>
                                        <span style="color:gray;">مهمان</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html($phone); ?></td>
                                <td><?php echo $assign_badge; ?></td>
                                <td><?php echo $row->ta_name ? esc_html($row->ta_name) : '—'; ?></td>
                                <td><?php echo $row->term_name ? esc_html($row->term_name) : '—'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="tablenav bottom">
            <div class="tablenav-pages">
                <span class="displaying-num">
                    <?php echo number_format_i18n(count($grouped_rows)); ?> تخصیص در این صفحه
                </span>                   
                <?php if ( $page_links ) : ?>
                    <span class="pagination-links"><?php echo $page_links; ?></span>
                <?php endif; ?>
            </div>
        </div>

        <style>
        .wc-badge { display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        .wc-processing { background: #c6e1c6; color: #5b841b; }
        .wc-completed { background: #c8d7e1; color: #2e4453; }
        .wc-partial { background: #ffdfa0; color: #8a641c; }
        .wc-pending-deposit { background: #ffdf00; color: #8a641c; }
        .wc-scheduled-payment { background: #ffdf0a; color: #8a641c; }
        
        .status-active { color: #46b450; font-weight: bold; }
        .status-completed { color: #f56e28; font-weight: bold; }
        .text-center { text-align: center; }
        .tablenav .tablenav-pages {
            float: left; 
            margin: 5px 0;
        }
        .tablenav .displaying-num {
            margin-left: 15px;
            font-size: 13px;
            color: #50575e;
            font-weight: 500;
        }
        .pagination-links .page-numbers {
            display: inline-block;
            min-width: 15px;
            padding: 4px 10px;
            margin: 0 2px;
            font-size: 13px;
            color: #2271b1;
            background: #fff;
            border: 1px solid #c3c4c7;
            border-radius: 4px;
            text-align: center;
            text-decoration: none;
            transition: all 0.2s ease-in-out;
            box-shadow: 0 1px 1px rgba(0,0,0,0.04);
        }
        .pagination-links .page-numbers:hover {
            background: #f0f0f1;
            border-color: #8c8f94;
            color: #135e96;
        }
        .pagination-links .page-numbers.current {
            background: #2271b1;
            color: #fff;
            border-color: #2271b1;
            font-weight: bold;
            box-shadow: none;
        }
        .pagination-links .page-numbers.dots {
            border: none;
            background: transparent;
            box-shadow: none;
            color: #50575e;
            pointer-events: none;
        }
        </style>
        <?php
    }
}
