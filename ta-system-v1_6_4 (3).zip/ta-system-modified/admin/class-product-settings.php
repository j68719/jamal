<?php
defined( 'ABSPATH' ) || exit;

class TA_Product_Settings {

    public function __construct() {
        add_action( 'woocommerce_product_data_tabs',   [ $this, 'add_tab' ] );
        add_action( 'woocommerce_product_data_panels', [ $this, 'render_panel' ] );
        add_action( 'woocommerce_process_product_meta', [ $this, 'save' ] );
        add_action( 'admin_head', [ $this, 'inline_styles' ] );
    }

    public function inline_styles(): void {
        if ( ! get_current_screen() || get_current_screen()->id !== 'product' ) return;
        echo '<style>
            #ta_prereq_row select[multiple] { height: 160px; width: 100%; }
            #ta_prereq_row .ta-prereq-help { color: #666; font-style: italic; font-size: 12px; margin-top: 5px; display: block; }
        </style>';
    }

    public function add_tab( array $tabs ): array {
        $tabs['ta_settings'] = [
            'label'    => 'تنظیمات استادیار',
            'target'   => 'ta_settings_panel',
            'class'    => [],
            'priority' => 80,
        ];
        return $tabs;
    }

    public function render_panel(): void {
        global $post;

        $terms    = TA_Database::get_results(
            "SELECT * FROM " . TA_Database::table( 'terms' ) . " ORDER BY order_index ASC"
        );
        $settings  = TA_Product_Meta::get_settings( $post->ID );
        $prereq_ids = TA_Product_Meta::get_prerequisites( $post->ID );

        // همه محصولات به‌جز خود محصول
        if ( ! function_exists( 'wc_get_products' ) ) { return; }
        $products = wc_get_products( [
            'limit'   => -1,
            'status'  => 'publish',
            'exclude' => [ $post->ID ],
            'orderby' => 'title',
            'order'   => 'ASC',
        ] );
        
        // این خط را بعد از دریافت $products در متد render_panel اضافه کنید

     //   $tas = get_users( ['role' => 'teaching_assistant', 'orderby' => 'display_name'] );
       global $wpdb;
$ta_table = TA_Database::table( 'assistants' );

// دریافت استادیاران فعال و مرتب‌سازی بر اساس رتبه با اتصال به جدول کاربران وردپرس
$tas = $wpdb->get_results( "
    SELECT u.ID, u.display_name 
    FROM {$ta_table} ta
    JOIN {$wpdb->users} u ON ta.user_id = u.ID
    WHERE ta.is_active = 1 
    ORDER BY ta.rank DESC
" );



        $selected_critique_ta = get_post_meta( $post->ID, '_ta_critique_ta_id', true );
$selected_professional_ta = get_post_meta( $post->ID, '_ta_professional_ta_id', true );


        $selected_term = $settings ? (int) $settings->term_id : 0;
        $selected_type = $settings ? $settings->course_type : '';
        ?>
        <div id="ta_settings_panel" class="panel woocommerce_options_panel" style="direction:rtl">
            <div class="options_group">

                <p class="form-field">
                    <label for="ta_term_id">ترم:</label>
                    <select name="ta_term_id" id="ta_term_id" style="width:60%">
                        <option value="">— انتخاب کنید —</option>
                        <?php foreach ( $terms as $term ) : ?>
                            <option value="<?= $term->id ?>" <?= selected( $selected_term, $term->id, false ) ?>>
                                <?= esc_html( $term->name ) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </p>

                <p class="form-field">
                    <label for="ta_course_type_select">نوع دوره:</label>
                    <select name="ta_course_type" id="ta_course_type_select" style="width:60%">
                        <option value="">— انتخاب کنید —</option>
                        <option value="creative"     <?= selected( $selected_type, 'creative',     false ) ?>>نویسندگی خلاق</option>
                        <option value="intro"        <?= selected( $selected_type, 'intro',        false ) ?>>نویسندگی مقدماتی</option>
                        <option value="critique"     <?= selected( $selected_type, 'critique',     false ) ?>>نقد اثر</option>
                        <option value="advanced"     <?= selected( $selected_type, 'advanced',     false ) ?>>نویسندگی پیشرفته</option>
                        <option value="professional" <?= selected( $selected_type, 'professional', false ) ?>>نویسندگی حرفه‌ای</option>
                    </select>
                </p>

                <p class="form-field" id="ta_prereq_row" style="<?= ($selected_type === 'creative' || $selected_type === 'critique' || $selected_type === '') ? 'display:none' : '' ?>">
                    <label for="ta_prerequisite_product_ids">محصولات پیش‌نیاز:</label>
                    <select name="ta_prerequisite_product_ids[]"
                            id="ta_prerequisite_product_ids"
                            multiple
                            style="width:60%">
                        <?php foreach ( $products as $product ) :
                            $pid = $product->get_id();
                        ?>
                            <option value="<?= $pid ?>"
                                <?= in_array( $pid, $prereq_ids, true ) ? 'selected' : '' ?>>
                                <?= esc_html( $product->get_name() ) ?> (ID: <?= $pid ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <span class="ta-prereq-help">
                        💡 چند محصول را با Ctrl+کلیک انتخاب کنید. گذراندن هر یک از آن‌ها برای ورود به این دوره کافی است.
                    </span>
                </p>

                <p class="form-field" id="ta_pro_group_row" style="<?= ($selected_type === 'professional' || $selected_type === 'critique') ? '' : 'display:none' ?>">
                    <label for="ta_pro_group_link">لینک گروه ثابت دوره  نقد اثر یا حرفه‌ای:</label>
                    <input type="url" name="ta_pro_group_link" id="ta_pro_group_link" style="width:60%" value="<?= esc_attr( $settings->pro_group_link ?? '' ) ?>" placeholder="https://...">
                    <span class="ta-prereq-help">لینک گروهی که هنرجویان واجد شرایط پس از خرید می‌بینند.</span>
                </p>
                            <!-- انتخاب استادیار برای دوره نقد اثر -->
            <p class="form-field" id="ta_critique_ta_row"  style="<?= ($selected_type === 'critique') ? '' : 'display:none' ?>">
                <label for="ta_critique_ta_id">استادیار نقد اثر:</label>
                <select name="ta_critique_ta_id" id="ta_critique_ta_id" style="width:60%">
                    <option value="">— انتخاب استادیار —</option>
                    <?php foreach ( $tas as $ta ) : ?>
                        <option value="<?= esc_attr( $ta->ID ) ?>" <?= selected( $selected_critique_ta, $ta->ID, false ) ?>>
                            <?= esc_html( $ta->display_name ) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <span class="ta-prereq-help">این استادیار مستقیماً و بدون در نظر گرفتن ظرفیت به خریداران این محصول اختصاص می‌یابد.</span>
            </p>
<p class="form-field" id="ta_professional_ta_row" style="<?= ($selected_type === 'professional') ? '' : 'display:none' ?>">
    <label for="ta_professional_ta_id">استادیار دوره حرفه‌ای:</label>
    <select name="ta_professional_ta_id" id="ta_professional_ta_id" style="width:60%">
        <option value="">— انتخاب استادیار —</option>
        <?php foreach ( $tas as $ta ) : ?>
            <option value="<?= esc_attr( $ta->ID ) ?>" <?= selected( $selected_professional_ta, $ta->ID, false ) ?>>
                <?= esc_html( $ta->display_name ) ?>
            </option>
        <?php endforeach; ?>
    </select>
</p>


            </div>

            <?php if ( $settings ) : ?>
            <div class="options_group" style="padding: 10px 16px; background:#f9f9f9; border-top:1px solid #ddd">
                <p style="margin:0; color:#555; font-size:12px">
                    وضعیت فعلی: <strong><?= TA_Product_Meta::course_type_label( $settings->course_type ) ?></strong>
                    | پیش‌نیازها:
                    <strong>
                        <?php
                        if ( $prereq_ids ) {
                            $names = [];
                            foreach ( $prereq_ids as $pid ) {
                                if ( ! function_exists( 'wc_get_product' ) ) { continue; }
                                $p = wc_get_product( $pid );
                                $names[] = $p ? $p->get_name() : "ID:{$pid}";
                            }
                            echo esc_html( implode( ' یا ', $names ) );
                        } else {
                            echo 'ندارد';
                        }
                        ?>
                    </strong>
                </p>
            </div>
            <?php endif; ?>
        </div>

        <script>
        document.getElementById('ta_course_type_select').addEventListener('change', function () {
            var val = this.value;
            document.getElementById('ta_prereq_row').style.display = (val === 'creative'|| val === 'critique' || val === '') ? 'none' : '';
            document.getElementById('ta_pro_group_row').style.display = (val === 'professional' || val === 'critique') ? '' : 'none';  
            document.getElementById('ta_critique_ta_row').style.display = ( val === 'critique') ? '' : 'none';  
            document.getElementById('ta_professional_ta_row').style.display = (val === 'professional') ? '' : 'none';

        });
        </script>
        <?php
    }

    public function save( int $product_id ): void {
    // 1. بررسی ارسال فرم و وجود فیلد ترم
    if ( ! isset( $_POST['ta_term_id'] ) ) {
        return;
    }

    // 2. دریافت و پاکسازی مقادیر فرم
    $term_id        = (int) sanitize_text_field( $_POST['ta_term_id'] ?? '' );
    $course_type    = sanitize_text_field( $_POST['ta_course_type'] ?? '' );
    $prereq_ids     = array_map( 'intval', (array) ( $_POST['ta_prerequisite_product_ids'] ?? [] ) );
    
    // نکته: نام فیلد در فرم HTML باید حتما name="ta_pro_group_link" باشد. 
    $pro_group_link = esc_url_raw( $_POST['ta_pro_group_link'] ?? '' );

    // 3. اگر ترم یا نوع دوره خالی باشد، هیچ چیز ذخیره نمی‌شود!
    if ( ! $term_id || ! $course_type ) {
        return;
    }

    // 4. برای دوره خلاق پیش‌نیاز نداریم
    if ( $course_type === 'creative' ) {
        $prereq_ids = [];
    }

    // 5. ذخیره استادیار نقد اثر (خطای متغیر $post_id در اینجا به $product_id اصلاح شد)
    if ( $course_type === 'critique' && ! empty( $_POST['ta_critique_ta_id'] ) ) {
        update_post_meta( $product_id, '_ta_critique_ta_id', intval( $_POST['ta_critique_ta_id'] ) );
    } 
    if ( $course_type === 'professional' && ! empty( $_POST['ta_professional_ta_id'] ) ) {
    update_post_meta( $product_id, '_ta_professional_ta_id', intval( $_POST['ta_professional_ta_id'] ) );
} 


    // 6. ذخیره سایر تنظیمات شامل لینک گروه در جدول/متای اختصاصی
    TA_Product_Meta::save_settings( $product_id, $term_id, $course_type, $prereq_ids, $pro_group_link );
}

}
