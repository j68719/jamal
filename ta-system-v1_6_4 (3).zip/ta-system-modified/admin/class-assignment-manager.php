<?php
defined( 'ABSPATH' ) || exit;

/**
 * مدیریت کامل تخصیص‌ها توسط ادمین
 * — جستجوی هنرجو با نام / شماره همراه
 * — تخصیص تکی
 * — ویرایش و حذف تخصیص‌های موجود
 * — لیست با فیلتر
 */
class TA_Admin_Assignments {

    public function __construct() {
        add_action( 'admin_post_ta_admin_assign',        [ $this, 'handle_assign'  ] );
        add_action( 'admin_post_ta_admin_edit_assign',   [ $this, 'handle_edit'    ] );
        add_action( 'admin_post_ta_admin_delete_assign', [ $this, 'handle_delete'  ] );
        // ta_search_users در TA_Admin_TA_Manager ثبت شده — تکرار نمی‌کنیم
        add_action( 'wp_ajax_ta_get_assignment',         [ $this, 'ajax_get_assignment' ] );
        add_action( 'wp_ajax_ta_save_student_gender',[ $this, 'ajax_save_student_gender' ] );

    }
    
 public function ajax_save_student_gender () : void{
    check_ajax_referer( 'ta_admin_nonce', 'nonce' );

    $student_id = intval( $_POST['student_id'] ?? 0 );
    $gender     = sanitize_text_field( $_POST['gender'] ?? '' );

    if ( ! $student_id || ! in_array( $gender, [ 'male', 'female' ], true ) ) {
        wp_send_json_error( 'داده نامعتبر' );
    }

    update_user_meta( $student_id, 'student_gender', $gender );
    update_user_meta( $student_id, 'gender', $gender );

    wp_send_json_success( [
        'message' => 'جنسیت ذخیره شد',
        'gender'  => $gender,
    ] );
} 

    // AJAX — دریافت اطلاعات تخصیص برای ویرایش
    public function ajax_get_assignment(): void {
        check_ajax_referer( 'ta_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        $id  = (int) ( $_POST['id'] ?? 0 );
        $row = TA_Database::get_row(
            "SELECT * FROM " . TA_Database::table( 'assignments' ) . " WHERE id = %d",
            [ $id ]
        );
        if ( ! $row ) wp_send_json_error( 'یافت نشد' );

        $student = get_userdata( $row->student_id );
        $phone = class_exists('TA_User_Helper')
    ? TA_User_Helper::get_phone( $row->student_id )
    : (
        get_user_meta($row->student_id, 'kerasno-phone',  true) ?:
        get_user_meta($row->student_id, 'phone',          true) ?:
        get_user_meta($row->student_id, 'Mreeir_phone',   true) ?:
        get_user_meta($row->student_id, 'billing_phone',  true) ?:
        ''
    );
        $ta      = TA_Database::get_row(
            "SELECT ta.*, u.display_name FROM " . TA_Database::table('assistants') . " ta
             JOIN {$GLOBALS['wpdb']->users} u ON u.ID = ta.user_id WHERE ta.id = %d",
            [ $row->ta_id ]
        );

        wp_send_json_success( [
            'id'             => $row->id,
            'student_id'     => $row->student_id,
            'student_name'   => $student ? $student->display_name : '',
            'student_email'  => $student ? $student->user_email : '',
            'student_phone'  => $phone ?: '',
            'ta_id'          => $row->ta_id,
            'ta_name'        => $ta ? $ta->display_name : '',
            'product_id'     => $row->product_id,
            'term_id'        => $row->term_id,
            'course_type'    => $row->course_type,
            'messenger'      => $row->messenger,
            'student_gender' => $row->student_gender,
            'group_link'     => $row->group_link,
            'status'         => $row->status,
            'cancel_date'         => $row->cancel_date ,
            'cancel_reason'         => $row->cancel_reason,
        ] );
    }

    // ════════════════════════════════════════════════════════════════
    // HANDLERS
    // ════════════════════════════════════════════════════════════════

    public function handle_assign(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'دسترسی غیرمجاز' );
        check_admin_referer( 'ta_admin_assign' );

        $student_id = (int) ( $_POST['student_id'] ?? 0 );
        $ta_id      = (int) ( $_POST['ta_id'] ?? 0 );
        $product_id = (int) ( $_POST['product_id'] ?? 0 );
        $messenger  = sanitize_text_field( $_POST['messenger'] ?? '' );
        $gender     = sanitize_text_field( $_POST['student_gender'] ?? '' );
        $group_link = sanitize_url( $_POST['group_link'] ?? '' );
        $status     = sanitize_text_field( $_POST['status'] ?? 'active' );

        if ( ! $student_id || ! $ta_id || ! $product_id ) {
            $this->redirect( 'error=missing_fields' );
        }

        $settings = TA_Product_Meta::get_settings( $product_id );
        if ( ! $settings ) {
            $this->redirect( 'error=product_not_configured' );
        }

        // بررسی تکراری
        $existing = TA_Database::get_row(
            "SELECT id FROM " . TA_Database::table('assignments') . " WHERE student_id=%d AND product_id=%d",
            [ $student_id, $product_id ]
        );
        if ( $existing ) {
            $this->redirect( 'error=duplicate' );
        }

        TA_Database::insert( 'ta_assignments', [
            'student_id'     => $student_id,
            'ta_id'          => $ta_id,
            'product_id'     => $product_id,
            'term_id'        => $settings->term_id,
            'course_type'    => $settings->course_type,
            'messenger'      => $messenger,
            'student_gender' => $gender,
            'group_link'     => $group_link ?: null,
            'status'         => $status,
            'created_at'     => current_time( 'mysql' ),
            
        ] );

        $this->redirect( 'assigned=1' );
    }

public function handle_edit(): void {
    // 1. اعتبارسنجی اولیه و بررسی دسترسی‌ها
    if ( ! current_user_can('manage_options') ) {
        wp_die('دسترسی غیرمجاز');
    }
    check_admin_referer('ta_admin_edit_assign');

    // 2. خواندن و پاکسازی تمام داده‌های ورودی از فرم
    $id              = (int) ( $_POST['assignment_id'] ?? 0 );
    $ta_id           = (int) ( $_POST['ta_id'] ?? 0 );
    $messenger       = sanitize_text_field( $_POST['messenger'] ?? '' );
    $gender          = sanitize_text_field( $_POST['student_gender'] ?? '' );
    $group_link      = sanitize_url( $_POST['group_link'] ?? '' );
    $status          = sanitize_text_field( $_POST['status'] ?? 'active' );
    $cancel_reason   = sanitize_textarea_field( $_POST['cancel_reason'] ?? '' );
    // تاریخ انصراف را از ورودی بخوانید، اگر خالی بود null در نظر بگیرید
    $cancel_date_from_post = ! empty( $_POST['cancel_date'] ) ? sanitize_text_field( $_POST['cancel_date'] ) : null;

    // اگر شناسه‌ها وجود ندارند، عملیات را متوقف کن
    if ( ! $id || ! $ta_id ) {
        $this->redirect('error=missing_fields');
    }

    // 3. دریافت اطلاعات فعلی تخصیص از دیتابیس (برای بررسی وضعیت قبلی)
    $current_assignment = TA_Database::get_row(
        "SELECT student_id, cancel_date FROM " . TA_Database::table('assignments') . " WHERE id = %d",
        [ $id ]
    );

    // اگر تخصیص وجود نداشت، متوقف شو
    if ( ! $current_assignment ) {
        $this->redirect('error=not_found');
    }

    // 4. به‌روزرسانی اطلاعات پروفایل هنرجو (جنسیت)
    if ( ! empty( $current_assignment->student_id ) ) {
        $student_id = (int) $current_assignment->student_id;
        if ( in_array( $gender, [ 'male', 'female' ], true ) ) {
            update_user_meta( $student_id, 'student_gender', $gender );
            update_user_meta( $student_id, 'gender', $gender ); // جهت حفظ سازگاری
        }
    }

    // 5. آماده‌سازی آرایه داده‌ها برای به‌روزرسانی جدول اصلی
    $update_data = [
        'ta_id'          => $ta_id,
        'messenger'      => $messenger,
        'student_gender' => $gender,
        'group_link'     => $group_link ?: null,
        'status'         => $status,
    ];

    // 6. منطق پردازش وضعیت انصراف
    if ( $status === 'canceled' ) {
        $update_data['cancel_reason'] = $cancel_reason;
        
        // اگر کاربر تاریخی در فرم وارد کرده، همان را ذخیره کن
        if ( $cancel_date_from_post ) {
            $update_data['cancel_date'] = $cancel_date_from_post;
        } 
        // در غیر این صورت، اگر از قبل هم تاریخ انصرافی وجود نداشته، تاریخ فعلی را ثبت کن
        elseif ( empty( $current_assignment->cancel_date ) ) {
            $update_data['cancel_date'] = current_time('mysql');
        }
        // اگر نه تاریخ جدیدی وارد شده و نه اولین بار است، تاریخ قبلی دست‌نخورده باقی می‌ماند
        
    } else {
        // اگر وضعیت چیزی غیر از "انصراف" بود، اطلاعات انصراف را پاک کن
        $update_data['cancel_reason'] = '';
        $update_data['cancel_date']   = null;
    }

    // 7. اجرای به‌روزرسانی در دیتابیس
    TA_Database::update( 'ta_assignments', $update_data, [ 'id' => $id ] );

    // 8. بازگرداندن کاربر به صفحه مدیریت
    $this->redirect('edited=1');
}


    public function handle_delete(): void {
    // ۱. بررسی دسترسی‌ها و امنیت درخواست
    if ( ! current_user_can( 'manage_options' ) ) wp_die( 'دسترسی غیرمجاز' );
    check_admin_referer( 'ta_admin_delete_assign' );

    $id = (int) ( $_POST['assignment_id'] ?? 0 );
    if ( ! $id ) {
        $this->redirect( 'error=no_id' );
        return;
    }

    // ۲. دریافت اطلاعات تخصیص از دیتابیس
    $row = TA_Database::get_row(
        "SELECT * FROM " . TA_Database::table('assignments') . " WHERE id = %d",
        [ $id ]
    );

    // اگر تخصیص پیدا نشد، عملیات متوقف شود
    if ( ! $row ) {
        $this->redirect( 'error=not_found' );
        return;
    }

    global $wpdb;

    // ۳. آزاد کردن گروه (اگر دوره خلاق بوده و گروه داشته است)
    if ( ! empty( $row->group_id ) ) {
        TA_Database::update( 'ta_groups', [
            'is_used'             => 0,
            'assigned_to_user_id' => null,
            'assigned_at'         => null,
        ], [ 'id' => $row->group_id ] );
    }

    // ۴. کاهش ظرفیت استادیار (اصلاح شده و دقیق)
    if ( ! empty( $row->capacity_id ) ) {
        // اگر capacity_id وجود داشت، ظرفیت را مستقیماً و دقیق کم کن
        $wpdb->query( $wpdb->prepare(
            "UPDATE " . TA_Database::table('capacities') . "
             SET used_capacity = GREATEST(0, used_capacity - 1)
             WHERE id = %d",
            [ $row->capacity_id ]
        ) );
    } else {
        // روش پشتیبان برای رکوردهای قدیمی که capacity_id آن‌ها ثبت نشده (صفر است)
        $wpdb->query( $wpdb->prepare(
            "UPDATE " . TA_Database::table('capacities') . "
             SET used_capacity = GREATEST(0, used_capacity - 1)
             WHERE ta_id = %d AND course_type = %s AND term_id = %d
               AND student_gender IN (%s, 'both')
             ORDER BY student_gender DESC LIMIT 1",
            [ $row->ta_id, $row->course_type, $row->term_id, $row->student_gender ]
        ) );
    }

    // ۵. حذف نمره مرتبط (جلوگیری از نمرات یتیم در سیستم)
    if ( class_exists('TA_Grade') ) {
        $grade_exists = TA_Grade::get_grade( $row->student_id, $row->product_id );
        if ( $grade_exists ) {
            // [FIX-10] نام جدول اصلاح شد: 'grades' → 'ta_grades' (قبلاً به جدول اشتباه می‌رفت)
            TA_Database::delete( 'ta_grades', [
                'student_id' => $row->student_id,
                'product_id' => $row->product_id
            ] );
        }
    }

    // ۶. حذف رکورد تخصیص از دیتابیس
    TA_Database::delete( 'ta_assignments', [ 'id' => $id ] );
    
    // بازگشت با پیام موفقیت
    $this->redirect( 'deleted=1' );
}



    // ════════════════════════════════════════════════════════════════
    // RENDER
    // ════════════════════════════════════════════════════════════════

    public function render(): void {
        if ( ! TA_Database::tables_exist() ) {
            echo '<div class="wrap"><div class="notice notice-error"><p>جداول پایگاه داده ایجاد نشده‌اند.</p></div></div>';
            return;
        }

        global $wpdb;
        $this->enqueue_admin_scripts();

        // پارامترهای فیلتر
        $search   = sanitize_text_field( $_GET['s'] ?? '' );
        $f_term   = (int) ( $_GET['f_term'] ?? 0 );
        $f_course = sanitize_text_field( $_GET['f_course'] ?? '' );
        $f_status = sanitize_text_field( $_GET['f_status'] ?? '' );
        $filter_ta     = sanitize_text_field( $_GET['filter_ta'] ?? '' );
        $filter_ta_id  = (int) ( $_GET['filter_ta_id'] ?? 0 );

        $filter_gender = sanitize_text_field($_GET['filter_gender'] ?? '');
        $paged    = max( 1, (int) ( $_GET['paged'] ?? 1 ) );
        $per_page = 200;

        $assign_table = TA_Database::table( 'assignments' );
        $ta_table     = TA_Database::table( 'assistants' );
        $terms_table  = TA_Database::table( 'terms' );

        // ── ساخت WHERE ───────────────────────────────────────────────────────
        $where   = [];
        $where[] = '1=1';
        $params  = [];



        if ( $search ) {
            $like = '%' . $wpdb->esc_like( $search ) . '%';
            // جستجو در نام هنرجو + ایمیل + شماره همراه
            $phone_ids = $wpdb->get_col( $wpdb->prepare(
    "SELECT DISTINCT user_id FROM {$wpdb->usermeta} 
     WHERE meta_key IN ('kerasno-phone','phone','Mreeir_phone','billing_phone') 
     AND meta_value LIKE %s",
    [ $like ]
) );
            $name_ids = $wpdb->get_col( $wpdb->prepare(
                "SELECT ID FROM {$wpdb->users} WHERE display_name LIKE %s OR user_email LIKE %s",
                [ $like, $like ]
            ) );
            $all_ids = array_unique( array_merge( $phone_ids, $name_ids ) );

            if ( $all_ids ) {
                $ids_placeholder = implode( ',', array_map( 'intval', $all_ids ) );
                $where[] = "a.student_id IN ({$ids_placeholder})";
            } else {
                $where[] = '1=0'; // هیچ نتیجه‌ای
            }
        }
        if ( $f_term )   { $where[] = 'a.term_id = %d';      $params[] = $f_term; }
        if ( $f_course ) { $where[] = 'a.course_type = %s';   $params[] = $f_course; }
        if ( $f_status ) { $where[] = 'a.status = %s';        $params[] = $f_status; }
        if ( $filter_gender ) {  $where[]= "a.student_gender = %s";    $params[] = $filter_gender;
        }
 
        if ( $filter_ta === 'unassigned' ) {
            // اضافه شدن ta.id IS NULL برای پیدا کردن تکالیفی که استادشان حذف شده است
            $where[] = '(a.ta_id IS NULL OR a.ta_id = 0 OR ta.id IS NULL)';
        } elseif ( $filter_ta_id > 0 ) {
            $where[]  = 'ta.id = %d';
            $params[] = $filter_ta_id;
        }


        $where_sql = implode( ' AND ', $where );

       
        $base_sql = "FROM {$assign_table} a
             LEFT JOIN {$ta_table}    ta  ON ta.id  = a.ta_id
             JOIN {$wpdb->users}      u   ON u.ID   = a.student_id
             LEFT JOIN {$wpdb->users} tu  ON tu.ID  = ta.user_id
             LEFT JOIN {$terms_table} t   ON t.id   = a.term_id
             WHERE {$where_sql}";


        $total = (int) $wpdb->get_var(
            $params
                ? $wpdb->prepare( "SELECT COUNT(*) {$base_sql}", $params )
                : "SELECT COUNT(*) {$base_sql}"
        );

        $offset = ( $paged - 1 ) * $per_page;
        $select_sql = "SELECT a.*, u.display_name AS student_name, u.user_email AS student_email,
                              tu.display_name AS ta_name, t.name AS term_name {$base_sql}
                       ORDER BY a.created_at DESC LIMIT {$per_page} OFFSET {$offset}";

        $rows = $params
            ? ( $wpdb->get_results( $wpdb->prepare( $select_sql, $params ) ) ?: [] )
            : ( $wpdb->get_results( $select_sql ) ?: [] );

        // — داده‌های فرم‌ها —
        $terms = TA_Database::get_results( "SELECT * FROM {$terms_table} ORDER BY order_index DESC" );
        $all_tas = $wpdb->get_results(
            "SELECT ta.id, ta.messengers, u.display_name
             FROM {$ta_table} ta JOIN {$wpdb->users} u ON u.ID = ta.user_id
             WHERE ta.is_active = 1 ORDER BY ta.rank DESC"
        ) ?: [];
        $products = function_exists('wc_get_products') ? wc_get_products( [ 'limit' => -1, 'status' => 'publish', 'orderby' => 'title' ] ) : [];

                        $course_labels = [ 'creative' => 'خلاق', 'critique' => 'نقد اثر', 'intro' => 'مقدماتی', 'advanced' => 'پیشرفته' , 'professional'=>'حرفه ای'];


                $m_labels      = [ 'telegram' => 'تلگرام', 'bale' => 'بله', 'eitaa' => 'ایتا' ,'both'=>'همه'];

        $total_pages   = ceil( $total / $per_page );

        $base_url = admin_url( 'admin.php?page=ta-assignments' );
        ?>
        <div class="wrap" dir="rtl">
            <h1 style="display:flex;align-items:center;gap:16px">
                تخصیص‌ها
                <button class="button button-primary" onclick="taOpenAssignModal()">➕ تخصیص تکی جدید</button>
                <button class="button button-secondary" onclick="taOpenCapacityAssignModal()" style="margin-right:8px">🎯 تخصیص بر اساس ظرفیت استادیار</button>

            </h1>

            <?php $this->render_notices(); ?>

            <style>
            #ta-filter-form select:focus,
            #ta-filter-form input:focus { outline:2px solid #0073aa; border-color:#0073aa; }
            .widefat tbody tr:hover td { background:#f8fafe !important; }
            .widefat tbody tr { transition: background .12s; }
            .ta-row-canceled td { opacity:.7; background:#fff5f5 !important; }
            .ta-row-completed td { background:#f9f9f9 !important; }
            </style>

            <!-- ── فیلتر ─────────────────────────────────────────────────── -->
            <?php
            // تعداد فیلترهای فعال
            $active_filters = array_filter([
                $search, $f_term, $f_course, $f_status, $filter_gender,
                $filter_ta === 'unassigned' ? 'unassigned' : '', $filter_ta_id
            ]);
            $has_active_filter = !empty($active_filters);
            ?>
            <form method="get" id="ta-filter-form" style="background:#fff;padding:16px 20px;border:1px solid #ddd;border-radius:8px;margin:16px 0;box-shadow:0 1px 3px rgba(0,0,0,.06)">
                <input type="hidden" name="page" value="ta-assignments">

                <div style="display:flex;flex-wrap:wrap;gap:14px;align-items:flex-end">

                    <!-- جستجو -->
                    <div style="flex:1;min-width:200px">
                        <label style="display:block;font-size:0.78rem;font-weight:600;color:#555;margin-bottom:4px">🔍 جستجو (نام / شماره / ایمیل)</label>
                        <input type="text" name="s" value="<?= esc_attr( $search ) ?>"
                               placeholder="مثال: ۰۹۱۲..."
                               style="width:100%;padding:6px 10px;border:1px solid #ccc;border-radius:5px;font-size:0.9rem"
                               autocomplete="off">
                    </div>

                    <!-- استادیار -->
                    <div style="min-width:160px">
                        <label style="display:block;font-size:0.78rem;font-weight:600;color:#555;margin-bottom:4px">👨‍🏫 استادیار</label>
                        <select name="filter_ta_id"
                                style="width:100%;padding:6px 8px;border:1px solid <?= $filter_ta_id ? '#0073aa' : '#ccc' ?>;border-radius:5px;<?= $filter_ta_id ? 'background:#f0f7ff;font-weight:600;color:#0073aa' : '' ?>">
                            <option value="">همه استادیاران</option>
                            <?php foreach ( $all_tas as $ta ) : ?>
                                <option value="<?= $ta->id ?>" <?= selected( $filter_ta_id, $ta->id, false ) ?>>
                                    <?= esc_html( $ta->display_name ) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- ترم -->
                    <div style="min-width:130px">
                        <label style="display:block;font-size:0.78rem;font-weight:600;color:#555;margin-bottom:4px">📅 ترم</label>
                        <select name="f_term"
                                style="width:100%;padding:6px 8px;border:1px solid <?= $f_term ? '#0073aa' : '#ccc' ?>;border-radius:5px;<?= $f_term ? 'background:#f0f7ff;font-weight:600;color:#0073aa' : '' ?>">
                            <option value="">همه</option>
                            <?php foreach ( $terms as $t ) : ?>
                                <option value="<?= $t->id ?>" <?= selected( $f_term, $t->id, false ) ?>><?= esc_html( $t->name ) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- نوع دوره -->
                    <div style="min-width:130px">
                        <label style="display:block;font-size:0.78rem;font-weight:600;color:#555;margin-bottom:4px">📚 نوع دوره</label>
                        <select name="f_course"
                                style="width:100%;padding:6px 8px;border:1px solid <?= $f_course ? '#0073aa' : '#ccc' ?>;border-radius:5px;<?= $f_course ? 'background:#f0f7ff;font-weight:600;color:#0073aa' : '' ?>">
                            <option value="">همه</option>
                            <?php foreach ( $course_labels as $v => $l ) : ?>
                                <option value="<?= $v ?>" <?= selected( $f_course, $v, false ) ?>><?= $l ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <!-- وضعیت -->
                    <div style="min-width:110px">
                        <label style="display:block;font-size:0.78rem;font-weight:600;color:#555;margin-bottom:4px">🔖 وضعیت</label>
                        <select name="f_status"
                                style="width:100%;padding:6px 8px;border:1px solid <?= $f_status ? '#0073aa' : '#ccc' ?>;border-radius:5px;<?= $f_status ? 'background:#f0f7ff;font-weight:600;color:#0073aa' : '' ?>">
                            <option value="">همه</option>
                            <option value="active"    <?= selected( $f_status, 'active',    false ) ?>>✅ فعال</option>
                            <option value="completed" <?= selected( $f_status, 'completed', false ) ?>>🏁 تکمیل</option>
                            <option value="canceled"  <?= selected( $f_status, 'canceled',  false ) ?>>❌ انصراف</option>
                        </select>
                    </div>

                    <!-- جنسیت -->
                    <div style="min-width:110px">
                        <label style="display:block;font-size:0.78rem;font-weight:600;color:#555;margin-bottom:4px">⚧ جنسیت</label>
                        <select name="filter_gender"
                                style="width:100%;padding:6px 8px;border:1px solid <?= $filter_gender ? '#0073aa' : '#ccc' ?>;border-radius:5px;<?= $filter_gender ? 'background:#f0f7ff;font-weight:600;color:#0073aa' : '' ?>">
                            <option value="">همه</option>
                            <option value="male"   <?= selected( $filter_gender, 'male',   false ) ?>>👨 آقا</option>
                            <option value="female" <?= selected( $filter_gender, 'female', false ) ?>>👩 خانم</option>
                        </select>
                    </div>

                    <!-- دکمه‌های عملیات -->
                    <div style="display:flex;gap:8px;align-items:flex-end;padding-bottom:1px">
                        <button type="submit" class="button button-primary" style="padding:6px 16px;height:34px">
                            🔎 اعمال فیلتر
                        </button>
                        <?php if ( $has_active_filter ) : ?>
                        <a href="<?= $base_url ?>" class="button button-secondary" style="padding:6px 12px;height:34px;background:#fff3cd;border-color:#ffc107;color:#856404" title="پاک‌کردن همه فیلترها">
                            ✕ پاک‌کردن
                        </a>
                        <?php else : ?>
                        <a href="<?= $base_url ?>" class="button" style="padding:6px 12px;height:34px">پاک‌کردن</a>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- دکمه نمایش بدون استاد در ردیف جداگانه -->
                <div style="margin-top:10px;padding-top:10px;border-top:1px dashed #eee;display:flex;align-items:center;gap:12px;flex-wrap:wrap">
                    <a href="<?= esc_url( admin_url('admin.php?page=ta-assignments&filter_ta=unassigned') ) ?>"
                       class="button <?= $filter_ta === 'unassigned' ? 'button-primary' : 'button-secondary' ?>"
                       style="<?= $filter_ta === 'unassigned' ? '' : 'background:#fff8e1;border-color:#ffa000;color:#c17900' ?>">
                        ⚠️ تکالیف بدون استادیار
                    </a>
                    <?php if ( $has_active_filter ) : ?>
                    <small style="color:#888;font-size:0.78rem">
                        <?= $total ?> نتیجه با فیلترهای فعال
                        <?php if ( $filter_ta_id ) :
                            $active_ta_name = '';
                            foreach ( $all_tas as $ta ) { if ( $ta->id == $filter_ta_id ) { $active_ta_name = $ta->display_name; break; } }
                        ?>
                        — استادیار: <strong><?= esc_html( $active_ta_name ) ?></strong>
                        <?php endif; ?>
                    </small>
                    <?php endif; ?>
                </div>
            </form>

            <!-- ── جدول تخصیص‌ها ─────────────────────────────────────────── -->
            <p style="color:#636e72;font-size:0.85rem;margin:8px 0">
                مجموع: <strong style="color:#2d3436"><?= number_format($total) ?></strong> تخصیص
                <?php if ( $has_active_filter ) : ?>
                <span style="margin-right:10px;padding:2px 8px;background:#dff0ff;border:1px solid #b3d7ff;border-radius:10px;font-size:0.78rem;color:#0073aa">فیلتر فعال</span>
                <?php endif; ?>
            </p>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th width="30">#</th>
                        <th>هنرجو</th>
                       <th width="70">جنسیت</th>


                        <th width="120">شماره همراه</th>
                        <th>استادیار</th>
                        <th width="100">ترم</th>
                        <th width="80">دوره</th>
                        <th width="80">پیامرسان</th>
                        <th>لینک گروه</th>
                        <th width="70">وضعیت</th>
                        <th width="130">عملیات</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ( empty( $rows ) ) : ?>
                    <tr><td colspan="11" style="text-align:center;padding:40px 24px;color:#aaa">
                        <div style="font-size:2rem;margin-bottom:8px">🔍</div>
                        <div style="font-size:1rem;color:#888">نتیجه‌ای یافت نشد.</div>
                        <?php if ( $has_active_filter ) : ?>
                        <div style="margin-top:8px"><a href="<?= $base_url ?>" style="color:#0073aa;font-size:0.85rem">پاک‌کردن فیلترها</a></div>
                        <?php endif; ?>
                    </td></tr>
                <?php endif; ?>
                <?php foreach ( $rows as $row ) :
                    $phone = class_exists('TA_User_Helper')
    ? TA_User_Helper::get_phone( $row->student_id )
    : (
        get_user_meta($row->student_id, 'kerasno-phone',  true) ?:
        get_user_meta($row->student_id, 'phone',          true) ?:
        get_user_meta($row->student_id, 'Mreeir_phone',   true) ?:
        get_user_meta($row->student_id, 'billing_phone',  true) ?:
        ''
    );
                    $row_class = $row->status === 'canceled' ? 'ta-row-canceled' : ( $row->status === 'completed' ? 'ta-row-completed' : '' );
                ?>
                    <tr class="<?= $row_class ?>">
                        <td style="color:#bbb"><?= $row->id ?></td>
                        <td>
                            <strong><?= esc_html( $row->student_name ) ?></strong><br>
                            <small style="color:#888"><?= esc_html( $row->student_email ) ?></small>
                        </td>
                         <td>
        <?php 
            if ( $row->student_gender === 'male' ) {
                echo 'آقا';
            } elseif ( $row->student_gender === 'female' ) {
                echo 'خانم';
            } else {
                echo '—';
            }
        ?>
    </td>
    
                        <td style="direction:ltr;text-align:left"><?= esc_html( $phone ?: '—' ) ?></td>
                        <td>
                            <?php if ( $row->ta_name ) : ?>
                            <a href="<?= esc_url( add_query_arg( ['page'=>'ta-assignments','filter_ta_id'=>$row->ta_id], admin_url('admin.php') ) ) ?>"
                               title="فیلتر بر اساس این استادیار"
                               style="color:#0073aa;text-decoration:none;font-size:0.9rem"
                               onmouseover="this.style.textDecoration='underline'" onmouseout="this.style.textDecoration='none'">
                                <?= esc_html( $row->ta_name ) ?>
                            </a>
                            <?php else : ?>
                            <span style="color:#e17055;font-size:0.82rem">⚠️ بدون استاد</span>
                            <?php endif; ?>
                        </td>
                        <td><?= esc_html( $row->term_name ?? '—' ) ?></td>
                        <td><?= $course_labels[ $row->course_type ] ?? $row->course_type ?></td>
                        <td><?= $m_labels[ $row->messenger ] ?? esc_html( $row->messenger ?? '—' ) ?></td>
                        <td>
                            <?php if ( $row->group_link ) : ?>
                                <a href="<?= esc_url( $row->group_link ) ?>" target="_blank" style="font-size:0.8rem">مشاهده</a>
                            <?php else : ?>
                                <span style="color:#bbb">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ( $row->status === 'active' ) : ?>
                                <span style="color:#00b894;font-weight:600;font-size:0.82rem">● فعال</span>
                            <?php elseif ( $row->status === 'canceled' ) : ?>
                                <span style="color:#d63031;font-size:0.82rem" title="<?= esc_attr($row->cancel_reason ?? '') ?>">✕ انصراف</span>
                            <?php else : ?>
                                <span style="color:#6c757d;font-size:0.82rem">🏁 تکمیل</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button class="button button-small"
                                    onclick="taOpenEditModal(<?= $row->id ?>)">
                                ✏️
                            </button>
                            <form method="post" action="<?= admin_url('admin-post.php') ?>" style="display:inline"
                                  onsubmit="return confirm('حذف تخصیص؟')">
                                <?php wp_nonce_field('ta_admin_delete_assign'); ?>
                                <input type="hidden" name="action" value="ta_admin_delete_assign">
                                <input type="hidden" name="assignment_id" value="<?= $row->id ?>">
                                <button class="button button-small button-link-delete">🗑️</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <!-- pagination -->
            <?php if ( $total_pages > 1 ) : ?>
            <div style="margin-top:16px;display:flex;align-items:center;justify-content:center;gap:4px;flex-wrap:wrap">
                <?php
                $pagination_args = [
                    's'             => $search,
                    'f_term'        => $f_term,
                    'f_course'      => $f_course,
                    'f_status'      => $f_status,
                    'filter_gender' => $filter_gender,
                    'filter_ta_id'  => $filter_ta_id,
                    'filter_ta'     => $filter_ta,
                ];
                ?>
                <?php if ( $paged > 1 ) : ?>
                <a href="<?= esc_url( add_query_arg( array_merge( $pagination_args, ['paged' => $paged - 1] ), $base_url ) ) ?>"
                   class="button" style="padding:4px 10px">«</a>
                <?php endif; ?>

                <?php for ( $p = max(1, $paged - 3); $p <= min($total_pages, $paged + 3); $p++ ) : ?>
                    <a href="<?= esc_url( add_query_arg( array_merge( $pagination_args, ['paged' => $p] ), $base_url ) ) ?>"
                       class="button <?= $p === $paged ? 'button-primary' : '' ?>"
                       style="padding:4px 10px;min-width:34px;text-align:center">
                        <?= $p ?>
                    </a>
                <?php endfor; ?>

                <?php if ( $paged < $total_pages ) : ?>
                <a href="<?= esc_url( add_query_arg( array_merge( $pagination_args, ['paged' => $paged + 1] ), $base_url ) ) ?>"
                   class="button" style="padding:4px 10px">»</a>
                <?php endif; ?>

                <small style="color:#888;margin-right:8px">صفحه <?= $paged ?> از <?= $total_pages ?></small>
            </div>
            <?php endif; ?>

        </div>

     
        <!-- ════ مودال ویرایش ═══════════════════════════════════════════════ -->
        <div id="ta-edit-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99999;overflow:auto">
            <div style="background:#fff;max-width:560px;margin:60px auto;border-radius:8px;padding:28px;direction:rtl;position:relative">
                <button onclick="taCloseModal('ta-edit-modal')"
                        style="position:absolute;left:16px;top:16px;background:none;border:none;font-size:20px;cursor:pointer">✕</button>
                <h2 style="margin-top:0">✏️ ویرایش تخصیص</h2>
                <div id="ta-edit-info" style="background:#f0f4f8;border-radius:6px;padding:10px 14px;margin-bottom:16px;font-size:0.85rem"></div>

                <form method="post" action="<?= admin_url('admin-post.php') ?>">
                    <?php wp_nonce_field('ta_admin_edit_assign'); ?>
                    <input type="hidden" name="action"        value="ta_admin_edit_assign">
                    <input type="hidden" name="assignment_id" id="edit_assignment_id">

                    <table class="form-table" style="direction:rtl">
                        <tr>
                            <th>استادیار</th>
                            <td>
                                <select name="ta_id" id="edit_ta_id" style="width:100%">
                                    <?php foreach ( $all_tas as $ta ) :
                                        $m = json_decode($ta->messengers,true) ?: [];
                                    ?>
                                        <option value="<?= $ta->id ?>"><?= esc_html($ta->display_name) ?> (<?= implode(', ',$m) ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th>پیامرسان</th>
                            <td>
                                <select name="messenger" id="edit_messenger" style="width:auto">
                                    <option value="telegram">تلگرام</option>
                                    <option value="bale">بله</option>
                                    <option value="eitaa">ایتا</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th>جنسیت هنرجو</th>
                            <td>
                                <select name="student_gender" id="edit_gender" style="width:auto">
                                    <option value="female">خانم</option>
                                    <option value="male">آقا</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th>لینک گروه</th>
                            <td><input type="url" name="group_link" id="edit_group_link" style="width:100%"></td>
                        </tr>
                        <tr>
    <th>وضعیت</th>
    <td>
        <select name="status" id="edit_status" style="width:auto" onchange="taToggleCancelFields()">
            <option value="active">فعال</option>
            <option value="completed">تکمیل‌شده</option>
            <option value="canceled">انصراف</option>
        </select>
    </td>
</tr>
<tr id="row_cancel_reason" style="display:none;">
    <th>توضیحات انصراف</th>
    <td>
        <textarea name="cancel_reason" id="edit_cancel_reason" rows="3" style="width:100%"></textarea>
    </td>
</tr>
<tr id="row_cancel_date" style="display:none;">
    <th>تاریخ انصراف</th>
    <td id="edit_cancel_date_display" style="color:#888; direction:ltr; text-align:right;"></td>
</tr>

                    </table>
                    <p><button type="submit" class="button button-primary">💾 ذخیره تغییرات</button></p>
                </form>
            </div>
        </div>   
        
        <!-- ════ مودال تخصیص جدید ════════════════════════════════════════════ -->
        <div id="ta-assign-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99999;overflow:auto">
            <div style="background:#fff;max-width:600px;margin:60px auto;border-radius:8px;padding:28px;direction:rtl;position:relative">
                <button onclick="taCloseModal('ta-assign-modal')"
                        style="position:absolute;left:16px;top:16px;background:none;border:none;font-size:20px;cursor:pointer">✕</button>
                <h2 style="margin-top:0">➕ تخصیص تکی جدید</h2>


                <form method="post" action="<?= admin_url('admin-post.php') ?>">
                    <?php wp_nonce_field('ta_admin_assign'); ?>
                    <input type="hidden" name="action"     value="ta_admin_assign">
                    <input type="hidden" name="student_id" id="assign_student_id">

                    <table class="form-table" style="direction:rtl">
                        <tr>
                            <th>جستجوی هنرجو <span style="color:red">*</span></th>
                            <td>
                                <input type="text" id="assign_student_search"
                                       placeholder="نام، شماره همراه یا ایمیل..."
                                       style="width:100%" autocomplete="off">
                                <div id="assign_student_results" style="border:1px solid #ddd;display:none;max-height:200px;overflow:auto;background:#fff;position:absolute;z-index:9999;width:380px"></div>
                                <div id="assign_student_selected" style="margin-top:6px;color:#2ecc71;font-size:0.85rem"></div>
                            </td>
                        </tr>
                        <tr>
                            <th>محصول <span style="color:red">*</span></th>
                            <td>
                                <select name="product_id" id="assign_product" style="width:100%" required>
                                    <option value="">— انتخاب کنید —</option>
                                    <?php foreach ( $products as $p ) :
                                        $s = TA_Product_Meta::get_settings( $p->get_id() );
                                        if ( ! $s ) continue;
                                        $term = TA_Database::get_row("SELECT name FROM " . TA_Database::table('terms') . " WHERE id=%d", [$s->term_id]);
                                        $ctype = $course_labels[$s->course_type] ?? $s->course_type;
                                    ?>
                                        <option value="<?= $p->get_id() ?>">
                                            <?= esc_html( $p->get_name() ) ?> — <?= esc_html($term->name??'') ?> (<?= $ctype ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th>استادیار <span style="color:red">*</span></th>
                            <td>
                                <select name="ta_id" style="width:100%" required>
                                    <option value="">— انتخاب کنید —</option>
                                    <?php foreach ( $all_tas as $ta ) :
                                        $m = json_decode($ta->messengers,true) ?: [];
                                    ?>
                                        <option value="<?= $ta->id ?>"><?= esc_html($ta->display_name) ?> (<?= implode(', ',$m) ?>)</option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th>پیامرسان</th>
                            <td>
                                <select name="messenger" style="width:auto">
                                    <option value="telegram">تلگرام</option>
                                    <option value="bale">بله</option>
                                    <option value="eitaa">ایتا</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th>جنسیت هنرجو</th>
                            <td>
                                <select name="student_gender" style="width:auto">
                                    <option value="female">خانم</option>
                                    <option value="male">آقا</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th>لینک گروه</th>
                            <td><input type="url" name="group_link" style="width:100%" placeholder="https://t.me/..."></td>
                        </tr>
                        <tr>
                            <th>وضعیت</th>
                            <td>
                                <select name="status" style="width:auto">
                                    <option value="active">فعال</option>
                                    <option value="completed">تکمیل‌شده</option>
                                </select>
                            </td>
                        </tr>
                    </table>

                    <p><button type="submit" class="button button-primary">✅ ثبت تخصیص</button></p>
                </form>
            </div>
        </div>
    
        <!-- ════ مودال تخصیص بر اساس ظرفیت ════ -->
        <div id="ta-capacity-assign-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99999;overflow:auto">
    <div style="background:#fff;max-width:640px;margin:60px auto;border-radius:8px;padding:28px;direction:rtl;position:relative">
        <button onclick="document.getElementById('ta-capacity-assign-modal').style.display='none'"
                style="position:absolute;left:16px;top:16px;background:none;border:none;font-size:20px;cursor:pointer">✕</button>
        <h2 style="margin-top:0">🎯 تخصیص بر اساس ظرفیت استادیار</h2>

        <!-- مرحله ۱ -->
        <div id="cap-step-1">
            <p style="color:#555;margin-bottom:12px">نام یا شماره همراه هنرجو را وارد کنید:</p>
            <input type="text" id="cap-student-search" class="regular-text"
                   placeholder="جستجوی هنرجو..." autocomplete="off" style="width:100%;margin-bottom:8px">
            <div id="cap-student-results" style="border:1px solid #ddd;border-radius:4px;max-height:200px;overflow-y:auto;display:none"></div>
            <div id="cap-student-selected" style="display:none;background:#f0f7ff;border-radius:6px;padding:10px 14px;margin-top:8px;font-size:.9rem"></div>
            <input type="hidden" id="cap-student-id">
        </div>

        <!-- مرحله ۲ -->
        <div id="cap-step-2" style="display:none;margin-top:16px">
            <table class="form-table" style="margin:0">
                <tr>
                    <th style="width:130px">دوره / محصول</th>
                    <td>
                        <select id="cap-product-id" class="regular-text" style="width:100%">
                            <option value="">— انتخاب کنید —</option>
                            <?php
$cap_products = function_exists('wc_get_products') ? wc_get_products( [ 'limit' => -1, 'status' => 'publish' ] ) : [];
foreach ( $cap_products as $p ) :
    $s = TA_Product_Meta::get_settings( $p->get_id() );
    if ( ! $s ) {
        continue;
    }
    $ct = isset( $s->course_type ) ? $s->course_type : '';
    ?>
    <option value="<?= esc_attr( $p->get_id() ) ?>" data-course-type="<?= esc_attr( $ct ) ?>">
        <?= esc_html( $p->get_name() ) ?>
    </option>
<?php endforeach; ?>

                        </select>
                    </td>
                </tr>
<tr id="cap-messenger-row">
    <th>پیام‌رسان</th>
    <td>
        <select id="cap-messenger" class="regular-text">
            <option value="">انتخاب کنید...</option>
            <option value="telegram">تلگرام</option>
            <option value="eitaa">ایتا</option>
            <option value="bale">بله</option>
        </select>
    </td>
</tr>
<!-- ردیف نمایش اطلاعات خوانده شده از دوره قبل -->
<tr id="cap-prev-info-row" style="display:none;">
    <th>اطلاعات دوره پیش‌نیاز</th>
    <td>
        <div style="margin-bottom: 8px; background: #f0f0f1; padding: 10px; border-radius: 4px;">
            <span id="cap-prev-info-text" style="font-weight:bold;">پیام‌رسان: ... | لینک گروه: ...</span>
        </div>
        <button type="button" id="cap-edit-prev-info-btn" class="button button-small">ویرایش اطلاعات</button>
    </td>
</tr>

<!-- ردیف لینک گروه (برای حالت ویرایش) -->
<tr id="cap-group-link-row" style="display:none;">
    <th>لینک گروه هنرجو</th>
    <td>
        <input type="url" id="cap-group-link" class="regular-text" placeholder="https://..." dir="ltr">
    </td>
</tr>


                <tr>
<th>جنسیت هنرجو</th>
<td>
    <?php 
    $user_gender = get_user_meta( get_current_user_id(), 'student_gender', true );

    if ( in_array( $user_gender, [ 'male', 'female' ], true ) ) : 
        $gender_fa = ( $user_gender === 'male' ) ? 'آقا' : 'خانم';
    ?>
    <input type="hidden" id="cap-gender-hidden" value="<?= esc_attr( $user_gender ) ?>">

        <div class="ta-field-group" id="ta-gender-display-box" style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
            <span style="font-size: 14px;">جنسیت شما: <strong><?= esc_html( $gender_fa ) ?></strong></span>
            <button type="button" id="ta-btn-edit-gender" style="background: none; border: none; cursor: pointer; color: #007cba; padding: 0; font-size: 13px; display: inline-flex; align-items: center; gap: 4px;">
                ✏️ ویرایش
            </button>
        </div>

        <div class="ta-field-group" id="ta-gender-select-box" style="display: none;">
            <label>جنسیت خود را وارد کنید:</label>
            <select id="cap-gender" class="ta-select" name="student_gender">
                <option value="male" <?php selected( $user_gender, 'male' ); ?>>آقا</option>
                <option value="female" <?php selected( $user_gender, 'female' ); ?>>خانم</option>
            </select>
        </div>
<script>
(function(){
    var productSel    = document.getElementById('cap-product-id');
    var messengerRow  = document.getElementById('cap-messenger-row');
    var messengerSel  = document.getElementById('cap-messenger');

    if ( productSel && messengerRow ) {
        productSel.addEventListener('change', function(){
            var opt = this.options[this.selectedIndex];
            var ct  = opt ? opt.getAttribute('data-course-type') : '';
            if ( ct ) {
                messengerRow.style.display = 'none';
                if ( messengerSel ) messengerSel.value = '';
            } else {
                messengerRow.style.display = '';
            }
        });
    }

    // ریست مودال: نمایش مجدد ردیف پیام‌رسان
    var origReset = window.resetCapacityModal;
    if ( typeof origReset === 'function' ) {
        window.resetCapacityModal = function() {
            origReset.apply(this, arguments);
            if ( messengerRow ) messengerRow.style.display = '';
        };
    }
})();
</script>


        <script>
            document.getElementById('ta-btn-edit-gender').addEventListener('click', function(e) {
                e.preventDefault();
                document.getElementById('ta-gender-display-box').style.display = 'none';
                document.getElementById('ta-gender-select-box').style.display = 'block';
            });
        </script>

    <?php else : ?>
        <div class="ta-field-group">
            <label>جنسیت خود را وارد کنید:</label>
            <select id="cap-gender" class="ta-select" name="student_gender">
                <option value="">— انتخاب کنید —</option>
                <option value="male">آقا</option>
                <option value="female">خانم</option>
            </select>
        </div>
    <?php endif; ?>
</td>

                </tr>
            </table>
            <p style="margin-top:12px">
                <button class="button button-primary" onclick="taLoadAvailableTAs()">🔍 نمایش ظرفیت‌های موجود</button>
            </p>
        </div>

        <!-- مرحله ۳ -->
        <div id="cap-step-3" style="display:none;margin-top:16px">
            <p style="font-weight:600;margin-bottom:8px">استادیارهای دارای ظرفیت:</p>
            <div id="cap-ta-list" style="border:1px solid #ddd;border-radius:6px;overflow:hidden"></div>
            <div id="cap-assign-msg" style="margin-top:12px;display:none;padding:10px;border-radius:6px"></div>
        </div>
        <!-- کادر بازخورد تخصیص -->
<div id="ta-assign-msg" style="display:none;"></div>

    </div>
</div>
   
  <script>    
function taToggleCancelFields() {
    var status = document.getElementById('edit_status').value;
    var reasonRow = document.getElementById('row_cancel_reason');
    var dateRow = document.getElementById('row_cancel_date');
    
    if (status === 'canceled') {
        reasonRow.style.display = 'table-row';
        // سطر تاریخ فقط در صورتی نمایش داده شود که از قبل تاریخی وجود داشته باشد
        if (document.getElementById('edit_cancel_date_display').innerText.trim() !== '') {
            dateRow.style.display = 'table-row';
        }
    } else {
        reasonRow.style.display = 'none';
        dateRow.style.display = 'none';
    }
}

// در تابعی که مودال را باز می‌کند (taOpenEditModal) باید مقادیر را ست کنید. 
// به عنوان مثال:
// document.getElementById('edit_cancel_reason').value = response.cancel_reason || '';
// document.getElementById('edit_cancel_date_display').innerText = response.cancel_date || '';
// taToggleCancelFields();
</script>

  
        <script>
var taAdminNonce = '<?= wp_create_nonce('ta_admin_nonce') ?>';
var taAjaxUrl    = '<?= admin_url('admin-ajax.php') ?>';

(function () {
    var capSearchTimer = null;

    function byId(id) {
        return document.getElementById(id);
    }

    function resetCapacityModal() {
        byId('cap-student-search').value = '';
        byId('cap-student-results').innerHTML = '';
        byId('cap-student-results').style.display = 'none';
        byId('cap-student-selected').innerHTML = '';
        byId('cap-student-selected').style.display = 'none';
        byId('cap-student-id').value = '';

        byId('cap-product-id').value = '';
      //  byId('cap-messenger').value = '';
        var messengerRow = document.getElementById('cap-messenger-row');
if (messengerRow && messengerRow.style.display !== 'none') {
    byId('cap-messenger').value = '';
}
       if (byId('cap-gender')) byId('cap-gender').value = '';
//جمال
       // byId('cap-gender').value = '';

        byId('cap-step-2').style.display = 'none';
        byId('cap-step-3').style.display = 'none';
        byId('cap-ta-list').innerHTML = '';

        hideAssignMessage();
    }

    function showCapacityModal() {
        resetCapacityModal();
        byId('ta-capacity-assign-modal').style.display = 'block';
    }

    function closeCapacityModal() {
        byId('ta-capacity-assign-modal').style.display = 'none';
    }

    window.taOpenCapacityAssignModal = showCapacityModal;

    window.taCloseCapacityAssignModal = closeCapacityModal;

    function showAssignMessage(type, html) {
        var box = byId('ta-assign-msg');
        if (!box) return;

        var styles = {
            loading: 'background:#f0f0f1;color:#555;border:1px solid #ccc;',
            success: 'background:#00a32a;color:#fff;border:1px solid #007a1f;',
            error:   'background:#d63638;color:#fff;border:1px solid #a00;'
        };

        box.style.cssText =
            'display:block;padding:10px 14px;border-radius:6px;margin-top:12px;font-size:13px;line-height:1.8;' +
            (styles[type] || styles.error);

        box.innerHTML = html;
    }

    function hideAssignMessage() {
        var box = byId('ta-assign-msg');
        if (!box) return;
        box.style.display = 'none';
        box.innerHTML = '';
    }

    function renderAvailableTAs(items) {
        var list = byId('cap-ta-list');
        list.innerHTML = '';

        if (!items || !items.length) {
            list.innerHTML = '<div style="padding:12px;color:#888">استادیاری با ظرفیت مناسب پیدا نشد.</div>';
            return;
        }

        items.forEach(function (ta) {
            var row = document.createElement('div');
            row.style.cssText =
                'display:flex;justify-content:space-between;align-items:center;gap:12px;padding:10px 14px;border-bottom:1px solid #eee;flex-wrap:wrap';

            var groupLinkHtml = ta.group_link
                ? ' — <a href="' + ta.group_link + '" target="_blank" rel="noopener" style="font-size:.85rem">🔗 لینک گروه</a>'
                : '';

            row.innerHTML =
                '<div style="flex:1;min-width:260px">' +
                    '<strong>' + ta.name + '</strong>' +
                    '<div style="margin-top:4px;font-size:.9rem;color:#555">' +
                        'ظرفیت باقی‌مانده: <strong>' + ta.remaining + '</strong>' + groupLinkHtml +
                    '</div>' +
                '</div>' +
                '<div>' +
                    '<button type="button" class="button button-primary button-small ta-capacity-pick-btn" ' +
                        'data-ta-id="' + ta.ta_id + '" ' +
                        'data-capacity-id="' + ta.capacity_id + '">' +
                        'انتخاب' +
                    '</button>' +
                '</div>';

            list.appendChild(row);
        });
        
    }

function handleProductChange() {
    var productSel   = byId('cap-product-id');
    var messengerRow = document.getElementById('cap-messenger-row');
    var messengerSel = byId('cap-messenger');

    if (!productSel || !messengerRow || !messengerSel) return;

    var selectedOption = productSel.options[productSel.selectedIndex];
    var courseType = selectedOption ? selectedOption.getAttribute('data-course-type') : '';

    if (courseType === 'creative') {
        messengerRow.style.display = '';
    } else {
        messengerRow.style.display = 'none';
        messengerSel.value = '';
    }
}

// بایند کردن به تغییر محصول
byId('cap-product-id').addEventListener('change', handleProductChange);


function collectCapacityFormData() {
    var productSel   = byId('cap-product-id');
    var courseType   = productSel.options[productSel.selectedIndex] ? productSel.options[productSel.selectedIndex].getAttribute('data-course-type') : '';
    var genderEl     = byId('cap-gender');
    var genderHidden = byId('cap-gender-hidden');

    var genderVal = (genderEl && genderEl.value.trim()) ? genderEl.value.trim() : (genderHidden ? genderHidden.value.trim() : '');

    var messengerVal = byId('cap-messenger') ? byId('cap-messenger').value.trim() : '';
    
    // اگر دوره مقدماتی/پیشرفته نیست و ردیف مخفی است، پیام‌رسان را خالی می‌فرستیم
    if (courseType !== 'intro' && courseType !== 'advanced') {
        var messengerRow = document.getElementById('cap-messenger-row');
        if (messengerRow && messengerRow.style.display === 'none') {
            messengerVal = '';
        }
    }

    return {
        student_id:     byId('cap-student-id').value.trim(),
        product_id:     byId('cap-product-id').value.trim(),
        messenger:      messengerVal,
        student_gender: genderVal
    };
}

function validateCapacityForm(data) {
    var missing = [];
    var productSel = byId('cap-product-id');
    var courseType = productSel.options[productSel.selectedIndex] ? productSel.options[productSel.selectedIndex].getAttribute('data-course-type') : '';

    if (!data.student_id) missing.push('هنرجو');
    if (!data.product_id) missing.push('محصول');

    if (courseType === 'intro' || courseType === 'advanced') {
        if (!data.messenger) missing.push('پیام‌رسان');
    } else {
        var messengerRow = document.getElementById('cap-messenger-row');
        if (messengerRow && messengerRow.style.display !== 'none' && !data.messenger) {
            missing.push('پیام‌رسان');
        }
    }
    
    if (!data.student_gender) missing.push('جنسیت');

    if (missing.length) {
        showAssignMessage('error', '❌ لطفاً این فیلدها را تکمیل کنید: ' + missing.join('، '));
        return false;
    }
    return true;
}

/* ── تابع کمکی: لود ظرفیت‌ها (بدون بررسی جنسیت) ── */
function doLoadAvailableTAs(formData) {
    byId('cap-step-3').style.display = 'block';
    byId('cap-ta-list').innerHTML = '<div style="padding:12px;color:#888">در حال بارگذاری...</div>';
    hideAssignMessage();

    fetch(taAjaxUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
        },
        body: new URLSearchParams({
            action: 'ta_admin_get_available_tas',
            nonce: taAdminNonce,
            product_id: formData.product_id,
            messenger: formData.messenger,
            student_gender: formData.student_gender,
            student_id: formData.student_id
        })
    })
    .then(function (r) { return r.json(); })
    .then(function (res) {
        if (!res.success) {
            byId('cap-ta-list').innerHTML =
                '<div style="padding:12px;color:#c00">' +
                (typeof res.data === 'string' ? res.data : 'خطا در دریافت ظرفیت‌ها') +
                '</div>';
            return;
        }
        renderAvailableTAs(res.data);
    })
    .catch(function (err) {
        byId('cap-ta-list').innerHTML =
            '<div style="padding:12px;color:#c00">خطا در ارتباط با سرور: ' + err.message + '</div>';
    });
}

/* ── تابع اصلی دکمه «نمایش ظرفیت‌های موجود» ── */
window.taLoadAvailableTAs = function () {
    
    var productSel = byId('cap-product-id');
    var courseType = productSel.options[productSel.selectedIndex] ? productSel.options[productSel.selectedIndex].getAttribute('data-course-type') : '';

    // --- ذخیره ظاهری فیلدهای ویرایش شده و بازگشت به حالت قبل ---
    if (courseType === 'intro' || courseType === 'advanced') {
        var msgr = byId('cap-messenger').value.trim();
        var link = byId('cap-group-link').value.trim();
        
        // آپدیت متن باکس طوسی
        var infoText = '<strong>پیام‌رسان:</strong> ' + (msgr || 'وارد نشده') + ' | <strong>لینک گروه:</strong> <span dir="ltr">' + (link || 'وارد نشده') + '</span>';
        var prevTextEl = byId('cap-prev-info-text');
        if (prevTextEl) prevTextEl.innerHTML = infoText;

        // مخفی کردن فرم ویرایش و نمایش مجدد باکس طوسی
        var mRow = document.getElementById('cap-messenger-row');
        var lRow = document.getElementById('cap-group-link-row');
        var pRow = document.getElementById('cap-prev-info-row');
        
        if (mRow) mRow.style.display = 'none';
        if (lRow) lRow.style.display = 'none';
        if (pRow) pRow.style.display = '';
    }
    // -------------------------------------------------------------

    var formData = collectCapacityFormData();

    if (!validateCapacityForm(formData)) {
        return;
    }

    /* ── بررسی: آیا در حال ویرایش جنسیت هستیم و تغییر کرده؟ ── */
    var selectBox    = byId('ta-gender-select-box');
    var genderSel    = byId('cap-gender');
    var genderHidden = byId('cap-gender-hidden');

    if (selectBox && selectBox.style.display !== 'none' && genderSel) {
        var newGender = genderSel.value.trim();
        var oldGender = genderHidden ? genderHidden.value.trim() : '';

        if (newGender && newGender !== oldGender) {
            fetch(taAjaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: new URLSearchParams({
                    action:     'ta_save_student_gender',
                    nonce:      taAdminNonce,
                    student_id: formData.student_id,
                    gender:     newGender
                })
            })
            .then(function (r) { return r.json(); })
            .then(function (res) {
                if (res.success) {
                    if (genderHidden) genderHidden.value = newGender;
                    var displayBox  = byId('ta-gender-display-box');
                    var genderLabel = (newGender === 'male') ? 'آقا' : 'خانم';
                    if (displayBox) {
                        var strong = displayBox.querySelector('strong');
                        if (strong) strong.textContent = genderLabel;
                        displayBox.style.display = '';
                    }
                    selectBox.style.display = 'none';
                }
                doLoadAvailableTAs(formData);
            })
            .catch(function (err) {
                doLoadAvailableTAs(formData);
            });
            return; 
        }
    }

    doLoadAvailableTAs(formData);
};

    function showCustomLinkForm(taId, capacityId) {
        var list = byId('cap-ta-list');

        var oldBox = byId('cap-custom-link-box');
        if (oldBox) oldBox.remove();

        var wrap = document.createElement('div');
        wrap.id = 'cap-custom-link-box';
        wrap.style.cssText = 'margin-top:12px;padding:14px;border:2px dashed #0073aa;border-radius:8px;background:#f0f8ff';

        wrap.innerHTML =
            '<div style="font-weight:700;margin-bottom:8px;color:#b32d2e">⚠️ این دوره نیاز به لینک گروه دارد.</div>' +
            '<div style="margin-bottom:8px">لینک گروه را وارد کنید:</div>' +
            '<input type="url" id="cap-custom-group-link" placeholder="https://..." dir="ltr" ' +
                'style="width:100%;padding:8px 10px;margin-bottom:10px">' +
            '<div style="display:flex;gap:8px;flex-wrap:wrap">' +
                '<button type="button" class="button button-primary" id="cap-submit-custom-link">ثبت لینک و تخصیص</button>' +
                '<button type="button" class="button" id="cap-cancel-custom-link">انصراف</button>' +
            '</div>';

        list.appendChild(wrap);

        byId('cap-submit-custom-link').addEventListener('click', function () {
            var link = byId('cap-custom-group-link').value.trim();

            if (!link || !/^https?:\/\//i.test(link)) {
                showAssignMessage('error', '❌ لطفاً یک لینک معتبر وارد کنید.');
                return;
            }

            submitCapacityAssign(taId, capacityId, link);
        });

        byId('cap-cancel-custom-link').addEventListener('click', function () {
            wrap.remove();
            hideAssignMessage();
        });
    }


function submitCapacityAssign(taId, capacityId, customGroupLink) {
    var formData = collectCapacityFormData();

    if (!validateCapacityForm(formData)) {
        return;
    }

    showAssignMessage('loading', '⏳ در حال ارسال...');

    var payload = {
        action: 'ta_admin_assign_by_capacity',
        nonce: taAdminNonce,
        student_id: formData.student_id,
        ta_id: taId,
        product_id: formData.product_id,
        capacity_id: capacityId,
        messenger: formData.messenger,
        student_gender: formData.student_gender
    };

    // اگر لینک کاستوم خالی بود اما مقداری در اینپوت لینک داشتیم (برای intro/advanced)
    if (!customGroupLink) {
        var productSel = byId('cap-product-id');
        var courseType = productSel.options[productSel.selectedIndex] ? productSel.options[productSel.selectedIndex].getAttribute('data-course-type') : '';
        if (courseType === 'intro' || courseType === 'advanced') {
            customGroupLink = byId('cap-group-link').value.trim();
        }
    }

    if (customGroupLink) {
        payload.custom_group_link = customGroupLink;
    }

    fetch(taAjaxUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: new URLSearchParams(payload)
    })
    .then(function (response) { return response.text(); })
    .then(function (rawText) {
        if (!rawText.trim()) throw new Error('پاسخ خالی از سرور دریافت شد');
        if (rawText.trim().charAt(0) === '<') throw new Error('سرور به‌جای JSON خروجی HTML برگردانده است');
        return JSON.parse(rawText);
    })
    .then(function (res) {
        if (res.success) {
            var message = (res.data && res.data.message) ? res.data.message : 'تخصیص با موفقیت انجام شد.';
            var groupLink = (res.data && res.data.group_link) ? res.data.group_link : '';
            var linkHtml = groupLink
                ? '<br><a href="' + groupLink + '" target="_blank" rel="noopener" style="color:#fff;text-decoration:underline">🔗 لینک گروه</a>'
                : '';

            showAssignMessage('success', '✅ ' + message + linkHtml);
            
            // ریست کردن مودال پس از موفقیت
            resetCapacityModal();

            // در صورت نیاز به ریلود صفحه:
            // setTimeout(function () { window.location.reload(); }, 1800);
            return;
        }

        if (res.data && res.data.needs_link) {
            showAssignMessage('error', '⚠️ ' + (res.data.message || 'لطفاً لینک گروه را وارد کنید.'));
            showCustomLinkForm(taId, capacityId);
            return;
        }

        var errorMessage = (res.data && res.data.message) ? res.data.message : (typeof res.data === 'string') ? res.data : 'خطا در تخصیص استادیار';
        showAssignMessage('error', '⚠️ ' + errorMessage);
    })
    .catch(function (err) {
        showAssignMessage('error', '🔴 ' + err.message);
    });
}



    window.taDoCapacityAssign = function (taId, capacityId) {
        submitCapacityAssign(taId, capacityId, '');
    };

    document.addEventListener('click', function (e) {
        var pickBtn = e.target.closest('.ta-capacity-pick-btn');
        if (pickBtn) {
            e.preventDefault();
            var taId = pickBtn.getAttribute('data-ta-id');
            var capacityId = pickBtn.getAttribute('data-capacity-id');
            submitCapacityAssign(taId, capacityId, '');
            return;
        }

        if (e.target === byId('ta-capacity-assign-modal')) {
            closeCapacityModal();
        }
    });

    document.addEventListener('DOMContentLoaded', function () {
        var searchInput = byId('cap-student-search');
        if (!searchInput) return;

   searchInput.addEventListener('input', function () {
            clearTimeout(capSearchTimer);

            var q = this.value.trim();
            if (q.length < 2) {
                byId('cap-student-results').style.display = 'none';
                byId('cap-student-results').innerHTML = '';
                return;
            }

            capSearchTimer = setTimeout(function () {
                fetch(taAjaxUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                    },
                    body: new URLSearchParams({
                        action: 'ta_search_users',
                        nonce: taAdminNonce,
                        q: q
                    })
                })
                .then(function (r) { return r.json(); })
                .then(function (res) {
                    var box = byId('cap-student-results');
                    box.innerHTML = '';

                    if (!res.success || !res.data || !res.data.length) {
                        box.innerHTML = '<div style="padding:10px;color:#888">نتیجه‌ای یافت نشد</div>';
                        box.style.display = 'block';
                        return;
                    }

                    res.data.forEach(function (u) {
                        var item = document.createElement('div');
                        item.style.cssText = 'padding:8px 12px;cursor:pointer;border-bottom:1px solid #eee';
                        item.textContent = (u.name || '') + ' — ' + (u.phone || '');
                        item.addEventListener('mouseenter', function () {
                            this.style.background = '#f0f7ff';
                        });
                        item.addEventListener('mouseleave', function () {
                            this.style.background = '';
                        });
                        item.addEventListener('click', function () {
                            byId('cap-student-id').value = u.id;
                            byId('cap-student-selected').textContent =
                                '✅ ' + (u.name || 'هنرجو') + ((u.phone ? ' (' + u.phone + ')' : ''));
                            byId('cap-student-selected').style.display = 'block';
                            byId('cap-student-search').value = '';
                            byId('cap-student-results').style.display = 'none';
                            byId('cap-step-2').style.display = 'block';
                            byId('cap-step-3').style.display = 'none';
                            byId('cap-ta-list').innerHTML = '';
                            hideAssignMessage();
                        });
                        box.appendChild(item);
                    });

                    box.style.display = 'block';
                })
                .catch(function () {
                    byId('cap-student-results').innerHTML =
                        '<div style="padding:10px;color:#c00">خطا در جستجوی هنرجو</div>';
                    byId('cap-student-results').style.display = 'block';
                });
            }, 350);
        });
    });
   
    jQuery(document).ready(function($) {

    // === مدیریت تغییر محصول در مودال ظرفیت ===
        $('#cap-product-id').on('change', function() {
        const $selectedOption = $(this).find('option:selected');
        const courseType = $selectedOption.data('course-type');
        const studentId = $('#cap-student-id').val();
        const productId = $(this).val();

        // ۱. ریست کردن ظاهر
        $('#cap-prev-info-row, #cap-group-link-row').hide();
        $('#cap-messenger, #cap-group-link').val('');

        // ۲. بررسی نوع دوره
        if (courseType === 'intro' || courseType === 'advanced') {
            
            $('#cap-messenger-row').hide();
            
            // نمایش متن "در حال بارگذاری" به کاربر
            $('#cap-prev-info-text').text('⏳ در حال دریافت اطلاعات دوره قبل...');
            $('#cap-prev-info-row').show();
            $('#cap-edit-prev-info-btn').hide(); 
            
            // ۳. درخواست AJAX
            // دقت کنید نام اکشن باید با بک‌اند تطابق داشته باشد
            $.post(ajaxurl, {
                action: 'ta_admin_get_prev_course_info', // مطمئن شوید نام اکشن در PHP هم همین است
                student_id: studentId,
                product_id: productId
            })
            .done((response) => {
                if (response.success && response.data) {
                    const { messenger, group_link } = response.data;
                    
                    $('#cap-prev-info-text').html(`<strong>پیام‌رسان:</strong> ${messenger} | <strong>لینک گروه:</strong> <span dir="ltr">${group_link}</span>`);
                    
                    $('#cap-messenger').val(messenger);
                    $('#cap-group-link').val(group_link);
                } else {
                    $('#cap-prev-info-text').text('⚠️ سابقه دوره پیش‌نیاز یافت نشد.');
                }
            })
            .fail(() => {
                $('#cap-prev-info-text').text('❌ خطا در دریافت اطلاعات. لطفاً ویرایش را بزنید.');
            })
            .always(() => {
                $('#cap-edit-prev-info-btn').show();
            });

        } else {
            $('#cap-messenger-row').show();
        }
    });

    // === دکمه ویرایش اطلاعات ===
    $('#cap-edit-prev-info-btn').on('click', function(e) {
        e.preventDefault(); // جلوگیری از رفتار پیش‌فرض دکمه
        $('#cap-prev-info-row').hide();
        $('#cap-messenger-row').fadeIn(); 
        $('#cap-group-link-row').fadeIn(); 
    });

});

})();
</script>
    
        <script>
        var taAdminNonce = '<?= wp_create_nonce('ta_admin_nonce') ?>';
        var taAjaxUrl   = '<?= admin_url('admin-ajax.php') ?>';
        var searchTimer = null;

        function taOpenAssignModal() {
            document.getElementById('ta-assign-modal').style.display = 'block';
        }
        function taCloseModal(id) {
            document.getElementById(id).style.display = 'none';
        }
        window.onclick = function(e) {
            ['ta-assign-modal','ta-edit-modal'].forEach(function(id){
                var el = document.getElementById(id);
                if (e.target === el) el.style.display = 'none';
            });
        };

        // جستجوی هنرجو با debounce
        document.getElementById('assign_student_search').addEventListener('input', function(){
            clearTimeout(searchTimer);
            var q = this.value.trim();
            if (q.length < 2) { document.getElementById('assign_student_results').style.display='none'; return; }
            searchTimer = setTimeout(function(){
                fetch(taAjaxUrl, {
                    method:'POST',
                    headers:{'Content-Type':'application/x-www-form-urlencoded'},
                    body: 'action=ta_search_users&nonce='+taAdminNonce+'&q='+encodeURIComponent(q)
                }).then(r=>r.json()).then(function(res){
                    if (!res.success) return;
                    var box = document.getElementById('assign_student_results');
                    box.innerHTML = '';
                    if (!res.data.length) {
                        box.innerHTML = '<div style="padding:8px 12px;color:#888;font-size:0.85rem">نتیجه‌ای یافت نشد</div>';
                        box.style.display = 'block'; return;
                    }
                    res.data.forEach(function(u){
                        var d = document.createElement('div');
                        d.style.cssText = 'padding:8px 12px;cursor:pointer;font-size:0.88rem;border-bottom:1px solid #eee';
                        d.textContent = u.label;
                        d.addEventListener('mouseover',function(){this.style.background='#f0f4f8'});
                        d.addEventListener('mouseout', function(){this.style.background=''});
                        d.addEventListener('click',function(){
                            document.getElementById('assign_student_id').value = u.id;
                            document.getElementById('assign_student_search').value = u.label;
                            document.getElementById('assign_student_selected').textContent = '✅ انتخاب شد: '+u.name;
                            box.style.display = 'none';
                        });
                        box.appendChild(d);
                    });
                    box.style.display = 'block';
                });
            }, 350);
        });

        // ویرایش تخصیص
           function taOpenEditModal(assignId) {
            fetch(taAjaxUrl, {
                method:'POST',
                headers:{'Content-Type':'application/x-www-form-urlencoded'},
                body: 'action=ta_get_assignment&nonce='+taAdminNonce+'&id='+assignId
            }).then(r=>r.json()).then(function(res){
                if (!res.success) { alert('خطا در دریافت اطلاعات'); return; }
                var d = res.data;
                document.getElementById('edit_assignment_id').value = d.id;
                document.getElementById('edit_ta_id').value        = d.ta_id;
                document.getElementById('edit_messenger').value    = d.messenger||'telegram';
                document.getElementById('edit_gender').value       = d.student_gender||'female';
                document.getElementById('edit_group_link').value   = d.group_link||'';
                
                // مقداردهی وضعیت
                var statusField = document.getElementById('edit_status');
                statusField.value = d.status||'active';

                // مقداردهی فیلدهای انصراف
                var cancelReasonField = document.getElementById('edit_cancel_reason');
                var cancelDateDisplay = document.getElementById('edit_cancel_date_display');
                
                if (cancelReasonField) cancelReasonField.value = d.cancel_reason || '';
                if (cancelDateDisplay) cancelDateDisplay.innerHTML = d.cancel_date || '';

                // فراخوانی تابعی که نمایش/مخفی کردن فیلدهای انصراف را کنترل می کند
                if (typeof taToggleCancelFields === 'function') {
                    taToggleCancelFields();
                }

                var phone = d.student_phone ? ' — ' + d.student_phone : '';
                document.getElementById('ta-edit-info').innerHTML =
                    '<strong>هنرجو:</strong> '+d.student_name+phone+
                    ' | <strong>محصول ID:</strong> '+d.product_id+
                    ' | <strong>دوره:</strong> '+d.course_type;
                document.getElementById('ta-edit-modal').style.display = 'block';
            });
        }

        </script>

        <?php
    }

    private function render_notices(): void {
        $map = [
            'assigned'                 => [ 'success', '✅ تخصیص با موفقیت ثبت شد.' ],
            'edited'                   => [ 'success', '✅ تخصیص ویرایش شد.' ],
            'deleted'                  => [ 'success', '🗑️ تخصیص حذف شد.' ],
            'error=missing_fields'     => [ 'error',   '❌ اطلاعات ناقص است.' ],
            'error=product_not_configured' => [ 'error', '❌ محصول در سیستم استادیار پیکربندی نشده.' ],
            'error=duplicate'          => [ 'error',   '❌ این هنرجو قبلاً برای این محصول تخصیص دارد.' ],
        ];
        foreach ( $map as $key => [ $type, $msg ] ) {
            if ( strpos( $key, '=' ) !== false ) {
                [$k, $v] = explode( '=', $key, 2 );
                if ( ( $_GET[ $k ] ?? '' ) === $v ) {
                    echo "<div class='notice notice-{$type} is-dismissible'><p>{$msg}</p></div>";
                }
            } else {
                if ( isset( $_GET[ $key ] ) ) {
                    echo "<div class='notice notice-{$type} is-dismissible'><p>{$msg}</p></div>";
                }
            }
        }
    }

    private function enqueue_admin_scripts(): void {
        // Inline CSS برای مودال در صفحه ادمین
        echo '<style>
            #ta-assign-modal .form-table th { width:130px; font-weight:600; }
            #ta-edit-modal   .form-table th { width:130px; font-weight:600; }
        </style>';
    }

    private function redirect( string $params ): never {
        wp_redirect( admin_url( "admin.php?page=ta-assignments&{$params}" ) );
        exit;
    }
    
    
    
}