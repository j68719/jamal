<?php
defined( 'ABSPATH' ) || exit;

class TA_Admin_Menu {

   
    public function __construct() {
        add_action( 'admin_menu', [ $this, 'register_menus' ] );
        add_action( 'admin_notices', [ $this, 'notice_tables_missing' ] );
        add_action( 'admin_init', [ $this, 'handle_manual_install' ] );
    }

  

    /**
     * اجرای نصب دستی از طریق دکمه در پیشخوان
     */
    public function handle_manual_install(): void {
        if (
            isset( $_GET['ta_install_tables'] ) &&
            current_user_can( 'manage_options' ) &&
            wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'ta_install_tables' )
        ) {
            TA_Database::install();
            wp_redirect( admin_url( 'admin.php?page=ta-system&ta_installed=1' ) );
            exit;
        }
    }

    /**
     * نمایش notice اگر جداول وجود ندارند
     */
    public function notice_tables_missing(): void {
        $screen = get_current_screen();
        if ( ! $screen || strpos( $screen->id, 'ta-' ) === false ) {
            return;
        }
        if ( TA_Database::tables_exist() ) {
            if ( isset( $_GET['ta_installed'] ) ) {
                echo '<div class="notice notice-success is-dismissible"><p>✅ جداول پایگاه داده با موفقیت ایجاد شدند.</p></div>';
            }
            return;
        }
        $install_url = wp_nonce_url(
            admin_url( 'admin.php?page=ta-system&ta_install_tables=1' ),
            'ta_install_tables'
        );
        echo '<div class="notice notice-error">';
        echo '<p><strong>سیستم استادیار:</strong> جداول پایگاه داده وجود ندارند.</p>';
        echo '<p><a href="' . esc_url( $install_url ) . '" class="button button-primary">▶ ایجاد جداول الان</a></p>';
        echo '</div>';
    }
    
    
    public function page_customers(): void {
        // [FIX-PATH] require_once زائد حذف شد — autoloader این کلاس را بارگذاری می‌کند
        ( new TA_Admin_Customers() )->render();
    }

    public function register_menus(): void {
        // [FIX-DOUBLE-CAPACITY] TA_Capacity_Manager اینجا یک‌بار ساخته می‌شود
        // (نسخه ta-system.php حذف شده تا از ثبت دوباره هوک‌های AJAX جلوگیری شود)
        require_once TA_SYSTEM_PATH . 'admin/class-capacity-manager.php';
        $this->capacity_manager = new TA_Capacity_Manager();

        add_menu_page(
            'سیستم استادیار',
            'سیستم استادیار',
            'manage_options',
            'ta-system',
            [ $this, 'page_dashboard' ],
            'dashicons-groups',
            56
        );

        add_submenu_page(
            'ta-system',
            'مدیریت استادیارها',
            'استادیارها',
            'manage_options',
            'ta-assistants',
            [ $this, 'page_assistants' ]
        );

        add_submenu_page(
            'ta-system',
            'ترم‌ها',
            'ترم‌ها',
            'manage_options',
            'ta-terms',
            [ $this, 'page_terms' ]
        );

        add_submenu_page(
            'ta-system',
            'تخصیص‌ها',
            'تخصیص‌ها',
            'manage_options',
            'ta-assignments',
            [ $this, 'page_assignments' ]
        );
        
        // مشتریان دوره‌ها
add_submenu_page(
    'ta-system',
    'مشتریان دوره‌ها',
    'مشتریان دوره‌ها',
    'manage_options',
    'ta-customers',
    [ $this, 'page_customers' ]
);

        add_submenu_page(
            'ta-system',
            'نمره‌ها',
            'نمره‌ها',
            'manage_options',
            'ta-grades',
            [ $this, 'page_grades' ]
        );

       // زیرمنو: بررسی ظرفیت‌ها
        add_submenu_page(
            'ta-system',
            'بررسی ظرفیت‌ها',
            'ظرفیت‌ها',
            'manage_options', // به جای $cap، این مقدار را مستقیم وارد کنید
            'ta-capacities',
            [ $this, 'render_capacities_page' ]
        );

        add_submenu_page(
            'ta-system',
            'حسابداری حق‌الزحمه',
            '💰 حق‌الزحمه',
            'manage_options',
            'ta-payroll',
            [ $this, 'page_payroll' ]
        );

        add_submenu_page(
            'ta-system',
            'گزارش نقد داستان',
            '📝 نقد داستان',
            'manage_options',
            'ta-story-critique',
            [ $this, 'page_story_critique' ]
        );

        add_submenu_page(
            'ta-system',
            'ایمپورت داده',
            '📥 ایمپورت داده',
            'manage_options',
            'ta-import',
            [ $this, 'page_import' ]
        );
        
                // اضافه کردن زیرمنوی تنظیمات (حدود خط 113)
        add_submenu_page(
            'ta-system',
            'تنظیمات',
            'تنظیمات',
            'manage_options',
            'ta-settings',
            [ $this, 'page_settings' ]
        );

        // [FIX-UNASSIGNED] ثبت صفحه سفارشات بدون استادیار که قبلاً در منو نبود
        add_submenu_page(
            'ta-system',
            'سفارشات بدون استادیار',
            '⚠️ بدون استادیار',
            'manage_options',
            'ta-unassigned-orders',
            [ $this, 'page_unassigned_orders' ]
        );

    }

    public function page_payroll(): void {
        ( new TA_Payroll() )->render();
    }

    public function page_import(): void {
        ( new TA_Admin_Import() )->render();
    }

    public function page_dashboard(): void {
        echo '<div class="wrap"><h1>سیستم تخصیص استادیار</h1>';
        echo '<p>به پنل مدیریت سیستم استادیار خوش آمدید.</p></div>';
    }

    public function page_assistants(): void {
        ( new TA_Admin_TA_Manager() )->render();
    }

    public function page_terms(): void {
        $this->handle_term_actions();
        $this->render_terms_page();
    }

    public function page_assignments(): void {
        ( new TA_Admin_Assignments() )->render();
    }

    public function page_grades(): void {
        require_once TA_SYSTEM_PATH . 'admin/class-grades-manager.php';
        ( new TA_Grades_Manager() )->render();
    }

    // ── Terms Management ─────────────────────────────────────────────────────
    private function handle_term_actions(): void {
        if ( ! isset( $_POST['ta_term_nonce'] ) || ! wp_verify_nonce( $_POST['ta_term_nonce'], 'ta_save_term' ) ) {
            return;
        }

        $action = sanitize_text_field( $_POST['ta_action'] ?? '' );

        if ( $action === 'save_term' ) {
            $name  = sanitize_text_field( $_POST['term_name'] ?? '' );
            $slug  = sanitize_key( $_POST['term_slug'] ?? '' );
            $order = (int) ( $_POST['term_order'] ?? 0 );
            $id    = (int) ( $_POST['term_id'] ?? 0 );

            if ( $name && $slug ) {
                if ( $id ) {
                    TA_Database::update( 'ta_terms', [ 'name' => $name, 'slug' => $slug, 'order_index' => $order ], [ 'id' => $id ] );
                } else {
                    TA_Database::insert( 'ta_terms', [ 'name' => $name, 'slug' => $slug, 'order_index' => $order, 'created_at' => current_time( 'mysql' ) ] );
                }
                echo '<div class="notice notice-success"><p>ترم ذخیره شد.</p></div>';
            }
        }

        if ( $action === 'delete_term' ) {
            $id = (int) ( $_POST['term_id'] ?? 0 );
            TA_Database::delete( 'ta_terms', [ 'id' => $id ] );
            echo '<div class="notice notice-success"><p>ترم حذف شد.</p></div>';
        }
    }

    private function render_terms_page(): void {
        if ( ! TA_Database::tables_exist() ) {
            echo '<div class="wrap"><div class="notice notice-error"><p>جداول پایگاه داده وجود ندارند.</p></div></div>';
            return;
        }
        $terms = TA_Database::get_results(
            "SELECT * FROM " . TA_Database::table( 'terms' ) . " ORDER BY order_index ASC"
        );
        ?>
        <div class="wrap" dir="rtl">
            <h1>مدیریت ترم‌ها</h1>

            <h2>افزودن / ویرایش ترم</h2>
            <form method="post">
                <?php wp_nonce_field( 'ta_save_term', 'ta_term_nonce' ); ?>
                <input type="hidden" name="ta_action" value="save_term">
                <input type="hidden" name="term_id" id="edit_term_id" value="0">
                <table class="form-table">
                    <tr>
                        <th>نام ترم <span style="color:red">*</span></th>
                        <td><input type="text" name="term_name" id="edit_term_name" class="regular-text" placeholder="مثلاً: زمستان ۱۴۰۴" required></td>
                    </tr>
                    <tr>
                        <th>شناسه (Slug) <span style="color:red">*</span></th>
                        <td><input type="text" name="term_slug" id="edit_term_slug" class="regular-text" placeholder="winter_1404" required></td>
                    </tr>
                    <tr>
                        <th>ترتیب</th>
                        <td><input type="number" name="term_order" id="edit_term_order" value="0" class="small-text"></td>
                    </tr>
                </table>
                <?php submit_button( 'ذخیره ترم', 'primary', 'submit', false ); ?>
                <button type="button" onclick="resetTermForm()" class="button">انصراف</button>
            </form>

            <h2>ترم‌های موجود</h2>
            <table class="wp-list-table widefat fixed">
                <thead>
                    <tr>
                        <th>ID</th><th>نام</th><th>Slug</th><th>ترتیب</th><th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ( $terms as $term ) : ?>
                    <tr>
                        <td><?= $term->id ?></td>
                        <td><?= esc_html( $term->name ) ?></td>
                        <td><?= esc_html( $term->slug ) ?></td>
                        <td><?= $term->order_index ?></td>
                        <td>
                            <button type="button" class="button button-small"
                                onclick="editTerm(<?= $term->id ?>, '<?= esc_js( $term->name ) ?>', '<?= esc_js( $term->slug ) ?>', <?= $term->order_index ?>)">
                                ویرایش
                            </button>
                            <form method="post" style="display:inline">
                                <?php wp_nonce_field( 'ta_save_term', 'ta_term_nonce' ); ?>
                                <input type="hidden" name="ta_action" value="delete_term">
                                <input type="hidden" name="term_id" value="<?= $term->id ?>">
                                <button class="button button-small button-link-delete" onclick="return confirm('حذف شود؟')">حذف</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <script>
        function editTerm(id, name, slug, order) {
            document.getElementById('edit_term_id').value = id;
            document.getElementById('edit_term_name').value = name;
            document.getElementById('edit_term_slug').value = slug;
            document.getElementById('edit_term_order').value = order;
            window.scrollTo(0, 0);
        }
        function resetTermForm() {
            document.getElementById('edit_term_id').value = 0;
            document.getElementById('edit_term_name').value = '';
            document.getElementById('edit_term_slug').value = '';
            document.getElementById('edit_term_order').value = 0;
        }
        </script>
        <?php
    }


    // render_capacities_page دیگر نیازی به ساختن کلاس ندارد
    public function render_capacities_page(): void {
        $this->capacity_manager->render_page();
    }
   

    public function page_unassigned_orders(): void {
        // [FIX-UNASSIGNED] بارگذاری کلاس که قبلاً در autoloader و منو ثبت نشده بود
        $file = TA_SYSTEM_PATH . 'admin/class-unassigned-orders.php';
        if ( file_exists( $file ) ) {
            require_once $file;
            ( new TA_Admin_Unassigned_Orders() )->render();
        } else {
            echo '<div class="wrap"><div class="notice notice-error"><p>فایل class-unassigned-orders.php یافت نشد.</p></div></div>';
        }
    }

    public function page_story_critique(): void {
        $table  = TA_Database::table('story_critique_forms');
        $rows   = TA_Database::get_results( "SELECT scf.*, u.user_email FROM {$table} scf LEFT JOIN {$GLOBALS['wpdb']->users} u ON u.ID = scf.user_id ORDER BY scf.created_at DESC LIMIT 1000" );
        ?>
        <div class="wrap" dir="rtl">
            <h1>📝 گزارش فرم‌های نقد داستان</h1>
            <p style="color:#555">تعداد کل: <strong><?= count($rows) ?></strong> فرم</p>
            <?php if ( empty($rows) ) : ?>
                <div class="notice notice-info"><p>هنوز فرمی ارسال نشده است.</p></div>
            <?php else : ?>
            <style>
            .ta-sc-table { width:100%; border-collapse:collapse; font-size:13px; background:#fff; }
            .ta-sc-table th { background:#f8f9fa; padding:10px 12px; text-align:right; font-weight:700; border-bottom:2px solid #dee2e6; white-space:nowrap; }
            .ta-sc-table td { padding:9px 12px; border-bottom:1px solid #f0f0f0; vertical-align:top; }
            .ta-sc-table tr:hover td { background:#fafafa; }
            .ta-sc-chip { display:inline-block; padding:2px 8px; border-radius:99px; font-size:11px; font-weight:700; margin:2px; }
            .ta-sc-wrap { border:1px solid #e5e7eb; border-radius:8px; overflow-x:auto; }
            </style>
            <div class="ta-sc-wrap">
            <table class="ta-sc-table widefat">
                <thead><tr>
                    <th>#</th>
                    <th>نام و نام‌خانوادگی</th>
                    <th>شماره تماس</th>
                    <th>آیدی بله</th>
                    <th>ایمیل</th>
                    <th>تخصص‌ها</th>
                    <th>سایر موارد</th>
                    <th>ساعات در روز</th>
                    <th>تاریخ ارسال</th>
                </tr></thead>
                <tbody>
                <?php
                $CHIP_COLORS = ['#ede9fe:#6d28d9','#fce7f3:#9d174d','#d1fae5:#065f46','#fef3c7:#92400e','#dbeafe:#1e40af','#fee2e2:#991b1b','#e0f2fe:#0369a1','#f0fdf4:#166534','#fdf4ff:#7e22ce','#fff7ed:#c2410c'];
                $i = 0;
                foreach ( $rows as $idx => $r ) :
                    $specs = $r->specialties ? json_decode($r->specialties, true) : [];
                    $specs = is_array($specs) ? $specs : [];
                ?>
                <tr>
                    <td style="color:#9ca3af;font-size:11px"><?= $idx+1 ?></td>
                    <td><strong><?= esc_html($r->full_name) ?></strong></td>
                    <td style="direction:ltr;text-align:right"><?= esc_html($r->phone) ?></td>
                    <td><?= esc_html($r->bale_id) ?></td>
                    <td style="font-size:11px;color:#6b7280"><?= esc_html($r->user_email ?? '—') ?></td>
                    <td>
                        <?php foreach($specs as $s):
                            $c = $CHIP_COLORS[$i % count($CHIP_COLORS)];
                            [$bg,$fg] = explode(':',$c);
                            $i++;
                        ?>
                        <span class="ta-sc-chip" style="background:<?= $bg ?>;color:<?= $fg ?>"><?= esc_html($s) ?></span>
                        <?php endforeach; ?>
                    </td>
                    <td style="max-width:200px;font-size:12px;color:#374151"><?= esc_html($r->other_specialty ?: '—') ?></td>
                    <td><?= esc_html($r->hours_per_day) ?></td>
                    <td style="font-size:11px;color:#9ca3af;white-space:nowrap"><?= esc_html($r->created_at) ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }

    public function page_settings(): void {
        // [FIX-DOUBLE-SETTINGS] هوک‌ها قبلاً در ta-system.php ثبت شده‌اند
        // TA_Settings::$hooks_registered=true است پس constructor تکراری ثبت نمی‌کند
        ( new TA_Settings() )->render();
    }


}
